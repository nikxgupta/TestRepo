************************************
 Thank you for purchasing our theme
************************************

FILES
-----
Fuse-1.4.4.zip      :  Fuse Template Skeleton Project
Fuse-1.4.4-demo.zip :  Fuse Template Demo Project


UPDATING THE TEMPLATE
---------------------
You can use our GitHub repository to easily update the template.
To access our repository please visit http://withinpixels.com/themes/fuse/github page.


DOCUMENTATION
-------------
You can access the online documentation at
http://withinpixels.com/themes/fuse/documentation


SUPPORT REQUESTS
----------------
For your support requests, please visit http://withinpixels.ticksy.com
Your support requests will be queued and can take up to 48 hours in
working days before answered.