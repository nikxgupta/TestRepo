﻿namespace Machs.Model
{
    using System;

    public class main_footer_help_Constant : BaseEntity
    {
        public const string ACTIONNAME = "ActionName";
        public const string CONTROLLERNAME = "ControllerName";
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string DISPLAYORDER = "Displayorder";
        public const string FOOTERHELPID = "FooterHelpId";
        public const string ISCUSTOM = "IsCustom";
        public const string ISHIDE = "IsHide";
        public const string ISTEMPLATE = "IsTemplate";
        public const string LANGUAGE = "Language";
        public const string LINKPATH = "LinkPath";
        public const string Machs_SPROC_MAIN_FOOTER_HELP_DEL = "sproc_main_footer_help_del";
        public const string Machs_SPROC_MAIN_FOOTER_HELP_LSTALL = "sproc_main_footer_help_lstAll";
        public const string Machs_SPROC_MAIN_FOOTER_HELP_SEARCH_LSTALL = "sproc_Search_main_footer_help_lstAll";
        public const string Machs_SPROC_MAIN_FOOTER_HELP_SEL = "sproc_main_footer_help_sel";
        public const string Machs_SPROC_MAIN_FOOTER_HELP_UPS = "sproc_main_footer_help_ups";
        public const string TITLE = "Title";
        public const string TITLEARABIC = "TitleArabic";
    }
}

