﻿namespace Machs.Model
{
    using System;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class FileHandle
    {
        public Stream Content { get; set; }

        public long ContentLength { get; set; }

        public HttpPostedFileBase File { get; set; }

        public string FileId { get; set; }

        public string FileName { get; set; }

        public string FilePath { get; set; }

        public string MIMEType { get; set; }
    }
}

