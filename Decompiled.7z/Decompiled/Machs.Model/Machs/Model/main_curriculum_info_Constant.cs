﻿namespace Machs.Model
{
    using System;

    public class main_curriculum_info_Constant : BaseEntity
    {
        public const string ACADEMICTERM = "AcademicTerm";
        public const string COURSECODE = "CourseCode";
        public const string COURSEDESCRIPTION = "CourseDescription";
        public const string COURSENAME = "CourseName";
        public const string CREDITS = "Credits";
        public const string CURRICULUMINFOID = "CurriculumInfoId";
        public const string CURRICULUMYEARID = "CurriculumYearId";
        public const string Machs_SPROC_MAIN_CURRICULUM_INFO_DEL = "sproc_main_curriculum_info_del";
        public const string Machs_SPROC_MAIN_CURRICULUM_INFO_LSTALL = "sproc_main_curriculum_info_lstAll";
        public const string Machs_SPROC_MAIN_CURRICULUM_INFO_LSTALL_BYCURRICULUMYEARID = "sproc_main_curriculum_info_lstAll_ByCurriculumYearId";
        public const string Machs_SPROC_MAIN_CURRICULUM_INFO_SEARCH_LSTALL = "sproc_Search_main_curriculum_info_lstAll";
        public const string Machs_SPROC_MAIN_CURRICULUM_INFO_SEL = "sproc_main_curriculum_info_sel";
        public const string Machs_SPROC_MAIN_CURRICULUM_INFO_UPS = "sproc_main_curriculum_info_ups";
        public const string PREREQUISITES = "PreRequisites";
    }
}

