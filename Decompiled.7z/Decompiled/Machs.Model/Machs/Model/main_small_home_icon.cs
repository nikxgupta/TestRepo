﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_small_home_icon : BaseEntity
    {
        public string ActionName { get; set; }

        public string ControllerName { get; set; }

        public string DataArabic { get; set; }

        public string DataEnglish { get; set; }

        [Display(Name="Display Order"), Required(ErrorMessage="Please Enter Display Order")]
        public int? Displayorder { get; set; }

        [Display(Name="Icon Image Path")]
        public string IconImagePath { get; set; }

        [Display(Name="Is Custom")]
        public bool IsCustom { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        [Display(Name="Is Template")]
        public bool IsTemplate { get; set; }

        public int Language { get; set; }

        [Display(Name="Link Path")]
        public string LinkPath { get; set; }

        public int SmallHomeIconId { get; set; }

        [Required(ErrorMessage="Please Enter Title")]
        public string Title { get; set; }

        [Required(ErrorMessage="Please Enter Title in Arabic"), Display(Name="Title in Arabic")]
        public string TitleArabic { get; set; }

        public HttpPostedFileBase UploadFile { get; set; }
    }
}

