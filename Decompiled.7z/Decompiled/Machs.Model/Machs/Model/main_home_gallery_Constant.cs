﻿namespace Machs.Model
{
    using System;

    public class main_home_gallery_Constant : BaseEntity
    {
        public const string GALLERYDESCRIPTION = "GalleryDescription";
        public const string GALLERYDESCRIPTIONARABIC = "GalleryDescriptionArabic";
        public const string GALLERYIMAGE = "GalleryImage";
        public const string HOMEGALLERYID = "HomeGalleryId";
        public const string ISHIDE = "IsHide";
        public const string Machs_SPROC_MAIN_HOME_GALLERY_DEL = "sproc_main_home_gallery_del";
        public const string Machs_SPROC_MAIN_HOME_GALLERY_LSTALL = "sproc_main_home_gallery_lstAll";
        public const string Machs_SPROC_MAIN_HOME_GALLERY_SEARCH_LSTALL = "sproc_Search_main_home_gallery_lstAll";
        public const string Machs_SPROC_MAIN_HOME_GALLERY_SEL = "sproc_main_home_gallery_sel";
        public const string Machs_SPROC_MAIN_HOME_GALLERY_UPS = "sproc_main_home_gallery_ups";
    }
}

