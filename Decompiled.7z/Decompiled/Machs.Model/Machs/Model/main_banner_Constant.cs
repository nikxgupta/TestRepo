﻿namespace Machs.Model
{
    using System;

    public class main_banner_Constant : BaseEntity
    {
        public const string BANNERID = "BannerId";
        public const string BANNERTYPE = "BannerType";
        public const string DESCRIPTION = "Description";
        public const string DESCRIPTIONARABIC = "DescriptionArabic";
        public const string DISPLAYORDER = "DisplayOrder";
        public const string FEATUREDIMAGE = "FeaturedImage";
        public const string ISCAMPUSLIFE = "IsCampusLife";
        public const string ISHOME = "IsHome";
        public const string ISINACTIVE = "IsInactive";
        public const string Machs_SPROC_MAIN_BANNER_DEL = "sproc_main_banner_del";
        public const string Machs_SPROC_MAIN_BANNER_LSTALL = "sproc_main_banner_lstAll";
        public const string Machs_SPROC_MAIN_BANNER_LSTALL_CAMPUSLIFE = "sproc_main_banner_lstAll_campusLife";
        public const string Machs_SPROC_MAIN_BANNER_LSTALL_INDEXPAGE = "sproc_main_banner_lstAll_indexpage";
        public const string Machs_SPROC_MAIN_BANNER_SEARCH_LSTALL = "sproc_Search_main_banner_lstAll";
        public const string Machs_SPROC_MAIN_BANNER_SEL = "sproc_main_banner_sel";
        public const string Machs_SPROC_MAIN_BANNER_UPS = "sproc_main_banner_ups";
        public const string MENUID = "MenuId";
        public const string TITLE = "Title";
        public const string TITLEARABIC = "TitleArabic";
    }
}

