﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web.Mvc;

    public class main_user : BaseEntity
    {
        [Required(ErrorMessage="Enter Confirm Password"), DataType(DataType.Password), System.Web.Mvc.Compare("Password", ErrorMessage="Password not matching"), Display(Name="Confirm Password")]
        public string ConfirmPassword { get; set; }

        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage="Enter Valid Email Address."), Required(ErrorMessage="Enter Email"), Display(Name="Email")]
        public string Email { get; set; }

        [Required(ErrorMessage=" Enter First Name"), RegularExpression("^[a-zA-Z ]+$", ErrorMessage="Enter Only  Alphabets For First Name"), Display(Name="First Name")]
        public string FirstName { get; set; }

        public bool IsActive { get; set; }

        [Display(Name="Last Name"), RegularExpression("^[a-zA-Z ]+$", ErrorMessage="Enter Only  Alphabets For Last Name")]
        public string LastName { get; set; }

        [Display(Name="Middle Name"), RegularExpression("^[a-zA-Z ]+$", ErrorMessage="Enter Only  Alphabets For Middle Name")]
        public string MiddleName { get; set; }

        [StringLength(13, ErrorMessage="Mobile Number  Should not be greater than 13"), Display(Name="Mobile Number")]
        public string MobileNumber { get; set; }

        [DataType(DataType.Password), StringLength(50, MinimumLength=7), Required(ErrorMessage="Enter Password"), Display(Name="Password")]
        public string Password { get; set; }

        [Required(ErrorMessage="Select Role "), Display(Name="Select Role")]
        public int? RoleId { get; set; }

        public string RoleName { get; set; }

        public int UserId { get; set; }
    }
}

