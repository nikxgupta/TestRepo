﻿namespace Machs.Model
{
    using System;

    public class main_library_menu_Constant : BaseEntity
    {
        public const string ACTIONNAME = "ActionName";
        public const string CONTROLLERNAME = "ControllerName";
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string DISPLAYORDER = "Displayorder";
        public const string ISCUSTOM = "IsCustom";
        public const string ISHIDE = "IsHide";
        public const string ISTEMPLATE = "IsTemplate";
        public const string LANGUAGE = "Language";
        public const string LIBRARYMENUID = "LibraryMenuId";
        public const string LINKPATH = "LinkPath";
        public const string Machs_SPROC_MAIN_LIBRARY_MENU_DEL = "sproc_main_library_menu_del";
        public const string Machs_SPROC_MAIN_LIBRARY_MENU_LSTALL = "sproc_main_library_menu_lstAll";
        public const string Machs_SPROC_MAIN_LIBRARY_MENU_SEARCH_LSTALL = "sproc_Search_main_library_menu_lstAll";
        public const string Machs_SPROC_MAIN_LIBRARY_MENU_SEL = "sproc_main_library_menu_sel";
        public const string Machs_SPROC_MAIN_LIBRARY_MENU_TEMPLATE_DEL = "sproc_main_library_menu_template_del";
        public const string Machs_SPROC_MAIN_LIBRARY_MENU_UPS = "sproc_main_library_menu_ups";
        public const string TITLE = "Title";
        public const string TITLEARABIC = "TitleArabic";
    }
}

