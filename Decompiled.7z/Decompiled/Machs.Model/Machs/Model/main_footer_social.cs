﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_footer_social : BaseEntity
    {
        [Required(ErrorMessage=" Enter Display Order"), Display(Name="Display Order")]
        public int Displayorder { get; set; }

        public int FooterSocialId { get; set; }

        [Display(Name="Icon Image Path")]
        public string IconImagePath { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        [Required(ErrorMessage=" Enter Link Path"), Display(Name="Link Path")]
        public string LinkPath { get; set; }

        [Display(Name="Link Text"), Required(ErrorMessage=" Enter Link Text")]
        public string LinkText { get; set; }

        [Required(ErrorMessage=" Enter Link Text in Arabic"), Display(Name="Link Text in Arabic")]
        public string LinkTextArabic { get; set; }

        public HttpPostedFileBase UploadFile { get; set; }
    }
}

