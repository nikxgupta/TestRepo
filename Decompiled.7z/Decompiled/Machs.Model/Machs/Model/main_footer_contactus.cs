﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_footer_contactus : BaseEntity
    {
        [Required(ErrorMessage="Enter Address")]
        public string Address { get; set; }

        [Display(Name="Email Address"), Required(ErrorMessage="Enter Email Address"), RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage="Please Enter Valid Email Address.")]
        public string EmailAddress { get; set; }

        public int FooterContactUsId { get; set; }

        [Display(Name="Google Map Code")]
        public string GoogleMapCode { get; set; }

        [Required(ErrorMessage="Enter Phone Number"), Display(Name="Phone Number")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage="Enter Website")]
        public string Website { get; set; }
    }
}

