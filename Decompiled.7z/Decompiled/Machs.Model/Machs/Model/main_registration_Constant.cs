﻿namespace Machs.Model
{
    using System;

    public class main_registration_Constant : BaseEntity
    {
        public const string ADDRESS = "Address";
        public const string CITY = "City";
        public const string CONFIRMPASSWORD = "ConfirmPassword";
        public const string DATEOFBIRTH = "DateOfBirth";
        public const string DEGREE = "Degree";
        public const string DEPARTMENT = "Department";
        public const string EMAIL = "Email";
        public const string EMAIL_REPLACE_EMAIL = "@@Email";
        public const string EMAIL_REPLACE_NAME = "@@Name";
        public const string EMAIL_REPLACE_PASSWORD = "@@Password";
        public const string EMAIL_SUBJECT = "MACHS Student Login Credentials.";
        public const string INSERTUPDATEDATE = "InsertUpdateDate";
        public const string LASTLOGINDATE = "LastLoginDate";
        public const string LOGIN_CREDIANTIALS_PATH = "LoginCredentials.html";
        public const string Machs_SPROC_MAIN_REGISTRATION_DEL = "sproc_main_registration_del";
        public const string Machs_SPROC_MAIN_REGISTRATION_LSTALL = "sproc_main_registration_lstAll";
        public const string Machs_SPROC_MAIN_REGISTRATION_SEARCH_LSTALL = "sproc_Search_main_registration_lstAll";
        public const string Machs_SPROC_MAIN_REGISTRATION_SEL = "sproc_main_registration_sel";
        public const string Machs_SPROC_MAIN_REGISTRATION_STUDENT_CHANGEPASSWORD = "sproc_main_registration_Student_ChangePassword";
        public const string Machs_SPROC_MAIN_REGISTRATION_STUDENT_LASTLOGINDATE_UPS = "sproc_main_registration_Student_LastLoginDate_ups";
        public const string Machs_SPROC_MAIN_REGISTRATION_STUDENT_SEL_BYEMAILID = "sproc_main_registration_Student_sel_ByEmailId";
        public const string Machs_SPROC_MAIN_REGISTRATION_STUDENT_SEL_BYSTUDENTID = "sproc_main_registration_Student_sel_ByStudentId";
        public const string Machs_SPROC_MAIN_REGISTRATION_UPS = "sproc_main_registration_ups";
        public const string Machs_SPROC_MAIN_STUDENT_LOGIN = "sproc_main_Student_Login";
        public const string NATIONALID = "NationalId";
        public const string NATIONALITY = "Nationality";
        public const string NEWPASSWORD = "NewPassword";
        public const string PASSPORTNUMBER = "PassportNumber";
        public const string PASSWORD = "Password";
        public const string PHONENUMBER = "PhoneNumber";
        public const string PROVINCESTATE = "ProvinceState";
        public const string REGISTRATIONID = "RegistrationId";
        public const string STUDENTFULLNAME = "StudentFullName";
        public const string STUDENTFULLNAMEARABIC = "StudentFullNameArabic";
        public const string STUDENTID = "StudentId";
        public const string USERTYPE = "UserType";
    }
}

