﻿namespace Machs.Model
{
    using System;

    public class main_faculty_research_Constant : BaseEntity
    {
        public const string FACULTYID = "FacultyId";
        public const string Machs_SPROC_MAIN_FACULTY_RESEARCH_DEL = "sproc_main_faculty_research_del";
        public const string Machs_SPROC_MAIN_FACULTY_RESEARCH_LSTALL = "sproc_main_faculty_research_lstAll";
        public const string Machs_SPROC_MAIN_FACULTY_RESEARCH_SEARCH_LSTALL = "sproc_Search_main_faculty_research_lstAll";
        public const string Machs_SPROC_MAIN_FACULTY_RESEARCH_SEL = "sproc_main_faculty_research_sel";
        public const string Machs_SPROC_MAIN_FACULTY_RESEARCH_SEL_BY_FACULTYID = "sproc_main_faculty_research_sel_By_FacultyId";
        public const string Machs_SPROC_MAIN_FACULTY_RESEARCH_UPS = "sproc_main_faculty_research_ups";
        public const string RESEARCHAUTHOR = "ResearchAuthor";
        public const string RESEARCHAUTHORARABIC = "ResearchAuthorArabic";
        public const string RESEARCHID = "ResearchId";
        public const string RESEARCHLINK = "ResearchLink";
        public const string RESEARCHTITLE = "ResearchTitle";
        public const string RESEARCHTITLEARABIC = "ResearchTitleArabic";
        public const string RESEARCHTYPE = "ResearchType";
    }
}

