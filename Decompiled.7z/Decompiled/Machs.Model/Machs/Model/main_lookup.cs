﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_lookup : BaseEntity
    {
        [Required(ErrorMessage="Enter Display Order"), Display(Name="Display Order")]
        public int DisplayOrder { get; set; }

        public int LookupId { get; set; }

        [Display(Name="Lookup Text"), Required(ErrorMessage="Enter Lookup Text")]
        public string LookupText { get; set; }

        [Required(ErrorMessage="Enter Lookup Text in Arabic"), Display(Name="Lookup Text in Arabic")]
        public string LookupTextArabic { get; set; }

        [Display(Name="Lookup Type"), Required(ErrorMessage="Enter Lookup Type")]
        public string LookupType { get; set; }

        [Required(ErrorMessage="Enter Lookup Value"), Display(Name="Lookup Value")]
        public string LookupValue { get; set; }
    }
}

