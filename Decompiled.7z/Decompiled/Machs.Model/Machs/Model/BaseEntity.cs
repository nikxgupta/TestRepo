﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class BaseEntity
    {
        public string ComputerName { get; set; }

        public string CreatedBy { get; set; }

        public int CreatedById { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreationMode { get; set; }

        public string FormId { get; set; }

        [Display(Name="IP Address")]
        public string IpAddress { get; set; }

        public string LastModifiedby { get; set; }

        public int LastModifiedById { get; set; }

        public DateTime LastModifiedDate { get; set; }

        public string LastUpdationMode { get; set; }

        public int NoOfPages { get; set; }

        public int PageIndex { get; set; }

        public int PageSize { get; set; }

        public string sort { get; set; }

        public string sortdir { get; set; }

        public string SortExp { get; set; }

        public int TotalCount { get; set; }

        public string UpdateMode { get; set; }

        public string WhereClause { get; set; }
    }
}

