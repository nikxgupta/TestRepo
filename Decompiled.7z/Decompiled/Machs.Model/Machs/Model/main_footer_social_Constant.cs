﻿namespace Machs.Model
{
    using System;

    public class main_footer_social_Constant : BaseEntity
    {
        public const string DISPLAYORDER = "Displayorder";
        public const string FOOTERSOCIALID = "FooterSocialId";
        public const string ICONIMAGEPATH = "IconImagePath";
        public const string ISHIDE = "IsHide";
        public const string LINKPATH = "LinkPath";
        public const string LINKTEXT = "LinkText";
        public const string LINKTEXTARABIC = "LinkTextArabic";
        public const string Machs_SPROC_MAIN_FOOTER_SOCIAL_DEl = "sproc_main_footer_social_del";
        public const string Machs_SPROC_MAIN_FOOTER_SOCIAL_LSTALL = "sproc_main_footer_social_lstAll";
        public const string Machs_SPROC_MAIN_FOOTER_SOCIAL_SEL = "sproc_main_footer_social_sel";
        public const string Machs_SPROC_MAIN_FOOTER_SOCIAL_UPS = "sproc_main_footer_social_ups";
    }
}

