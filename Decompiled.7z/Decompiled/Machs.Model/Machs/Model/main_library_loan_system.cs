﻿namespace Machs.Model
{
    using Machs.Common.BookLibrary;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_library_loan_system : BaseEntity
    {
        public string Author { get; set; }

        public string BookAvailbleOn { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.BookLibrary.BookLibrary), ErrorMessageResourceName="ReqBookLoanFromDate")]
        public DateTime? BookLoanFromDate { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.BookLibrary.BookLibrary), ErrorMessageResourceName="ReqBookLoanToDate")]
        public DateTime? BookLoanToDate { get; set; }

        public string BookPeriodicalsTitle { get; set; }

        public DateTime CurrentDate { get; set; }

        public string DelayPenalties { get; set; }

        public string Email { get; set; }

        [DisplayFormat(DataFormatString="{0:dd-MMM-yyyy}")]
        public DateTime? FromDate { get; set; }

        public DateTime FutureBookDate { get; set; }

        public int? LibraryBooksId { get; set; }

        public int LibraryLoanId { get; set; }

        public int? QuantityAfterLoan { get; set; }

        public string SerialNumber { get; set; }

        public string StudentFullName { get; set; }

        public string StudentFullNameArabic { get; set; }

        public int? StudentId { get; set; }

        [DisplayFormat(DataFormatString="{0:dd-MMM-yyyy}")]
        public DateTime? ToDate { get; set; }

        public string UserType { get; set; }
    }
}

