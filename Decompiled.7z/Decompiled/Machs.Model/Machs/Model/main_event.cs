﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_event : BaseEntity
    {
        [Display(Name="Is Active")]
        public bool IsActive { get; set; }

        [Display(Name="Show Read More")]
        public bool IsReadMore { get; set; }

        [Display(Name="Show on Home Page")]
        public bool IsShowOnHomePage { get; set; }

        [Display(Name="Associated Department"), Required(ErrorMessage="Please select Department")]
        public int MenuId { get; set; }

        [Display(Name="Associated Department")]
        public string MenuName { get; set; }

        [Required(ErrorMessage="Select Event Date"), Display(Name="Event Date")]
        public DateTime? MEventDate { get; set; }

        [Display(Name="Event Description")]
        public string MEventDescription { get; set; }

        [Display(Name="Event Description in Arabic")]
        public string MEventDescriptionArabic { get; set; }

        public int MEventId { get; set; }

        [Required(ErrorMessage="Enter Event Title"), Display(Name="Event Title")]
        public string MEventTitle { get; set; }

        [Display(Name="Event Title in Arabic"), Required(ErrorMessage="Enter Event Title in Arabic")]
        public string MEventTitleArabic { get; set; }

        [Display(Name="Event Title Image")]
        public string MEventTitleImage { get; set; }

        public string Month { get; set; }

        public HttpPostedFileBase UploadFile { get; set; }

        public string Year { get; set; }
    }
}

