﻿namespace Machs.Model
{
    using System;

    public class main_downloads_Constant : BaseEntity
    {
        public const string DOCUMENTTITLE = "DocumentTitle";
        public const string DOCUMENTTITLEARABIC = "DocumentTitleArabic";
        public const string DOCUMENTUPLOADPATH1 = "DocumentUploadPath1";
        public const string DOWNLOADSID = "DownloadsId";
        public const string ISHIDE = "IsHide";
        public const string Machs_SPROC_MAIN_DOWNLOADS_DEL = "sproc_main_downloads_del";
        public const string Machs_SPROC_MAIN_DOWNLOADS_LSTALL = "sproc_main_downloads_lstAll";
        public const string Machs_SPROC_MAIN_DOWNLOADS_SEARCH_LSTALL = "sproc_Search_main_downloads_lstAll";
        public const string Machs_SPROC_MAIN_DOWNLOADS_SEL = "sproc_main_downloads_sel";
        public const string Machs_SPROC_MAIN_DOWNLOADS_UPS = "sproc_main_downloads_ups";
        public const string MENUID = "MenuId";
        public const string MENUNAME = "MenuName";
    }
}

