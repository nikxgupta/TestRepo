﻿namespace Machs.Model
{
    using System;

    public class main_faculty_publication_Constant : BaseEntity
    {
        public const string FACULTYID = "FacultyId";
        public const string Machs_SPROC_MAIN_FACULTY_PUBLICATION_DEL = "sproc_main_faculty_publication_del";
        public const string Machs_SPROC_MAIN_FACULTY_PUBLICATION_LSTALL = "sproc_main_faculty_publication_lstAll";
        public const string Machs_SPROC_MAIN_FACULTY_PUBLICATION_SEARCH_LSTALL = "sproc_Search_main_faculty_publication_lstAll";
        public const string Machs_SPROC_MAIN_FACULTY_PUBLICATION_SEL = "sproc_main_faculty_publication_sel";
        public const string Machs_SPROC_MAIN_FACULTY_PUBLICATION_SEL_BY_FACULTYID = "sproc_main_faculty_publication_sel_By_FacultyId";
        public const string Machs_SPROC_MAIN_FACULTY_PUBLICATION_UPS = "sproc_main_faculty_publication_ups";
        public const string PUBLICATIONID = "PublicationId";
        public const string PUBLICATIONNAME = "PublicationName";
        public const string PUBLICATIONNAMEARABIC = "PublicationNameArabic";
    }
}

