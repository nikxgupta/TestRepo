﻿namespace Machs.Model
{
    using System;

    public class main_library_Constant : BaseEntity
    {
        public const string AUTHOR = "Author";
        public const string BOOKAVAILABILITY = "BookAvailability";
        public const string BOOKCATEGORY = "BookCategory";
        public const string BOOKLOANFROMDATE = "BookLoanFromDate";
        public const string BOOKLOANTODATE = "BookLoanToDate";
        public const string BOOKPERIODICALSTITLE = "BookPeriodicalsTitle";
        public const string CLASS = "Class";
        public const string CURRENTDATE = "CurrentDate";
        public const string DELAYPENALTIES = "DelayPenalties";
        public const string EDITION = "Edition";
        public const string ISSUEDATE = "IssueDate";
        public const string LIBRARYBOOKSID = "LibraryBooksId";
        public const string LIBRARYLOANID = "LibraryLoanId";
        public const string Machs_SPROC_MAIN_LIBRARY_DEL = "sproc_main_library_del";
        public const string Machs_SPROC_MAIN_LIBRARY_LSTALL = "sproc_main_library_lstAll";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL = "sproc_main_library_sel";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL_FUTUREBOOKHISTORY = "sproc_main_library_sel_FutureBookHistory";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL_FUTUREBOOKS = "sproc_main_library_sel_FutureBooks";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL_PASTBOOK = "sproc_main_library_sel_PastBook";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL_PASTBOOKHISTORY = "sproc_main_library_sel_PastBookHistory";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL_PRESENTBOOK = "sproc_main_library_sel_PresentBook";
        public const string Machs_SPROC_MAIN_LIBRARY_SEL_PRESENTBOOKHISTORY = "sproc_main_library_sel_PresentBookHistory";
        public const string Machs_SPROC_MAIN_LIBRARY_UPS = "sproc_main_library_ups";
        public const string Machs_SPROC_MAIN_LIBRARY_UPS_QUANTITYWITHLIBRARY = "sproc_main_library_ups_QuantityWithLibrary";
        public const string QUANTITY = "Quantity";
        public const string QUANTITYWITHLIBRARY = "QuantityWithLibrary";
        public const string SERIALNUMBER = "SerialNumber";
        public const string STUDENTFULLNAME = "StudentFullName";
        public const string STUDENTID = "StudentID";
        public const string SUBCLASS = "SubClass";
        public const string YEAR = "Year";
    }
}

