﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_downloads : BaseEntity
    {
        [Display(Name="Department Name")]
        public string DepartmentName { get; set; }

        [Display(Name="Document Title"), Required(ErrorMessage="Enter Document Title ")]
        public string DocumentTitle { get; set; }

        [Display(Name="Document Title in  Arabic"), Required(ErrorMessage="Enter Document Title in  Arabic")]
        public string DocumentTitleArabic { get; set; }

        [Display(Name="Document 1 Upload Path ")]
        public string DocumentUploadPath1 { get; set; }

        public int DownloadsId { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        [Display(Name="Department")]
        public int MenuId { get; set; }

        [Display(Name="Parent Name")]
        public string MenuName { get; set; }

        public HttpPostedFileBase UploadFilePath1 { get; set; }

        public HttpPostedFileBase UploadFilePath2 { get; set; }
    }
}

