﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_library : BaseEntity
    {
        [Required(ErrorMessage="Enter Book Author")]
        public string Author { get; set; }

        [Display(Name="Is Book Available")]
        public bool BookAvailability { get; set; }

        [Display(Name="Book Category")]
        public string BookCategory { get; set; }

        public DateTime BookLoanFromDate { get; set; }

        public DateTime BookLoanToDate { get; set; }

        [Required(ErrorMessage="Enter Book/Periodicals Title"), Display(Name="Book/Periodicals Title")]
        public string BookPeriodicalsTitle { get; set; }

        public string Class { get; set; }

        public DateTime CurrentDate { get; set; }

        [Display(Name="Delay Penalties")]
        public string DelayPenalties { get; set; }

        public string Edition { get; set; }

        [Display(Name="Issue Date")]
        public string IssueDate { get; set; }

        public int LibraryBooksId { get; set; }

        public int LibraryLoanId { get; set; }

        [Required(ErrorMessage="Enter Quantity")]
        public int Quantity { get; set; }

        [Display(Name="Quantity With Library")]
        public int? QuantityWithLibrary { get; set; }

        [Display(Name="Serial Number")]
        public string SerialNumber { get; set; }

        public string StudentFullName { get; set; }

        public int StudentID { get; set; }

        [Display(Name="Sub Class ")]
        public string SubClass { get; set; }

        public string Year { get; set; }
    }
}

