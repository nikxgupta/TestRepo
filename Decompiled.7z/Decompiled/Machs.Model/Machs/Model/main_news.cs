﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_news : BaseEntity
    {
        [Display(Name="Is Active")]
        public bool IsActive { get; set; }

        [Display(Name="Show on Home Page")]
        public bool IsShowOnHomePage { get; set; }

        [Display(Name="Link Path1")]
        public string LinkPath1 { get; set; }

        [Display(Name="Link Path2")]
        public string LinkPath2 { get; set; }

        [Display(Name="Link Text1")]
        public string LinkText1 { get; set; }

        [Display(Name="Link Text2")]
        public string LinkText2 { get; set; }

        [Display(Name="Link Text1 in Arabic")]
        public string LinkTextArabic1 { get; set; }

        [Display(Name="Link Text2 in Arabic")]
        public string LinkTextArabic2 { get; set; }

        public int MenuId { get; set; }

        [Display(Name="Associated Department")]
        public string MenuName { get; set; }

        [Display(Name="News Description"), Required(ErrorMessage="Enter News Description")]
        public string MNewsDescription { get; set; }

        [Display(Name="News Description in Arabic"), Required(ErrorMessage="Enter News Description in Arabic")]
        public string MNewsDescriptionArabic { get; set; }

        public int MNewsId { get; set; }

        [Display(Name="News Title"), Required(ErrorMessage="Enter News Title")]
        public string MNewsTitle { get; set; }

        [Required(ErrorMessage="Enter News Title in Arabic"), Display(Name="News Title in Arabic")]
        public string MNewsTitleArabic { get; set; }

        public DateTime? NewsDate { get; set; }

        [Display(Name="News Image1")]
        public string NewsImage1 { get; set; }

        [Display(Name="News Image2")]
        public string NewsImage2 { get; set; }

        [Display(Name="News Image3")]
        public string NewsImage3 { get; set; }

        [Display(Name="News Image4")]
        public string NewsImage4 { get; set; }

        [Display(Name="News Title Image")]
        public string TitleImage { get; set; }

        public HttpPostedFileBase UploadFile { get; set; }

        public HttpPostedFileBase UploadFileForNewsImage1 { get; set; }

        public HttpPostedFileBase UploadFileForNewsImage2 { get; set; }

        public HttpPostedFileBase UploadFileForNewsImage3 { get; set; }

        public HttpPostedFileBase UploadFileForNewsImage4 { get; set; }
    }
}

