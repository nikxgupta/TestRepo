﻿namespace Machs.Model
{
    using System;
    using System.Runtime.CompilerServices;

    public class main_menu_data : BaseEntity
    {
        public string DataArabic { get; set; }

        public string DataEnglish { get; set; }

        public int Language { get; set; }

        public int MenuDataId { get; set; }

        public int MenuId { get; set; }

        public string MenuName { get; set; }

        public string MenuNameArabic { get; set; }

        public int? ParentId { get; set; }
    }
}

