﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_menu : BaseEntity
    {
        [Required(ErrorMessage="Enter Action Name"), Display(Name="Action Name")]
        public string ActionName { get; set; }

        [Required(ErrorMessage="Enter Controller Name "), Display(Name="Controller Name")]
        public string ControllerName { get; set; }

        [Display(Name="Display order"), Required(ErrorMessage="Enter Display order")]
        public int? Displayorder { get; set; }

        [Display(Name="Is Custom")]
        public bool IsCustom { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        public bool IsMenuAvailable { get; set; }

        [Display(Name="Is Template")]
        public bool IsTemplate { get; set; }

        [Display(Name="Link Path")]
        public string LinkPath { get; set; }

        public int MenuId { get; set; }

        [Display(Name="Menu Name"), Required(ErrorMessage="Enter Menu Name")]
        public string MenuName { get; set; }

        [Required(ErrorMessage="Enter Menu Name in Arabic"), Display(Name="Menu Name Arabic")]
        public string MenuNameArabic { get; set; }

        public int NoOfChilds { get; set; }

        [Display(Name="Parent")]
        public int? ParentId { get; set; }

        public string ParentName { get; set; }

        public string ParentNameArabic { get; set; }

        public int? RoleId { get; set; }

        public int RoleMenuId { get; set; }
    }
}

