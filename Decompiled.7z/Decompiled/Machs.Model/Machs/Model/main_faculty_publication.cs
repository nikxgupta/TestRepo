﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_faculty_publication : BaseEntity
    {
        public string divId { get; set; }

        public int? FacultyId { get; set; }

        public int PublicationId { get; set; }

        [Display(Name="Publication Name")]
        public string PublicationName { get; set; }

        [Display(Name="Publication Name Arabic")]
        public string PublicationNameArabic { get; set; }
    }
}

