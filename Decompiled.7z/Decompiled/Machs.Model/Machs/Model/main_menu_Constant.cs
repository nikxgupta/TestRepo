﻿namespace Machs.Model
{
    using System;

    public class main_menu_Constant : BaseEntity
    {
        public const string ACTIONNAME = "ActionName";
        public const string CONTROLLERNAME = "ControllerName";
        public const string DISPLAYORDER = "Displayorder";
        public const string ISCUSTOM = "IsCustom";
        public const string ISHIDE = "IsHide";
        public const string ISMENUAVAILABLE = "IsMenuAvailable";
        public const string ISTEMPLATE = "IsTemplate";
        public const string LINKPATH = "LinkPath";
        public const string Machs_SPROC_MAIN_MENU_ACAD = "sproc_main_menu_Acad";
        public const string Machs_SPROC_MAIN_MENU_ACAD_ADMIN = "sproc_main_menu_Acad_Admin";
        public const string MACHS_SPROC_MAIN_MENU_DEL = "sproc_main_menu_del";
        public const string MACHS_SPROC_MAIN_MENU_LST = "sproc_main_menu_lst";
        public const string Machs_SPROC_MAIN_MENU_LSTALL = "sproc_main_menu_lstAll";
        public const string MACHS_SPROC_MAIN_MENU_LSTALL_INFO = "sproc_main_menu_LstAll_Info";
        public const string MACHS_SPROC_MAIN_MENU_LSTALL_INFOBYMENUID = "sproc_main_menu_LstAll_InfoByMenuID";
        public const string MACHS_SPROC_MAIN_MENU_LSTALL_INFOBYMENUIDANDPARENTID = "sproc_main_menu_LstAll_InfoByMenuIDAndParentId";
        public const string Machs_SPROC_MAIN_MENU_LSTALL_SITEMAP = "sproc_main_menu_LstAll_SiteMap";
        public const string Machs_SPROC_MAIN_MENU_LSTALL_TREEVIEW = "sproc_main_menu_LstAll_TreeView";
        public const string Machs_SPROC_MAIN_MENU_SEARCH_LSTALL = "sproc_Search_main_menu_lstAll";
        public const string Machs_SPROC_MAIN_MENU_SEL = "sproc_main_menu_sel";
        public const string Machs_SPROC_MAIN_MENU_UPS = "sproc_main_menu_ups";
        public const string MENUID = "MenuId";
        public const string MENUNAME = "MenuName";
        public const string MENUNAMEARABIC = "MenuNameArabic";
        public const string PARENTID = "ParentId";
        public const string ROLEID = "RoleId";
        public const string ROLEMENUID = "RoleMenuId";
        public const string SPROC_MAIN_GET_MENU_BY_ROLEID = "sproc_main_Get_menu_By_RoleId";
        public const string SPROC_MAIN_MENU_GETPARENTCHILD = "sproc_main_menu_GetParentChild";
        public const string SPROC_MAIN_MENU_GETPARENTNAME = "sproc_main_menu_GetParentName";
        public const string SPROC_MAIN_MENU_LSTALL_CUSTOM = "sproc_main_menu_lstAll_Custom";
        public const string SPROC_MAIN_MENU_SEL_FORCUSTOM = "sproc_main_menu_sel_ForCustom";
        public const string SPROC_MAIN_MENU_UPS_CUSTOM = "sproc_main_menu_ups_Custom";
        public const string SPROC_MAIN_ROLE_MENU_UPS = "sproc_main_role_menu_ups";
        public const string SPROC_MAIN_ROLE_MENUS_LINKING_LSTALL = "sproc_main_role_menus_linking_lstall";
    }
}

