﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_role : BaseEntity
    {
        public int AssociatedUser { get; set; }

        public int RoleId { get; set; }

        [Required(ErrorMessage="Enter Role Name"), Display(Name="Role Name")]
        public string RoleName { get; set; }
    }
}

