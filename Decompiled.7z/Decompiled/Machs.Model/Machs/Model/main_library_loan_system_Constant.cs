﻿namespace Machs.Model
{
    using System;

    public class main_library_loan_system_Constant : BaseEntity
    {
        public const string BOOKAVAILBLEON = "BookAvailbleOn";
        public const string BOOKLOANFROMDATE = "BookLoanFromDate";
        public const string BOOKLOANTODATE = "BookLoanToDate";
        public const string CURRENTDATE = "CurrentDate";
        public const string FUTUREBOOKDATE = "FutureBookDate";
        public const string LIBRARYBOOKSID = "LibraryBooksId";
        public const string LIBRARYLOANID = "LibraryLoanId";
        public const string Machs_SPROC_MAIN_LIBRARY_CHECKUSERHASBOOK = "sproc_main_library_checkUserHasBook";
        public const string Machs_sproc_MAIN_LIBRARY_LOAN_SYSTEM_DEL = "sproc_main_library_loan_system_del";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_SYSTEM_DOWNLOADRECEIPT = "sproc_main_library_loan_system_downloadReceipt";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_SYSTEM_GETFUTUREBOOKDATE = "sproc_main_library_loan_system_GetFutureBookDate";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_SYSTEM_LSTALL = "sproc_main_library_loan_system_lstAll";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_SYSTEM_SEARCH_LSTALL = "sproc_Search_main_library_loan_system_lstAll";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_SYSTEM_SEL = "sproc_main_library_loan_system_sel";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_SYSTEM_UPS = "sproc_main_library_loan_system_ups";
        public const string Machs_SPROC_MAIN_LIBRARY_LOAN_UPDATETODATEFORRENEW = "sproc_main_library_loan_UpdateTodateForRenew";
        public const string QUANTITYAFTERLOAN = "QuantityAfterLoan";
        public const string STUDENTID = "StudentId";
    }
}

