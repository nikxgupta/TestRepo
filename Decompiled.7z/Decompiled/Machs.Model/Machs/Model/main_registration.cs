﻿namespace Machs.Model
{
    using Machs.Common.Login;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_registration : BaseEntity
    {
        public string Address { get; set; }

        public string City { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqConfirmPassword"), DataType(DataType.Password), System.Web.Mvc.Compare("NewPassword", ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="PasswordNotMatching")]
        public string ConfirmPassword { get; set; }

        public DateTime? DateOfBirth { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqDegree")]
        public string Degree { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqDepartment")]
        public string Department { get; set; }

        [Display(Name="Email Id"), Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqEmail"), RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage="Please Enter Valid Email Address.")]
        public string Email { get; set; }

        public DateTime InsertUpdateDate { get; set; }

        public DateTime LastLoginDate { get; set; }

        [Display(Name="National Id")]
        public string NationalId { get; set; }

        [Required(ErrorMessage="Enter Nationality ")]
        public string Nationality { get; set; }

        [StringLength(50, MinimumLength=7), Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqNewPassword"), DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Display(Name="Passport Number")]
        public string PassportNumber { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqPassword")]
        public string Password { get; set; }

        public string PhoneNumber { get; set; }

        public string ProvinceState { get; set; }

        public int RegistrationId { get; set; }

        [Required(ErrorMessageResourceType=typeof(Machs.Common.Login.Login), ErrorMessageResourceName="ReqFullName"), Display(Name="Full Name ")]
        public string StudentFullName { get; set; }

        [Display(Name="Full Name in Arabic ")]
        public string StudentFullNameArabic { get; set; }

        [Required(ErrorMessage="Enter User Id"), Display(Name="User Id")]
        public int? StudentId { get; set; }

        [Display(Name="User Type"), Required(ErrorMessage="Select User Type")]
        public string UserType { get; set; }
    }
}

