﻿namespace Machs.Model
{
    using System;

    public class main_footer_contactus_Constant : BaseEntity
    {
        public const string ADDRESS = "Address";
        public const string EMAILADDRESS = "EmailAddress";
        public const string FOOTERCONTACTUSID = "FooterContactUsId";
        public const string GOOGLEMAPCODE = "GoogleMapCode";
        public const string Machs_SPROC_MAIN_FOOTER_CONTACTUS_LSTALL = "sproc_main_footer_contactus_lstAll";
        public const string Machs_SPROC_MAIN_FOOTER_CONTACTUS_SEL = "sproc_main_footer_contactus_sel";
        public const string Machs_SPROC_MAIN_FOOTER_CONTACTUS_UPS = "sproc_main_footer_contactus_ups";
        public const string PHONENUMBER = "PhoneNumber";
        public const string WEBSITE = "Website";
    }
}

