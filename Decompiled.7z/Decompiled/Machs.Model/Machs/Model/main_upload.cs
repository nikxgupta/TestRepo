﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_upload : BaseEntity
    {
        [Display(Name="Asset URL")]
        public string UploadFile { get; set; }

        [Required(ErrorMessage="Enter Upload Asset"), Display(Name="Upload Asset")]
        public HttpPostedFileBase UploadFileBytes { get; set; }

        public int UploadId { get; set; }

        [Required(ErrorMessage="Enter Asset Name"), Display(Name="File Asset Name")]
        public string UploadName { get; set; }
    }
}

