﻿namespace Machs.Model
{
    using System;

    public class main_small_home_icon_Constant : BaseEntity
    {
        public const string ACTIONNAME = "ActionName";
        public const string CONTROLLERNAME = "ControllerName";
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string DISPLAYORDER = "Displayorder";
        public const string ICONIMAGEPATH = "IconImagePath";
        public const string ISCUSTOM = "IsCustom";
        public const string ISHIDE = "IsHide";
        public const string ISTEMPLATE = "IsTemplate";
        public const string LANGUAGE = "Language";
        public const string LINKPATH = "LinkPath";
        public const string Machs_SPROC_MAIN_SMALL_HOME_ICON_DEL = "sproc_main_small_home_icon_del";
        public const string Machs_SPROC_MAIN_SMALL_HOME_ICON_LSTALL = "sproc_main_small_home_icon_lstAll";
        public const string Machs_SPROC_MAIN_SMALL_HOME_ICON_SEARCH_LSTALL = "sproc_Search_main_small_home_icon_lstAll";
        public const string Machs_SPROC_MAIN_SMALL_HOME_ICON_SEL = "sproc_main_small_home_icon_sel";
        public const string Machs_SPROC_MAIN_SMALL_HOME_ICON_UPS = "sproc_main_small_home_icon_ups";
        public const string SMALLHOMEICONID = "SmallHomeIconId";
        public const string TITLE = "Title";
        public const string TITLEARABIC = "TitleArabic";
    }
}

