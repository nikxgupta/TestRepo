﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_footer_help : BaseEntity
    {
        public string ActionName { get; set; }

        public string ControllerName { get; set; }

        public string DataArabic { get; set; }

        public string DataEnglish { get; set; }

        [Required(ErrorMessage="Enter Display Order"), Display(Name="Display Order")]
        public int Displayorder { get; set; }

        public int FooterHelpId { get; set; }

        [Display(Name="Is Custom")]
        public bool IsCustom { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        [Display(Name="Is Template")]
        public bool IsTemplate { get; set; }

        public int Language { get; set; }

        [Display(Name="Link Path")]
        public string LinkPath { get; set; }

        [Required(ErrorMessage="Enter Title")]
        public string Title { get; set; }

        [Display(Name="Title in Arabic"), Required(ErrorMessage="Enter Title in Arabic")]
        public string TitleArabic { get; set; }
    }
}

