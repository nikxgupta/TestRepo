﻿namespace Machs.Model
{
    using System;

    public class main_CAC_block_Constant : BaseEntity
    {
        public const string CACBLOCKID = "CACBlockId";
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string ICONIMAGEPATH = "IconImagePath";
        public const string ISHIDE = "IsHide";
        public const string ISTEMPLATE = "IsTemplate";
        public const string LANGUAGE = "Language";
        public const string LINKPATH = "LinkPath";
        public const string Machs_SPROC_MAIN_CAC_BLOCK_DEL = "sproc_main_CAC_block_del";
        public const string Machs_SPROC_MAIN_CAC_BLOCK_LSTALL = "sproc_main_CAC_block_lstAll";
        public const string Machs_SPROC_MAIN_CAC_BLOCK_SEL = "sproc_main_CAC_block_sel";
        public const string Machs_SPROC_MAIN_CAC_BLOCK_UPS = "sproc_main_CAC_block_ups";
        public const string SHORTDESCRIPTION = "ShortDescription";
        public const string SHORTDESCRIPTIONARABIC = "ShortDescriptionArabic";
        public const string TITLE = "Title";
        public const string TITLEARABIC = "TitleArabic";
    }
}

