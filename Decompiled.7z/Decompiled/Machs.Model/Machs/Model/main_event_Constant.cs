﻿namespace Machs.Model
{
    using System;

    public class main_event_Constant : BaseEntity
    {
        public const string ISACTIVE = "IsActive";
        public const string ISREADMORE = "IsReadMore";
        public const string ISSHOWONHOMEPAGE = "IsShowOnHomePage";
        public const string Machs_SPROC_MAIN_EVENT_DEL = "sproc_main_event_del";
        public const string Machs_SPROC_MAIN_EVENT_LSTALL = "sproc_main_event_lstAll";
        public const string Machs_SPROC_MAIN_EVENT_SEARCH_LSTALL = "sproc_main_event_lstAll";
        public const string Machs_SPROC_MAIN_EVENT_SEL = "sproc_main_event_sel";
        public const string Machs_SPROC_MAIN_EVENT_UPS = "sproc_main_event_ups";
        public const string MENUID = "MenuId";
        public const string MEVENTDATE = "MEventDate";
        public const string MEVENTDESCRIPTION = "MEventDescription";
        public const string MEVENTDESCRIPTIONARABIC = "MEventDescriptionArabic";
        public const string MEVENTID = "MEventId";
        public const string MEVENTTITLE = "MEventTitle";
        public const string MEVENTTITLEARABIC = "MEventTitleArabic";
        public const string MEVENTTITLEIMAGE = "MEventTitleImage";
        public const string MONTH = "Month";
        public const string SPROC_MAIN_EVENTS_SHOW_PUBLIC = "sproc_main_events_show_public";
        public const string SPROC_MAIN_EVENTS_SHOW_PUBLIC_BYDAY = "sproc_main_events_show_public_byDay";
        public const string SPROC_MAIN_EVENTS_SHOW_PUBLIC_BYMONTH = "sproc_main_events_show_public_byMonth";
        public const string SPROC_MAIN_EVENTS_SHOW_PUBLIC_BYMONTH_ALL = "sproc_main_events_show_public_byMonth_All";
        public const string YEAR = "Year";
    }
}

