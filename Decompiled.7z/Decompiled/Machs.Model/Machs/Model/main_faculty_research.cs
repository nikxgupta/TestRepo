﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_faculty_research : BaseEntity
    {
        public string divId { get; set; }

        public int? FacultyId { get; set; }

        [Display(Name="Research Author")]
        public string ResearchAuthor { get; set; }

        [Display(Name="Research Author Arabic")]
        public string ResearchAuthorArabic { get; set; }

        public int ResearchId { get; set; }

        [Display(Name="Link")]
        public string ResearchLink { get; set; }

        [Display(Name="Research Title")]
        public string ResearchTitle { get; set; }

        [Display(Name="Research Title Arabic")]
        public string ResearchTitleArabic { get; set; }

        [Display(Name="Research Type")]
        public string ResearchType { get; set; }
    }
}

