﻿namespace Machs.Model
{
    using System;

    public class main_help_faq_Constant : BaseEntity
    {
        public const string ANSWER = "Answer";
        public const string ANSWERARABIC = "AnswerArabic";
        public const string DISPLAYORDER = "Displayorder";
        public const string HELPFAQID = "HelpFAQId";
        public const string ISHIDE = "IsHide";
        public const string Machs_SPROC_MAIN_HELP_FAQ_DEL = "sproc_main_help_faq_del";
        public const string Machs_SPROC_MAIN_HELP_FAQ_LSTALL = "sproc_main_help_faq_lstAll";
        public const string Machs_SPROC_MAIN_HELP_FAQ_SEL = "sproc_main_help_faq_sel";
        public const string Machs_SPROC_MAIN_HELP_FAQ_UPS = "sproc_main_help_faq_ups";
        public const string QUESTION = "Question";
        public const string QUESTIONARABIC = "QuestionArabic";
    }
}

