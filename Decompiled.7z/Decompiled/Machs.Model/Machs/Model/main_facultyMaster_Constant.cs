﻿namespace Machs.Model
{
    using System;

    public class main_facultyMaster_Constant : BaseEntity
    {
        public const string CVUPLOADPATH = "CVUploadPath";
        public const string CVUPLOADPATHARABIC = "CVUploadPathArabic";
        public const string DEPARTMENTNAME = "DepartmentName";
        public const string EMAILADDRESS = "EmailAddress";
        public const string FACULTYID = "FacultyId";
        public const string FACULTYIMAGE = "FacultyImage";
        public const string FACULTYNAME = "FacultyName";
        public const string FACULTYNAMEARABIC = "FacultyNameArabic";
        public const string Machs_SPROC_MAIN_FACULTYMASTER_DEL = "sproc_main_facultyMaster_del";
        public const string Machs_SPROC_MAIN_FACULTYMASTER_LSTALL = "sproc_main_facultyMaster_lstAll";
        public const string Machs_SPROC_MAIN_FACULTYMASTER_SEARCH_LSTALL = "sproc_Search_main_facultyMaster_lstAll";
        public const string Machs_SPROC_MAIN_FACULTYMASTER_SEL = "sproc_main_facultyMaster_sel";
        public const string Machs_SPROC_MAIN_FACULTYMASTER_UPS = "sproc_main_facultyMaster_ups";
        public const string MENUID = "MenuId";
        public const string OFFICELOCATION = "OfficeLocation";
        public const string PHONEEXT = "PhoneExt";
        public const string PHONENUMBER = "PhoneNumber";
        public const string POSITION = "Position";
        public const string POSITIONARABIC = "PositionArabic";
        public const string SUBJECTSTEACH = "SubjectsTeach";
        public const string SUBJECTSTEACHARABIC = "SubjectsTeachArabic";
        public const string UPLOADCV = "UploadCV";
    }
}

