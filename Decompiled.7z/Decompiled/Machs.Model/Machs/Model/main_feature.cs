﻿namespace Machs.Model
{
    using System;
    using System.Runtime.CompilerServices;

    public class main_feature : BaseEntity
    {
        public string ActionName { get; set; }

        public string ControllerName { get; set; }

        public int? DisplayOrder { get; set; }

        public int FeatureId { get; set; }

        public string FeatureName { get; set; }

        public string FeatureNameArabic { get; set; }

        public int? ParentId { get; set; }
    }
}

