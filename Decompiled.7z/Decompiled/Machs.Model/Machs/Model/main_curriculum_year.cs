﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_curriculum_year : BaseEntity
    {
        public int CurriculumYearId { get; set; }

        [Display(Name="Curriculum Year Name"), Required(ErrorMessage="Enter Curriculum Year Name")]
        public string CurriculumYearName { get; set; }

        [Display(Name="Department Name")]
        public string DepartmentName { get; set; }

        public int? ParentId { get; set; }

        [Display(Name="Year Value"), Required(ErrorMessage="Enter Year Value")]
        public string YearValue { get; set; }
    }
}

