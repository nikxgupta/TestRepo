﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_banner : BaseEntity
    {
        public int BannerId { get; set; }

        public string BannerType { get; set; }

        [Required(ErrorMessage="Enter Description"), Display(Name="Description")]
        public string Description { get; set; }

        [Display(Name="Description in Arabic")]
        public string DescriptionArabic { get; set; }

        [Required(ErrorMessage="Enter Display Order"), Display(Name="Display Order")]
        public int? DisplayOrder { get; set; }

        [Display(Name="Featured Image")]
        public string FeaturedImage { get; set; }

        [Display(Name="Is CampusLife")]
        public bool IsCampusLife { get; set; }

        [Display(Name=" Show On HomePage")]
        public bool IsHome { get; set; }

        [Display(Name="Is Inactive")]
        public bool IsInactive { get; set; }

        public int MenuId { get; set; }

        [Required(ErrorMessage="Enter Banner Name"), Display(Name="Banner Name")]
        public string Title { get; set; }

        [Display(Name="Banner Name in Arabic")]
        public string TitleArabic { get; set; }

        public HttpPostedFileBase UploadFile { get; set; }
    }
}

