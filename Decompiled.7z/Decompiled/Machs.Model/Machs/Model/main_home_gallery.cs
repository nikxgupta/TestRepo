﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_home_gallery : BaseEntity
    {
        [Display(Name="Gallery Description")]
        public string GalleryDescription { get; set; }

        [Display(Name="Gallery Description in Arabic")]
        public string GalleryDescriptionArabic { get; set; }

        [Display(Name="Gallery Image")]
        public string GalleryImage { get; set; }

        public int HomeGalleryId { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        public HttpPostedFileBase UploadFile { get; set; }
    }
}

