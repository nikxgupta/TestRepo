﻿namespace Machs.Model
{
    using System;

    public class main_user_Constant : BaseEntity
    {
        public const string EMAIL = "Email";
        public const string FIRSTNAME = "FirstName";
        public const string ISACTIVE = "IsActive";
        public const string LASTNAME = "LastName";
        public const string Machs_SPROC_MAIN_USER__SEL_BYEMAILID = "sproc_main_User__sel_ByEmailId";
        public const string Machs_SPROC_MAIN_USER_DEL = "sproc_main_user_del";
        public const string Machs_SPROC_MAIN_USER_LSTALL = "sproc_main_user_lstAll";
        public const string Machs_SPROC_MAIN_USER_SEARCH_LSTALL = "sproc_Search_main_user_lstAll";
        public const string Machs_SPROC_MAIN_USER_SEL = "sproc_main_user_sel";
        public const string Machs_SPROC_MAIN_USER_SELBYCREDENTIALS = "sproc_main_user_selByCredentials";
        public const string Machs_SPROC_MAIN_USER_UPS = "sproc_main_user_ups";
        public const string MIDDLENAME = "MiddleName";
        public const string MOBILENUMBER = "MobileNumber";
        public const string PASSWORD = "Password";
        public const string ROLEID = "RoleId";
        public const string USERID = "UserId";
    }
}

