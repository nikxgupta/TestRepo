﻿namespace Machs.Model
{
    using System;

    public class main_news_Constant : BaseEntity
    {
        public const string ISACTIVE = "IsActive";
        public const string ISSHOWONHOMEPAGE = "IsShowOnHomePage";
        public const string LINKPATH1 = "LinkPath1";
        public const string LINKPATH2 = "LinkPath2";
        public const string LINKTEXT1 = "LinkText1";
        public const string LINKTEXT2 = "LinkText2";
        public const string LINKTEXTARABIC1 = "LinkTextArabic1";
        public const string LINKTEXTARABIC2 = "LinkTextArabic2";
        public const string Machs_SPROC_MAIN_NEWS_DEL = "sproc_main_news_del";
        public const string Machs_SPROC_MAIN_NEWS_LSTALL = "sproc_main_news_lstAll";
        public const string Machs_SPROC_MAIN_NEWS_SEARCH_LSTALL = "sproc_Search_main_news_lstAll";
        public const string Machs_SPROC_MAIN_NEWS_SEL = "sproc_main_news_sel";
        public const string Machs_SPROC_MAIN_NEWS_UPS = "sproc_main_news_ups";
        public const string MENUID = "MenuId";
        public const string MNEWSDESCRIPTION = "MNewsDescription";
        public const string MNEWSDESCRIPTIONARABIC = "MNewsDescriptionArabic";
        public const string MNEWSID = "MNewsId";
        public const string MNEWSTITLE = "MNewsTitle";
        public const string MNEWSTITLEARABIC = "MNewsTitleArabic";
        public const string NEWSDATE = "NewsDate";
        public const string NEWSIMAGE1 = "NewsImage1";
        public const string NEWSIMAGE2 = "NewsImage2";
        public const string NEWSIMAGE3 = "NewsImage3";
        public const string NEWSIMAGE4 = "NewsImage4";
        public const string SPROC_MAIN_NEWS_SHOW_PUBLIC = "sproc_main_news_show_public";
        public const string TITLEIMAGE = "TitleImage";
    }
}

