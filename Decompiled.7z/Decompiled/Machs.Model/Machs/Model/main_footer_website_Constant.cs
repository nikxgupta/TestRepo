﻿namespace Machs.Model
{
    using System;

    public class main_footer_website_Constant : BaseEntity
    {
        public const string ACTIONNAME = "ActionName";
        public const string CONTROLLERNAME = "ControllerName";
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string DISPLAYORDER = "Displayorder";
        public const string FOOTERWEBSITEID = "FooterWebsiteId";
        public const string ISCUSTOM = "IsCustom";
        public const string ISHIDE = "IsHide";
        public const string ISTEMPLATE = "IsTemplate";
        public const string LANGUAGE = "Language";
        public const string LINKPATH = "LinkPath";
        public const string Machs_SPROC_MAIN_FOOTER_WEBSITE_DEL = "sproc_main_footer_website_del";
        public const string Machs_SPROC_MAIN_FOOTER_WEBSITE_LSTALL = "sproc_main_footer_website_lstAll";
        public const string Machs_SPROC_MAIN_FOOTER_WEBSITE_SEARCH_LSTALL = "sproc_Search_main_footer_website_lstAll";
        public const string Machs_SPROC_MAIN_FOOTER_WEBSITE_SEL = "sproc_main_footer_website_sel";
        public const string Machs_SPROC_MAIN_FOOTER_WEBSITE_UPS = "sproc_main_footer_website_ups";
        public const string TITLE = "Title";
        public const string TITLEARABIC = "TitleArabic";
    }
}

