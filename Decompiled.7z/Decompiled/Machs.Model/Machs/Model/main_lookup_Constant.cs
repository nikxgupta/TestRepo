﻿namespace Machs.Model
{
    using System;

    public class main_lookup_Constant : BaseEntity
    {
        public const string DISPLAYORDER = "DisplayOrder";
        public const string LOOKUPID = "LookupId";
        public const string LOOKUPTEXT = "LookupText";
        public const string LOOKUPTEXTARABIC = "LookupTextArabic";
        public const string LOOKUPTYPE = "LookupType";
        public const string LOOKUPVALUE = "LookupValue";
        public const string Machs_SPROC_MAIN_LOOKUP_DEL = "sproc_main_lookup_del";
        public const string Machs_SPROC_MAIN_LOOKUP_GETBOOKCATEGORY = "sproc_main_lookup_GetBookCategory";
        public const string Machs_SPROC_MAIN_LOOKUP_GETUSERTYPE = "sproc_main_lookup_GetUserType";
        public const string Machs_SPROC_MAIN_LOOKUP_LSTALL = "sproc_main_lookup_lstAll";
        public const string Machs_SPROC_MAIN_LOOKUP_SEARCH_LSTALL = "sproc_Search_main_lookup_lstAll";
        public const string Machs_SPROC_MAIN_LOOKUP_SEL = "sproc_main_lookup_sel";
        public const string Machs_SPROC_MAIN_LOOKUP_UPS = "sproc_main_lookup_ups";
    }
}

