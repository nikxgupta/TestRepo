﻿namespace Machs.Model
{
    using System;

    public class main_home_popup_container_Constant : BaseEntity
    {
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string ENDDATE = "EndDate";
        public const string HOMEPOPUPCONTAINERID = "HomePopupContainerId";
        public const string ISSHOW = "IsShow";
        public const string LANGUAGE = "Language";
        public const string LINK1TEXT = "Link1Text";
        public const string LINK1TEXTARABIC = "Link1TextArabic";
        public const string LINK1URL = "Link1URL";
        public const string LINK2TEXT = "Link2Text";
        public const string LINK2TEXTARABIC = "Link2TextArabic";
        public const string LINK2URL = "Link2URL";
        public const string Machs_SPROC_MAIN_HOME_POPUP_CONTAINER_DEL = "sproc_main_home_popup_container_del";
        public const string Machs_SPROC_MAIN_HOME_POPUP_CONTAINER_LSTALL = "sproc_main_home_popup_container_lstAll";
        public const string Machs_SPROC_MAIN_HOME_POPUP_CONTAINER_REMOVEDATA = "sproc_main_home_popup_container_RemoveData";
        public const string Machs_SPROC_MAIN_HOME_POPUP_CONTAINER_SEARCH_LSTALL = "sproc_Search_main_home_popup_container_lstAll";
        public const string Machs_SPROC_MAIN_HOME_POPUP_CONTAINER_SEL = "sproc_main_home_popup_container_sel";
        public const string Machs_SPROC_MAIN_HOME_POPUP_CONTAINER_UPS = "sproc_main_home_popup_container_ups";
        public const string STARTDATE = "StartDate";
    }
}

