﻿namespace Machs.Model
{
    using System;

    public class main_curriculum_year_Constant : BaseEntity
    {
        public const string CURRICULUMYEARID = "CurriculumYearId";
        public const string CURRICULUMYEARNAME = "CurriculumYearName";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_DEL = "sproc_main_curriculum_year_del";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_LSTALL = "sproc_main_curriculum_year_lstAll";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_LSTALL_BYPARENTID = "sproc_main_curriculum_year_lstAll_ByParentId";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_SEARCH_LSTALL = "sproc_Search_main_curriculum_year_lstAll";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_SEL = "sproc_main_curriculum_year_sel";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_SEL_BYYEARVALUE = "sproc_main_curriculum_year_sel_ByYearValue";
        public const string Machs_SPROC_MAIN_CURRICULUM_YEAR_UPS = "sproc_main_curriculum_year_ups";
        public const string PARENTID = "ParentId";
        public const string YEARVALUE = "YearValue";
    }
}

