﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_curriculum_info : BaseEntity
    {
        [Required(ErrorMessage="Select Academic Term"), Display(Name="Academic Term")]
        public string AcademicTerm { get; set; }

        [Display(Name="Course Code"), Required(ErrorMessage="Enter Course Code")]
        public string CourseCode { get; set; }

        [Display(Name="Course Description")]
        public string CourseDescription { get; set; }

        [Display(Name="Course Name"), Required(ErrorMessage="Enter Course Name")]
        public string CourseName { get; set; }

        [Required(ErrorMessage="Enter Credits")]
        public string Credits { get; set; }

        public int CurriculumInfoId { get; set; }

        public int? CurriculumYearId { get; set; }

        public string CurriculumYearName { get; set; }

        [Display(Name="Department Name")]
        public string DepartmentName { get; set; }

        public int? ParentId { get; set; }

        [Display(Name="Prerequisites")]
        public string PreRequisites { get; set; }
    }
}

