﻿namespace Machs.Model
{
    using System;

    public class main_role_features_Constant : BaseEntity
    {
        public const string FEATURE_ID = "FeatureId";
        public const string FEATURE_NAME = "FeatureName";
        public const string FEATUREID = "FeatureId";
        public const string ISADD = "IsAdd";
        public const string ISDELETE = "IsDelete";
        public const string ISEDIT = "IsEdit";
        public const string ISPRINT = "IsPrint";
        public const string ISROLEAVAILABLE = "IsRoleAvailable";
        public const string ISVIEW = "IsView";
        public const string Machs_SPROC_MAIN_GET_FEATURE_BY_ROLEID_LSTALL = "sproc_main_Get_Feature_By_RoleId";
        public const string Machs_SPROC_MAIN_ROLE_FEATURES_LSTALL = "sproc_main_role_features_lstAll";
        public const string Machs_SPROC_MAIN_ROLE_FEATURES_SEARCH_LSTALL = "sproc_Search_main_role_features_lstAll";
        public const string Machs_SPROC_MAIN_ROLE_FEATURES_SEL = "sproc_main_role_features_sel";
        public const string Machs_SPROC_MAIN_ROLE_FEATURES_UPS = "sproc_main_role_features_ups";
        public const string ROLEFEATUREID = "RoleFeatureId";
        public const string ROLEID = "RoleId";
        public const string SPROC_MAIN_ROLE_FEATURE_LINKING_LSTALL = "sproc_main_role_feature_linking_lstall";
        public const string SPROC_MAIN_ROLE_FEATURE_UPS = "sproc_main_role_feature_ups";
    }
}

