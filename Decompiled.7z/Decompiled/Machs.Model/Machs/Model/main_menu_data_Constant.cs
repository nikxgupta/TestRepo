﻿namespace Machs.Model
{
    using System;

    public class main_menu_data_Constant : BaseEntity
    {
        public const string DATAARABIC = "DataArabic";
        public const string DATAENGLISH = "DataEnglish";
        public const string LANGUAGE = "Language";
        public const string Machs_SPROC_MAIN_MENU_DATA_DEL = "sproc_main_menu_data_del";
        public const string Machs_SPROC_MAIN_MENU_DATA_LSTALL = "sproc_main_menu_data_lstAll";
        public const string Machs_SPROC_MAIN_MENU_DATA_SEARCH_LSTALL = "sproc_Search_main_menu_data_lstAll";
        public const string Machs_SPROC_MAIN_MENU_DATA_SEL = "sproc_main_menu_data_sel";
        public const string Machs_SPROC_MAIN_MENU_DATA_UPS = "sproc_main_menu_data_ups";
        public const string MACHS_SPROC_MAIN_MENU_LSTALL_INFOBYMENUID = "sproc_main_menu_LstAll_InfoByMenuID";
        public const string MENUDATAID = "MenuDataId";
        public const string MENUID = "MenuId";
        public const string PARENTID = "ParentId";
    }
}

