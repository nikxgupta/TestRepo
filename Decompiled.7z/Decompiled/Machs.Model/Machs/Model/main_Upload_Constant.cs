﻿namespace Machs.Model
{
    using System;

    public class main_Upload_Constant : BaseEntity
    {
        public const string MACHS_SPROC_MAIN_UPLOAD_DEL = "sproc_main_Upload_del";
        public const string MACHS_SPROC_MAIN_UPLOAD_LSTALL = "sproc_main_Upload_lstAll";
        public const string MACHS_SPROC_MAIN_UPLOAD_SEL = "sproc_main_Upload_sel";
        public const string MACHS_SPROC_MAIN_UPLOAD_UPS = "sproc_main_Upload_ups";
        public const string UPLOADFILE = "UploadFile";
        public const string UPLOADID = "UploadId";
        public const string UPLOADNAME = "UploadName";
    }
}

