﻿namespace Machs.Model
{
    using System;
    using System.Runtime.CompilerServices;

    public class main_role_features : BaseEntity
    {
        public string ActionName { get; set; }

        public string ControllerName { get; set; }

        public int DisplayOrder { get; set; }

        public int? FeatureId { get; set; }

        public string FeatureName { get; set; }

        public bool IsAdd { get; set; }

        public bool IsDelete { get; set; }

        public bool IsEdit { get; set; }

        public bool? IsPrint { get; set; }

        public bool IsRoleAvailable { get; set; }

        public bool? IsView { get; set; }

        public int ParentId { get; set; }

        public int RoleFeatureId { get; set; }

        public int? RoleId { get; set; }

        public string RoleName { get; set; }
    }
}

