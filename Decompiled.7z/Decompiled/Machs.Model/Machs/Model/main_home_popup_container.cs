﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_home_popup_container : BaseEntity
    {
        public string DataArabic { get; set; }

        public string DataEA { get; set; }

        public string DataEnglish { get; set; }

        [Display(Name="End Date"), Required(ErrorMessage="Please select End Date")]
        public DateTime? EndDate { get; set; }

        public string HomePopupContainerId { get; set; }

        [Display(Name="Show Popup on Home Page?")]
        public bool IsShow { get; set; }

        public int Language { get; set; }

        [Display(Name="Link 1 Text")]
        public string Link1Text { get; set; }

        [Display(Name="Link 1 Text Arabic")]
        public string Link1TextArabic { get; set; }

        [Display(Name="Link 1 URL")]
        public string Link1URL { get; set; }

        [Display(Name="Link 2 Text")]
        public string Link2Text { get; set; }

        [Display(Name="Link 2 Text Arabic")]
        public string Link2TextArabic { get; set; }

        [Display(Name="Link 2 URL")]
        public string Link2URL { get; set; }

        [Display(Name="Start Date"), Required(ErrorMessage="Please select Start Date")]
        public DateTime? StartDate { get; set; }

        public HttpPostedFileBase UploadLink1 { get; set; }

        public HttpPostedFileBase UploadLink2 { get; set; }
    }
}

