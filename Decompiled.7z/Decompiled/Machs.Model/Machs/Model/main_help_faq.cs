﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_help_faq : BaseEntity
    {
        [Required(ErrorMessage="Enter Answer")]
        public string Answer { get; set; }

        [Display(Name="Answer in Arabic"), Required(ErrorMessage="Enter Answer in Arabic")]
        public string AnswerArabic { get; set; }

        [Required(ErrorMessage="Enter Display Order"), Display(Name="Display Order")]
        public int? Displayorder { get; set; }

        public int HelpFAQId { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        [Required(ErrorMessage="Enter Question")]
        public string Question { get; set; }

        [Required(ErrorMessage="Enter Question in Arabic"), Display(Name="Question in Arabic")]
        public string QuestionArabic { get; set; }
    }
}

