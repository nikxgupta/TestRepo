﻿namespace Machs.Model
{
    using System;

    public class main_role_Constant : BaseEntity
    {
        public const string Machs_SPROC_MAIN_ROLE_Del = "sproc_main_role_del";
        public const string Machs_SPROC_MAIN_ROLE_LSTALL = "sproc_main_role_lstAll";
        public const string Machs_SPROC_MAIN_ROLE_SEARCH_LSTALL = "sproc_Search_main_role_lstAll";
        public const string Machs_SPROC_MAIN_ROLE_SEL = "sproc_main_role_sel";
        public const string Machs_SPROC_MAIN_ROLE_UPS = "sproc_main_role_ups";
        public const string ROLEID = "RoleId";
        public const string ROLENAME = "RoleName";
    }
}

