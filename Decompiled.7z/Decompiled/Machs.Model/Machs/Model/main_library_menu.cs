﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_library_menu : BaseEntity
    {
        public string ActionName { get; set; }

        public string ControllerName { get; set; }

        public string DataArabic { get; set; }

        public string DataEnglish { get; set; }

        [Display(Name="Display Order"), Required(ErrorMessage="Please Enter Display Order")]
        public int? Displayorder { get; set; }

        [Display(Name="Is Custom")]
        public bool IsCustom { get; set; }

        [Display(Name="Is Hide")]
        public bool IsHide { get; set; }

        [Display(Name="Is Template")]
        public bool IsTemplate { get; set; }

        public int Language { get; set; }

        public int LibraryMenuId { get; set; }

        [Required(ErrorMessage="Please Enter Title")]
        public string Title { get; set; }

        [Display(Name="Title in Arabic"), Required(ErrorMessage="Please Enter Title in Arabic")]
        public string TitleArabic { get; set; }
    }
}

