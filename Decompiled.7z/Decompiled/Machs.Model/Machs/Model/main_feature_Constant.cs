﻿namespace Machs.Model
{
    using System;

    public class main_feature_Constant : BaseEntity
    {
        public const string ACTIONNAME = "ActionName";
        public const string CONTROLLERNAME = "ControllerName";
        public const string DISPLAYORDER = "DisplayOrder";
        public const string FEATUREID = "FeatureId";
        public const string FEATURENAME = "FeatureName";
        public const string FEATURENAMEARABIC = "FeatureNameArabic";
        public const string Machs_SPROC_MAIN_FEATURE_LSTALL = "sproc_main_feature_lstAll";
        public const string Machs_SPROC_MAIN_FEATURE_SEARCH_LSTALL = "sproc_Search_main_feature_lstAll";
        public const string Machs_SPROC_MAIN_FEATURE_SEL = "sproc_main_feature_sel";
        public const string Machs_SPROC_MAIN_FEATURE_UPS = "sproc_main_feature_ups";
        public const string PARENTID = "ParentId";
    }
}

