﻿namespace Machs.Model
{
    using System;

    public class main_faculty_qualification_Constant : BaseEntity
    {
        public const string DEGREE = "Degree";
        public const string DEGREEARABIC = "DegreeArabic";
        public const string DEPARTMENT = "Department";
        public const string DEPARTMENTARABIC = "DepartmentArabic";
        public const string FACULTYID = "FacultyId";
        public const string Machs_SPROC_MAIN_FACULTY_QUALIFICATION_DEL = "sproc_main_faculty_qualification_del";
        public const string Machs_SPROC_MAIN_FACULTY_QUALIFICATION_LSTALL = "sproc_main_faculty_qualification_lstAll";
        public const string Machs_SPROC_MAIN_FACULTY_QUALIFICATION_SEARCH_LSTALL = "sproc_Search_main_faculty_qualification_lstAll";
        public const string Machs_SPROC_MAIN_FACULTY_QUALIFICATION_SEL = "sproc_main_faculty_qualification_sel";
        public const string Machs_SPROC_MAIN_FACULTY_QUALIFICATION_SEL_BY_FACULTYID = "sproc_main_faculty_qualification_sel_By_FacultyId";
        public const string Machs_SPROC_MAIN_FACULTY_QUALIFICATION_UPS = "sproc_main_faculty_qualification_ups";
        public const string PASSINGYEAR = "PassingYear";
        public const string QUALIFICATIONID = "QualificationId";
        public const string UNIVERSITY = "University";
        public const string UNIVERSITYARABIC = "UniversityArabic";
    }
}

