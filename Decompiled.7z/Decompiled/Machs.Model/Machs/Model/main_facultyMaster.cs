﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;
    using System.Web;

    public class main_facultyMaster : BaseEntity
    {
        [Display(Name="CV Upload Path")]
        public string CVUploadPath { get; set; }

        [Display(Name="CV Upload Path in Arabic")]
        public string CVUploadPathArabic { get; set; }

        [Display(Name="Department Name")]
        public string DepartmentName { get; set; }

        [Display(Name="Email Address"), Required(ErrorMessage="Enter Email Address"), RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage="Please Enter Valid Email Address.")]
        public string EmailAddress { get; set; }

        public int FacultyId { get; set; }

        [Display(Name="Faculty Image")]
        public string FacultyImage { get; set; }

        [Display(Name="Faculty Name"), Required(ErrorMessage="Enter Faculty Name"), RegularExpression("^[a-zA-Z ]+$", ErrorMessage="Enter Only  Alphabets For Faculty Name")]
        public string FacultyName { get; set; }

        [Display(Name="Faculty Name Arabic"), Required(ErrorMessage="Enter Faculty Name Arabic")]
        public string FacultyNameArabic { get; set; }

        public HttpPostedFileBase ImageFaculty { get; set; }

        [Display(Name="Department")]
        public int MenuId { get; set; }

        [Display(Name="Associated Department")]
        public string MenuName { get; set; }

        [Display(Name="Office Location")]
        public string OfficeLocation { get; set; }

        [Display(Name="Ext.")]
        public string PhoneExt { get; set; }

        [Display(Name="Phone Number"), StringLength(13, ErrorMessage="Number Should not be greater than 13")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage="Enter Position"), Display(Name="Position")]
        public string Position { get; set; }

        [Display(Name="Position Arabic"), Required(ErrorMessage="Enter Position Arabic")]
        public string PositionArabic { get; set; }

        [Display(Name="Subjects Teach")]
        public string SubjectsTeach { get; set; }

        [Display(Name="Subjects Teach in Arabic")]
        public string SubjectsTeachArabic { get; set; }

        [Display(Name="Upload CV")]
        public HttpPostedFileBase UploadCV { get; set; }

        public HttpPostedFileBase UploadCVArabic { get; set; }
    }
}

