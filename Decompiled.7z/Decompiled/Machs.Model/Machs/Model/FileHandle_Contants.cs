﻿namespace Machs.Model
{
    using System;

    public class FileHandle_Contants
    {
        public const string ASSETUPLOADS = "/AssetUploads";
        public const string BANNER = "/Banners";
        public const string Block = "/Block";
        public const string Downloads = "/Downloads";
        public const string EVENT = "/Event";
        public const string FACULTY = "/Faculty";
        public const string HomeGallery = "/HomeGallery";
        public const string HomePopup = "/HomePopup";
        public const string Icon = "/Icon";
        public const string NEWS = "/News";
        public const string Social = "/Social";
    }
}

