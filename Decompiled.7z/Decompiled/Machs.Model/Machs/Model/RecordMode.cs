﻿namespace Machs.Model
{
    using System;

    public enum RecordMode
    {
        User,
        Service,
        ExcelImport
    }
}

