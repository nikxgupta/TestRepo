﻿namespace Machs.Model
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class main_loggeduser
    {
        public main_user currentuser { get; set; }

        public List<main_role_features> listrolefeatures { get; set; }

        public List<main_menu> listrolemenus { get; set; }
    }
}

