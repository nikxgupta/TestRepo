﻿namespace Machs.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.CompilerServices;

    public class main_faculty_qualification : BaseEntity
    {
        public string Degree { get; set; }

        [Display(Name="Degree Arabic")]
        public string DegreeArabic { get; set; }

        public string Department { get; set; }

        [Display(Name="Department Arabic")]
        public string DepartmentArabic { get; set; }

        public string divId { get; set; }

        public int? FacultyId { get; set; }

        [Display(Name="Passing Year")]
        public string PassingYear { get; set; }

        public int QualificationId { get; set; }

        public string University { get; set; }

        [Display(Name="University Arabic")]
        public string UniversityArabic { get; set; }
    }
}

