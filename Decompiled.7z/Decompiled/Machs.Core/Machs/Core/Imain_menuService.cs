﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_menuService : IService<main_menu>
    {
        int AddEditRoleMenus(main_menu entity);
        int DeleteMenu(main_menu Entity);
        IEnumerable<main_menu> FillAllMenu(main_menu entity);
        IEnumerable<main_menu> GetAllSiteMap(main_menu entity);
        IEnumerable<main_menu> GetAllTreeView(main_menu entity);
        IEnumerable<main_menu> GetCustomMenus(main_menu entity);
        main_menu GetCustomMenusDetailsForUpdate(main_menu obj);
        IEnumerable<main_menu> GetMenusByRoleID(main_menu entity);
        main_menu GetParentDetails(main_menu obj);
        IEnumerable<main_menu> GetParentsChild(main_menu entity);
        IEnumerable<main_menu> GetRoleMenus(main_menu obj);
        IEnumerable<main_menu> ListAllAcademicDepartments(main_menu entity);
        IEnumerable<main_menu> ListAllDepartments(main_menu entity);
        int UpdateCustomMenusDetails(main_menu obj);
    }
}

