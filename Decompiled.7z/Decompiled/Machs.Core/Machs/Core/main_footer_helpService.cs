﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_footer_helpService : Imain_footer_helpService, IService<main_footer_help>
    {
        private Imain_footer_help _main_footer_help = null;

        public main_footer_helpService(Imain_footer_help main_footer_help)
        {
            this._main_footer_help = main_footer_help;
        }

        public int AddEditDelete(main_footer_help entity)
        {
            string[] param = new string[] { "FooterHelpId", "Title", "Language", "TitleArabic", "IsCustom", "IsHide", "IsTemplate", "DataArabic", "DataEnglish", "Displayorder", "LinkPath" };
            object obj2 = this._main_footer_help.ExecuteNonQuery(entity, param, "sproc_main_footer_help_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteHelpFooter(main_footer_help Entity)
        {
            string[] param = new string[] { "FooterHelpId" };
            return this._main_footer_help.ExecuteNonQuery(Entity, param, "sproc_main_footer_help_del");
        }

        public main_footer_help Get(main_footer_help obj)
        {
            string[] param = new string[] { "FooterHelpId" };
            return this._main_footer_help.Get(obj, param, "sproc_main_footer_help_sel");
        }

        public IEnumerable<main_footer_help> GetAll(main_footer_help entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_footer_help.GetAll(entity, param, "sproc_main_footer_help_lstAll");
        }

        public object GetScalar(main_footer_help obj)
        {
            throw new NotImplementedException();
        }
    }
}

