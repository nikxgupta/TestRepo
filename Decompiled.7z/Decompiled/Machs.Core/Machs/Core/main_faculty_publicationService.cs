﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_faculty_publicationService : Imain_faculty_publicationService, IService<main_faculty_publication>
    {
        private Imain_faculty_publication _main_faculty_publication = null;

        public main_faculty_publicationService(Imain_faculty_publication main_faculty_publication)
        {
            this._main_faculty_publication = main_faculty_publication;
        }

        public int AddEditDelete(main_faculty_publication entity)
        {
            string[] param = new string[] { "PublicationId", "FacultyId", "PublicationName", "PublicationNameArabic" };
            return Convert.ToInt32(this._main_faculty_publication.GetScalar(entity, param, "sproc_main_faculty_publication_ups"));
        }

        public int Deletepublication(main_faculty_publication entity)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_faculty_publication.ExecuteNonQuery(entity, param, "sproc_main_faculty_publication_del");
        }

        public main_faculty_publication Get(main_faculty_publication obj)
        {
            string[] param = new string[] { "PublicationId" };
            return this._main_faculty_publication.Get(obj, param, "sproc_main_faculty_publication_sel");
        }

        public IEnumerable<main_faculty_publication> GetAll(main_faculty_publication entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_faculty_publication.GetAll(entity, param, "sproc_main_faculty_publication_lstAll");
        }

        public IEnumerable<main_faculty_publication> GetAllpublicationByFacultyId(main_faculty_publication entity)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_faculty_publication.GetAll(entity, param, "sproc_main_faculty_publication_sel_By_FacultyId");
        }

        public object GetScalar(main_faculty_publication obj)
        {
            throw new NotImplementedException();
        }
    }
}

