﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_footer_contactusService : Imain_footer_contactusService, IService<main_footer_contactus>
    {
        private Imain_footer_contactus _main_footer_contactus = null;

        public main_footer_contactusService(Imain_footer_contactus main_footer_contactus)
        {
            this._main_footer_contactus = main_footer_contactus;
        }

        public int AddEditDelete(main_footer_contactus entity)
        {
            string[] param = new string[] { "FooterContactUsId", "Address", "PhoneNumber", "EmailAddress", "Website", "GoogleMapCode" };
            object obj2 = this._main_footer_contactus.ExecuteNonQuery(entity, param, "sproc_main_footer_contactus_ups");
            return Convert.ToInt32(obj2);
        }

        public main_footer_contactus Get(main_footer_contactus obj)
        {
            string[] param = new string[0];
            return this._main_footer_contactus.Get(obj, param, "sproc_main_footer_contactus_sel");
        }

        public IEnumerable<main_footer_contactus> GetAll(main_footer_contactus entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_footer_contactus.GetAll(entity, param, "sproc_main_footer_contactus_lstAll");
        }

        public object GetScalar(main_footer_contactus obj)
        {
            throw new NotImplementedException();
        }
    }
}

