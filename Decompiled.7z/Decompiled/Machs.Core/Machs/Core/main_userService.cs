﻿namespace Machs.Core
{
    using Machs.Common;
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class main_userService : Imain_userService, IService<main_user>
    {
        private Imain_menuService _main_menuService = null;
        private Imain_role_featuresService _main_role_featureService = null;
        private Imain_user _main_user = null;

        public main_userService(Imain_user main_user)
        {
            this._main_user = main_user;
            Imain_role_features _features = new main_role_featuresRepo();
            this._main_role_featureService = new main_role_featuresService(_features);
            Imain_menu _menu = new main_menuRepo();
            this._main_menuService = new main_menuService(_menu);
        }

        public int AddEditDelete(main_user entity)
        {
            string[] param = new string[] { "UserId", "FirstName", "MiddleName", "LastName", "Email", "Password", "MobileNumber", "IsActive", "RoleId" };
            object obj2 = this._main_user.ExecuteNonQuery(entity, param, "sproc_main_user_ups");
            return Convert.ToInt32(obj2);
        }

        public int Delete(main_user obj)
        {
            string[] param = new string[] { "UserId" };
            return Convert.ToInt32(this._main_user.GetScalar(obj, param, "sproc_main_user_del"));
        }

        public main_user Get(main_user obj)
        {
            string[] param = new string[] { "UserId" };
            return this._main_user.Get(obj, param, "sproc_main_user_sel");
        }

        public IEnumerable<main_user> GetAll(main_user entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "FirstName" };
            return this._main_user.GetAll(entity, param, "sproc_main_user_lstAll");
        }

        public main_user GetByCredentials(main_user obj)
        {
            main_user _user = null;
            string[] param = new string[] { "Email", "Password" };
            _user = this._main_user.Get(obj, param, "sproc_main_user_selByCredentials");
            if ((_user != null) && (_user.UserId != 0))
            {
                if (MachsSession.IsInSession("USERAndROLE"))
                {
                    MachsSession.RemoveSessionItem("USERAndROLE");
                }
                main_loggeduser pValue = new main_loggeduser {
                    currentuser = _user
                };
                main_role_features entity = new main_role_features {
                    RoleId = new int?(Convert.ToInt32(_user.RoleId))
                };
                pValue.listrolefeatures = this._main_role_featureService.GetFeaturesByRoleID(entity).ToList<main_role_features>();
                main_menu _menu = new main_menu {
                    RoleId = new int?(Convert.ToInt32(_user.RoleId))
                };
                pValue.listrolemenus = this._main_menuService.GetMenusByRoleID(_menu).ToList<main_menu>();
                MachsSession.AddSessionItem("USERAndROLE", pValue);
            }
            return _user;
        }

        public object GetScalar(main_user obj)
        {
            throw new NotImplementedException();
        }

        public main_user GetUserByEmailId(main_user obj)
        {
            string[] param = new string[] { "Email" };
            return this._main_user.Get(obj, param, "sproc_main_User__sel_ByEmailId");
        }
    }
}

