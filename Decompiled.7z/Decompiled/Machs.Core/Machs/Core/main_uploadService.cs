﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_uploadService : Imain_uploadService, IService<main_upload>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_upload _main_upload = null;

        public main_uploadService(Imain_upload main_upload)
        {
            this._main_upload = main_upload;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_upload entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["FileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["FileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFileBytes = entity.UploadFileBytes;
            if (uploadFileBytes != null)
            {
                str3 = str3 + "/AssetUploads";
                str4 = str4 + "/AssetUploads";
                handle.FileName = uploadFileBytes.FileName;
                handle.MIMEType = uploadFileBytes.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFileBytes.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.UploadFile = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "UploadId", "UploadFile", "UploadName" };
            return Convert.ToInt32(this._main_upload.GetScalar(entity, param, "sproc_main_Upload_ups"));
        }

        public int Delete(main_upload entity)
        {
            string[] param = new string[] { "UploadId" };
            return this._main_upload.ExecuteNonQuery(entity, param, "sproc_main_Upload_del");
        }

        public main_upload Get(main_upload obj)
        {
            string[] param = new string[] { "UploadId" };
            return this._main_upload.Get(obj, param, "sproc_main_Upload_sel");
        }

        public IEnumerable<main_upload> GetAll(main_upload entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "UploadName" };
            return this._main_upload.GetAll(entity, param, "sproc_main_Upload_lstAll");
        }

        public object GetScalar(main_upload obj)
        {
            throw new NotImplementedException();
        }
    }
}

