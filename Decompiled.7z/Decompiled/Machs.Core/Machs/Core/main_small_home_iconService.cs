﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_small_home_iconService : Imain_small_home_iconService, IService<main_small_home_icon>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_small_home_icon _main_small_home_icon = null;

        public main_small_home_iconService(Imain_small_home_icon main_small_home_icon)
        {
            this._main_small_home_icon = main_small_home_icon;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_small_home_icon entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            if (uploadFile != null)
            {
                str3 = str3 + "/Icon";
                str4 = str4 + "/Icon";
                handle.FileName = uploadFile.FileName;
                handle.MIMEType = uploadFile.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.IconImagePath = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "SmallHomeIconId", "Title", "Displayorder", "TitleArabic", "IsTemplate", "LinkPath", "IconImagePath", "IsHide", "Language", "DataArabic", "DataEnglish", "IsCustom" };
            object obj2 = this._main_small_home_icon.ExecuteNonQuery(entity, param, "sproc_main_small_home_icon_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteIcon(main_small_home_icon Entity)
        {
            string[] param = new string[] { "SmallHomeIconId" };
            return this._main_small_home_icon.ExecuteNonQuery(Entity, param, "sproc_main_small_home_icon_del");
        }

        public main_small_home_icon Get(main_small_home_icon obj)
        {
            string[] param = new string[] { "SmallHomeIconId" };
            return this._main_small_home_icon.Get(obj, param, "sproc_main_small_home_icon_sel");
        }

        public IEnumerable<main_small_home_icon> GetAll(main_small_home_icon entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_small_home_icon.GetAll(entity, param, "sproc_main_small_home_icon_lstAll");
        }

        public object GetScalar(main_small_home_icon obj)
        {
            throw new NotImplementedException();
        }
    }
}

