﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Web.Mvc;

    public interface IFileHandler
    {
        string CopyToFile(string SourceFilePath, string DestinationFilePath);
        string ReadFileStream(FileHandle handle);
        FileStreamResult ReadFileStreamResult(FileHandle handle);
        byte[] ReadFileToByte(FileHandle handle);
        bool UploadFile(FileHandle handle, ref string FullFilePath, ref string errorMessage);
    }
}

