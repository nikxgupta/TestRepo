﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_role_featuresService : IService<main_role_features>
    {
        int AddEditRoleFeatures(main_role_features entity);
        IEnumerable<main_role_features> GetFeaturesByRoleID(main_role_features entity);
        IEnumerable<main_role_features> GetRoleFeatures(main_role_features obj);
    }
}

