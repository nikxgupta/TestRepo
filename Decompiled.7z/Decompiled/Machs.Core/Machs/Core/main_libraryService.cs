﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_libraryService : Imain_libraryService, IService<main_library>
    {
        private Imain_library _main_library = null;

        public main_libraryService(Imain_library main_library)
        {
            this._main_library = main_library;
        }

        public int AddEditDelete(main_library entity)
        {
            string[] param = new string[] { "LibraryBooksId", "BookPeriodicalsTitle", "SerialNumber", "Author", "Edition", "IssueDate", "Quantity", "BookCategory", "QuantityWithLibrary", "DelayPenalties", "Class", "SubClass", "Year" };
            object obj2 = this._main_library.ExecuteNonQuery(entity, param, "sproc_main_library_ups");
            return Convert.ToInt32(obj2);
        }

        public int Deletelibrary(main_library Entity)
        {
            string[] param = new string[] { "LibraryBooksId" };
            return this._main_library.ExecuteNonQuery(Entity, param, "sproc_main_library_del");
        }

        public main_library Get(main_library obj)
        {
            string[] param = new string[] { "LibraryBooksId" };
            return this._main_library.Get(obj, param, "sproc_main_library_sel");
        }

        public IEnumerable<main_library> GetAll(main_library entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "BookPeriodicalsTitle", "BookCategory" };
            return this._main_library.GetAll(entity, param, "sproc_main_library_lstAll");
        }

        public IEnumerable<main_library> GetFutureBookHistory(main_library obj)
        {
            string[] param = new string[] { "LibraryBooksId", "CurrentDate" };
            return this._main_library.GetAll(obj, param, "sproc_main_library_sel_FutureBookHistory");
        }

        public IEnumerable<main_library> GetFutureBooks(main_library obj)
        {
            string[] param = new string[] { "StudentID", "CurrentDate" };
            return this._main_library.GetAll(obj, param, "sproc_main_library_sel_FutureBooks");
        }

        public IEnumerable<main_library> GetPastBookHistory(main_library obj)
        {
            string[] param = new string[] { "LibraryBooksId", "CurrentDate" };
            return this._main_library.GetAll(obj, param, "sproc_main_library_sel_PastBookHistory");
        }

        public IEnumerable<main_library> GetPastBooks(main_library obj)
        {
            string[] param = new string[] { "StudentID", "CurrentDate" };
            return this._main_library.GetAll(obj, param, "sproc_main_library_sel_PastBook");
        }

        public IEnumerable<main_library> GetPresentBookHistory(main_library obj)
        {
            string[] param = new string[] { "LibraryBooksId", "CurrentDate" };
            return this._main_library.GetAll(obj, param, "sproc_main_library_sel_PresentBookHistory");
        }

        public IEnumerable<main_library> GetPresentBooks(main_library obj)
        {
            string[] param = new string[] { "StudentID", "CurrentDate" };
            return this._main_library.GetAll(obj, param, "sproc_main_library_sel_PresentBook");
        }

        public object GetScalar(main_library obj)
        {
            throw new NotImplementedException();
        }

        public int UpdateLibraryWithQuantity(main_library obj)
        {
            string[] param = new string[] { "LibraryBooksId", "QuantityWithLibrary" };
            return this._main_library.ExecuteNonQuery(obj, param, "sproc_main_library_ups_QuantityWithLibrary");
        }
    }
}

