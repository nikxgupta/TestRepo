﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_roleService : IService<main_role>
    {
        int DeleteRole(main_role Entity);
    }
}

