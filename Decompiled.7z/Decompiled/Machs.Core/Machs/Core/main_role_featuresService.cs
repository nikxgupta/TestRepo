﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_role_featuresService : Imain_role_featuresService, IService<main_role_features>
    {
        private Imain_role_features _main_role_features = null;

        public main_role_featuresService(Imain_role_features main_role_features)
        {
            this._main_role_features = main_role_features;
        }

        public int AddEditDelete(main_role_features entity)
        {
            string[] param = new string[] { "RoleId", "FeatureId", "IsAdd", "IsDelete", "IsEdit", "IsPrint", "IsView" };
            return Convert.ToInt32(this._main_role_features.GetScalar(entity, param, "sproc_main_role_features_ups"));
        }

        public int AddEditRoleFeatures(main_role_features entity)
        {
            string[] param = new string[] { "RoleId", "FeatureId", "IsRoleAvailable" };
            return this._main_role_features.ExecuteNonQuery(entity, param, "sproc_main_role_feature_ups");
        }

        public main_role_features Get(main_role_features obj)
        {
            string[] param = new string[] { "RoleFeatureId" };
            return this._main_role_features.Get(obj, param, "sproc_main_role_features_sel");
        }

        public IEnumerable<main_role_features> GetAll(main_role_features entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_role_features.GetAll(entity, param, "sproc_main_role_features_lstAll");
        }

        public IEnumerable<main_role_features> GetFeaturesByRoleID(main_role_features entity)
        {
            string[] param = new string[] { "RoleId" };
            return this._main_role_features.GetAll(entity, param, "sproc_main_Get_Feature_By_RoleId");
        }

        public IEnumerable<main_role_features> GetRoleFeatures(main_role_features obj)
        {
            string[] param = new string[] { "RoleId" };
            return this._main_role_features.GetAll(obj, param, "sproc_main_role_feature_linking_lstall");
        }

        public object GetScalar(main_role_features obj)
        {
            throw new NotImplementedException();
        }
    }
}

