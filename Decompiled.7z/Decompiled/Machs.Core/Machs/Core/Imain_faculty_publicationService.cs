﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_faculty_publicationService : IService<main_faculty_publication>
    {
        int Deletepublication(main_faculty_publication Entity);
        IEnumerable<main_faculty_publication> GetAllpublicationByFacultyId(main_faculty_publication entity);
    }
}

