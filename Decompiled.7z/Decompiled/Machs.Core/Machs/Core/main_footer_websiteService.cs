﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_footer_websiteService : Imain_footer_websiteService, IService<main_footer_website>
    {
        private Imain_footer_website _main_footer_website = null;

        public main_footer_websiteService(Imain_footer_website main_footer_website)
        {
            this._main_footer_website = main_footer_website;
        }

        public int AddEditDelete(main_footer_website entity)
        {
            string[] param = new string[] { "FooterWebsiteId", "Title", "Language", "TitleArabic", "IsCustom", "IsHide", "IsTemplate", "DataArabic", "DataEnglish", "Displayorder", "LinkPath" };
            object obj2 = this._main_footer_website.ExecuteNonQuery(entity, param, "sproc_main_footer_website_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteWebSite(main_footer_website Entity)
        {
            string[] param = new string[] { "FooterWebsiteId" };
            return this._main_footer_website.ExecuteNonQuery(Entity, param, "sproc_main_footer_website_del");
        }

        public main_footer_website Get(main_footer_website obj)
        {
            string[] param = new string[] { "FooterWebsiteId" };
            return this._main_footer_website.Get(obj, param, "sproc_main_footer_website_sel");
        }

        public IEnumerable<main_footer_website> GetAll(main_footer_website entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_footer_website.GetAll(entity, param, "sproc_main_footer_website_lstAll");
        }

        public object GetScalar(main_footer_website obj)
        {
            throw new NotImplementedException();
        }
    }
}

