﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_roleService : Imain_roleService, IService<main_role>
    {
        private Imain_role _main_role = null;

        public main_roleService(Imain_role main_role)
        {
            this._main_role = main_role;
        }

        public int AddEditDelete(main_role entity)
        {
            string[] param = new string[] { "RoleId", "RoleName" };
            return Convert.ToInt32(this._main_role.GetScalar(entity, param, "sproc_main_role_ups"));
        }

        public int DeleteRole(main_role Entity)
        {
            string[] param = new string[] { "RoleId" };
            return this._main_role.ExecuteNonQuery(Entity, param, "sproc_main_role_del");
        }

        public main_role Get(main_role obj)
        {
            string[] param = new string[] { "RoleId" };
            return this._main_role.Get(obj, param, "sproc_main_role_sel");
        }

        public IEnumerable<main_role> GetAll(main_role entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "RoleName" };
            return this._main_role.GetAll(entity, param, "sproc_main_role_lstAll");
        }

        public object GetScalar(main_role obj)
        {
            throw new NotImplementedException();
        }
    }
}

