﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_help_faqService : IService<main_help_faq>
    {
        int DeleteQuestion(main_help_faq Entity);
    }
}

