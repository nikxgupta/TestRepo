﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_downloadsService : Imain_downloadsService, IService<main_downloads>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_downloadsRepo _Imain_downloadsRepo = null;

        public main_downloadsService(Imain_downloadsRepo _Imain_downloadsRepo)
        {
            this._Imain_downloadsRepo = _Imain_downloadsRepo;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_downloads entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase base2 = entity.UploadFilePath1;
            HttpPostedFileBase base3 = entity.UploadFilePath2;
            if (base2 != null)
            {
                str3 = str3 + "/Downloads";
                str4 = str4 + "/Downloads";
                handle.FileName = base2.FileName;
                handle.MIMEType = base2.ContentType;
                handle.FilePath = str3;
                handle.Content = base2.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.DocumentUploadPath1 = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "DownloadsId", "DocumentTitle", "DocumentTitleArabic", "DocumentUploadPath1", "IsHide", "MenuId" };
            object obj2 = this._Imain_downloadsRepo.ExecuteNonQuery(entity, param, "sproc_main_downloads_ups");
            return Convert.ToInt32(obj2);
        }

        public int Deletedownloads(main_downloads Entity)
        {
            string[] param = new string[] { "DownloadsId" };
            return this._Imain_downloadsRepo.ExecuteNonQuery(Entity, param, "sproc_main_downloads_del");
        }

        public main_downloads Get(main_downloads obj)
        {
            string[] param = new string[] { "DownloadsId" };
            return this._Imain_downloadsRepo.Get(obj, param, "sproc_main_downloads_sel");
        }

        public IEnumerable<main_downloads> GetAll(main_downloads entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "DocumentTitle", "MenuId" };
            return this._Imain_downloadsRepo.GetAll(entity, param, "sproc_main_downloads_lstAll");
        }

        public object GetScalar(main_downloads obj)
        {
            throw new NotImplementedException();
        }
    }
}

