﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_small_home_iconService : IService<main_small_home_icon>
    {
        int DeleteIcon(main_small_home_icon Entity);
    }
}

