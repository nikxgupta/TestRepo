﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_featureService : Imain_featureService, IService<main_feature>
    {
        private Imain_feature _main_feature = null;

        public main_featureService(Imain_feature main_feature)
        {
            this._main_feature = main_feature;
        }

        public int AddEditDelete(main_feature entity)
        {
            string[] param = new string[] { "FeatureName", "FeatureNameArabic", "ControllerName", "ActionName", "ParentId", "DisplayOrder" };
            return Convert.ToInt32(this._main_feature.GetScalar(entity, param, "sproc_main_feature_ups"));
        }

        public main_feature Get(main_feature obj)
        {
            string[] param = new string[] { "FeatureId" };
            return this._main_feature.Get(obj, param, "sproc_main_feature_sel");
        }

        public IEnumerable<main_feature> GetAll(main_feature entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_feature.GetAll(entity, param, "sproc_main_feature_lstAll");
        }

        public object GetScalar(main_feature obj)
        {
            throw new NotImplementedException();
        }
    }
}

