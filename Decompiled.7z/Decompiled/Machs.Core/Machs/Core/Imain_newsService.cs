﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_newsService : IService<main_news>
    {
        int DeleteNews(main_news Entity);
        IEnumerable<main_news> GetNews(main_news entity);
    }
}

