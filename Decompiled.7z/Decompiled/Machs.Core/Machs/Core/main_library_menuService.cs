﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_library_menuService : Imain_library_menuService, IService<main_library_menu>
    {
        private Imain_library_menu _main_library_menu = null;

        public main_library_menuService(Imain_library_menu main_library_menu)
        {
            this._main_library_menu = main_library_menu;
        }

        public int AddEditDelete(main_library_menu entity)
        {
            string[] param = new string[] { "LibraryMenuId", "Title", "Displayorder", "TitleArabic", "IsTemplate", "IconImagePath", "IsHide", "Language", "DataArabic", "DataEnglish", "IsCustom" };
            object obj2 = this._main_library_menu.ExecuteNonQuery(entity, param, "sproc_main_library_menu_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteLibraryMenu(main_library_menu Entity)
        {
            string[] param = new string[] { "LibraryMenuId" };
            return this._main_library_menu.ExecuteNonQuery(Entity, param, "sproc_main_library_menu_del");
        }

        public int DeleteLibraryMenuTemplate(main_library_menu Entity)
        {
            string[] param = new string[] { "LibraryMenuId" };
            return this._main_library_menu.ExecuteNonQuery(Entity, param, "sproc_main_library_menu_template_del");
        }

        public main_library_menu Get(main_library_menu obj)
        {
            string[] param = new string[] { "LibraryMenuId" };
            return this._main_library_menu.Get(obj, param, "sproc_main_library_menu_sel");
        }

        public IEnumerable<main_library_menu> GetAll(main_library_menu entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_library_menu.GetAll(entity, param, "sproc_main_library_menu_lstAll");
        }

        public object GetScalar(main_library_menu obj)
        {
            throw new NotImplementedException();
        }
    }
}

