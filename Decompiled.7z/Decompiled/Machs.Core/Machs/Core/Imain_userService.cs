﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_userService : IService<main_user>
    {
        int Delete(main_user entity);
        main_user GetByCredentials(main_user obj);
        main_user GetUserByEmailId(main_user obj);
    }
}

