﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_footer_socialService : Imain_footer_socialService, IService<main_footer_social>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_footer_social _main_footer_social = null;

        public main_footer_socialService(Imain_footer_social main_footer_social)
        {
            this._main_footer_social = main_footer_social;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_footer_social entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            if (uploadFile != null)
            {
                str3 = str3 + "/Social";
                str4 = str4 + "/Social";
                handle.FileName = uploadFile.FileName;
                handle.MIMEType = uploadFile.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.IconImagePath = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "FooterSocialId", "LinkText", "LinkTextArabic", "IconImagePath", "Displayorder", "IsHide", "LinkPath" };
            object obj2 = this._main_footer_social.ExecuteNonQuery(entity, param, "sproc_main_footer_social_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteFooterSocial(main_footer_social Entity)
        {
            string[] param = new string[] { "FooterSocialId" };
            return this._main_footer_social.ExecuteNonQuery(Entity, param, "sproc_main_footer_social_del");
        }

        public main_footer_social Get(main_footer_social obj)
        {
            string[] param = new string[] { "FooterSocialId" };
            return this._main_footer_social.Get(obj, param, "sproc_main_footer_social_sel");
        }

        public IEnumerable<main_footer_social> GetAll(main_footer_social entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_footer_social.GetAll(entity, param, "sproc_main_footer_social_lstAll");
        }

        public object GetScalar(main_footer_social obj)
        {
            throw new NotImplementedException();
        }
    }
}

