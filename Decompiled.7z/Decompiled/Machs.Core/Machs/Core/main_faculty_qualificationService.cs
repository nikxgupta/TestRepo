﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_faculty_qualificationService : Imain_faculty_qualificationService, IService<main_faculty_qualification>
    {
        private Imain_faculty_qualification _main_faculty_qualification = null;

        public main_faculty_qualificationService(Imain_faculty_qualification main_faculty_qualification)
        {
            this._main_faculty_qualification = main_faculty_qualification;
        }

        public int AddEditDelete(main_faculty_qualification entity)
        {
            string[] param = new string[] { "QualificationId", "FacultyId", "Degree", "DegreeArabic", "Department", "DepartmentArabic", "University", "UniversityArabic", "PassingYear" };
            return Convert.ToInt32(this._main_faculty_qualification.GetScalar(entity, param, "sproc_main_faculty_qualification_ups"));
        }

        public int DeleteQualification(main_faculty_qualification obj)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_faculty_qualification.ExecuteNonQuery(obj, param, "sproc_main_faculty_qualification_del");
        }

        public main_faculty_qualification Get(main_faculty_qualification obj)
        {
            string[] param = new string[] { "QualificationId" };
            return this._main_faculty_qualification.Get(obj, param, "sproc_main_faculty_qualification_sel");
        }

        public IEnumerable<main_faculty_qualification> GetAll(main_faculty_qualification entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_faculty_qualification.GetAll(entity, param, "sproc_main_faculty_qualification_lstAll");
        }

        public IEnumerable<main_faculty_qualification> GetAllQualificationByFacultyId(main_faculty_qualification entity)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_faculty_qualification.GetAll(entity, param, "sproc_main_faculty_qualification_sel_By_FacultyId");
        }

        public object GetScalar(main_faculty_qualification obj)
        {
            throw new NotImplementedException();
        }
    }
}

