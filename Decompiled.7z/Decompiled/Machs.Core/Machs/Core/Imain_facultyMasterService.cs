﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_facultyMasterService : IService<main_facultyMaster>
    {
        int DeleteFaculty(main_facultyMaster Entity);
    }
}

