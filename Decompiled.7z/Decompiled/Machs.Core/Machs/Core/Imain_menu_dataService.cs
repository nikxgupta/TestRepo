﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_menu_dataService : IService<main_menu_data>
    {
        int DeleteMenu(main_menu_data Entity);
        main_menu_data ListAllSubMenuByMenuId(main_menu_data obj);
    }
}

