﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_home_galleryService : IService<main_home_gallery>
    {
        int Delete(main_home_gallery entity);
    }
}

