﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_lookupService : Imain_lookupService, IService<main_lookup>
    {
        private Imain_lookup _main_lookup = null;

        public main_lookupService(Imain_lookup main_lookup)
        {
            this._main_lookup = main_lookup;
        }

        public int AddEditDelete(main_lookup entity)
        {
            string[] param = new string[] { "LookupId", "LookupType", "LookupText", "LookupTextArabic", "LookupValue", "DisplayOrder" };
            object obj2 = this._main_lookup.ExecuteNonQuery(entity, param, "sproc_main_lookup_ups");
            return Convert.ToInt32(obj2);
        }

        public int Deletelookup(main_lookup Entity)
        {
            string[] param = new string[] { "LookupId" };
            return this._main_lookup.ExecuteNonQuery(Entity, param, "sproc_main_lookup_del");
        }

        public main_lookup Get(main_lookup obj)
        {
            string[] param = new string[] { "LookupId" };
            return this._main_lookup.Get(obj, param, "sproc_main_lookup_sel");
        }

        public IEnumerable<main_lookup> GetAll(main_lookup entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "LookupType", "LookupText" };
            return this._main_lookup.GetAll(entity, param, "sproc_main_lookup_lstAll");
        }

        public object GetScalar(main_lookup obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<main_lookup> ListAllBookCategory(main_lookup entity)
        {
            string[] param = new string[] { "LookupType" };
            return this._main_lookup.GetAll(entity, param, "sproc_main_lookup_GetBookCategory");
        }

        public IEnumerable<main_lookup> ListAllUserType(main_lookup entity)
        {
            string[] param = new string[] { "LookupType" };
            return this._main_lookup.GetAll(entity, param, "sproc_main_lookup_GetUserType");
        }
    }
}

