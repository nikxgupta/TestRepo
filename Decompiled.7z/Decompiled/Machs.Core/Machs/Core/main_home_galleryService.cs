﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_home_galleryService : Imain_home_galleryService, IService<main_home_gallery>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_home_galleryRepo _main_home_galleryRepo = null;

        public main_home_galleryService(Imain_home_galleryRepo main_home_galleryRepo)
        {
            this._main_home_galleryRepo = main_home_galleryRepo;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_home_gallery entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            if (uploadFile != null)
            {
                str3 = str3 + "/HomeGallery";
                str4 = str4 + "/HomeGallery";
                handle.MIMEType = uploadFile.ContentType;
                handle.FileName = uploadFile.FileName;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.GalleryImage = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "HomeGalleryId", "GalleryImage", "GalleryDescription", "GalleryDescriptionArabic", "IsHide" };
            object obj2 = this._main_home_galleryRepo.ExecuteNonQuery(entity, param, "sproc_main_home_gallery_ups");
            return Convert.ToInt32(obj2);
        }

        public int Delete(main_home_gallery entity)
        {
            string[] param = new string[] { "HomeGalleryId" };
            return this._main_home_galleryRepo.ExecuteNonQuery(entity, param, "sproc_main_home_gallery_del");
        }

        public main_home_gallery Get(main_home_gallery obj)
        {
            string[] param = new string[] { "HomeGalleryId" };
            return this._main_home_galleryRepo.Get(obj, param, "sproc_main_home_gallery_sel");
        }

        public IEnumerable<main_home_gallery> GetAll(main_home_gallery entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "GalleryDescription" };
            return this._main_home_galleryRepo.GetAll(entity, param, "sproc_main_home_gallery_lstAll");
        }

        public object GetScalar(main_home_gallery obj)
        {
            throw new NotImplementedException();
        }
    }
}

