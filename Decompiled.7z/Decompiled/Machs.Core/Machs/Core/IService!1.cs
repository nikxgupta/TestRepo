﻿namespace Machs.Core
{
    using System;
    using System.Collections.Generic;

    public interface IService<T>
    {
        int AddEditDelete(T entity);
        T Get(T obj);
        IEnumerable<T> GetAll(T entity);
        object GetScalar(T obj);
    }
}

