﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.IO;
    using System.Web.Mvc;

    public class FileHandler : IFileHandler
    {
        private string _FileName = string.Empty;
        private string _FilePath = string.Empty;
        private string _MIMEType = string.Empty;
        private string _SuccessMessage = string.Empty;

        public string CopyToFile(string SourceFilePath, string DestinationFilePath)
        {
            throw new NotImplementedException();
        }

        public string GetFileMimeType(string FileName) => 
            string.Empty;

        public string ReadFileStream(FileHandle handle)
        {
            throw new NotImplementedException();
        }

        public FileStreamResult ReadFileStreamResult(FileHandle handle)
        {
            this._MIMEType = "image/jpg";
            FileStreamResult result = null;
            string path = handle.FilePath + @"\" + handle.FileName;
            if (!File.Exists(path))
            {
                return result;
            }
            using (FileStream stream = File.Open(path, FileMode.Open))
            {
                return new FileStreamResult(stream, this._MIMEType);
            }
        }

        public byte[] ReadFileToByte(FileHandle handle)
        {
            string path = handle.FilePath + @"\" + handle.FileName;
            byte[] buffer = null;
            if (File.Exists(path))
            {
                using (FileStream stream = File.Open(path, FileMode.Open))
                {
                    buffer = new byte[stream.Length];
                    stream.Read(buffer, 0, buffer.Length);
                }
            }
            return buffer;
        }

        public bool UploadFile(FileHandle handle, ref string retFullFilePath, ref string errorMessage)
        {
            handle.FilePath = handle.FilePath.Replace('/', '\\');
            if (!string.IsNullOrEmpty(handle.FileName))
            {
                if (handle.FileName.Contains(@"\"))
                {
                    string str2 = handle.FileName.Substring(handle.FileName.LastIndexOf(@"\") + 1);
                    handle.FileName = str2;
                }
                if (handle.Content.Length > 0L)
                {
                    string filePath = handle.FilePath;
                    Stream content = handle.Content;
                    if (!Directory.Exists(handle.FilePath))
                    {
                        Directory.CreateDirectory(handle.FilePath);
                    }
                    string path = handle.FilePath + @"\" + handle.FileName;
                    using (FileStream stream2 = File.Create(path, (int) handle.Content.Length))
                    {
                        byte[] buffer = new byte[handle.Content.Length];
                        handle.Content.Read(buffer, 0, buffer.Length);
                        stream2.Write(buffer, 0, buffer.Length);
                    }
                    retFullFilePath = path;
                    return true;
                }
                errorMessage = "Error- File should not be empty";
            }
            else
            {
                errorMessage = "Error- No File Name";
            }
            return false;
        }
    }
}

