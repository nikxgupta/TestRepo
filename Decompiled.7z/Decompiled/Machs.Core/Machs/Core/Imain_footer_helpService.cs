﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_footer_helpService : IService<main_footer_help>
    {
        int DeleteHelpFooter(main_footer_help entity);
    }
}

