﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_lookupService : IService<main_lookup>
    {
        int Deletelookup(main_lookup Entity);
        IEnumerable<main_lookup> ListAllBookCategory(main_lookup entity);
        IEnumerable<main_lookup> ListAllUserType(main_lookup entity);
    }
}

