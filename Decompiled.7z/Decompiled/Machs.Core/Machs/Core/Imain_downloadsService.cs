﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_downloadsService : IService<main_downloads>
    {
        int Deletedownloads(main_downloads entity);
    }
}

