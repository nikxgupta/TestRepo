﻿namespace Machs.Core
{
    public interface Imain_featureService : IService<main_feature>
    {
    }
}

