﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_faculty_qualificationService : IService<main_faculty_qualification>
    {
        int DeleteQualification(main_faculty_qualification obj);
        IEnumerable<main_faculty_qualification> GetAllQualificationByFacultyId(main_faculty_qualification entity);
    }
}

