﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_library_loan_systemService : IService<main_library_loan_system>
    {
        IEnumerable<main_library_loan_system> CheckUserHasBook(main_library_loan_system obj);
        int DeleteBookHistory(main_library_loan_system Entity);
        main_library_loan_system GetDownLoadReceipt(main_library_loan_system obj);
        object GetFutureBookDate(main_library_loan_system Entity);
        int UpdateTodateForRenew(main_library_loan_system Entity);
    }
}

