﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_CAC_blockService : IService<main_CAC_block>
    {
        int DeleteBlockPopUp(main_CAC_block Entity);
    }
}

