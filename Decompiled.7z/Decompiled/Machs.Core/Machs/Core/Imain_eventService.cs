﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_eventService : IService<main_event>
    {
        int Deletemain_event(main_event Entity);
        IEnumerable<main_event> GetEvents(main_event entity);
        IEnumerable<main_event> GetEventsByDay(main_event entity);
        IEnumerable<main_event> GetEventsByMonth(main_event entity);
        IEnumerable<main_event> GetEventsByMonthALL(main_event entity);
    }
}

