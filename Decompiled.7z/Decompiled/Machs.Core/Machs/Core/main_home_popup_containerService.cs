﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_home_popup_containerService : Imain_home_popup_containerService, IService<main_home_popup_container>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_home_popup_container _Imain_home_popup_container = null;

        public main_home_popup_containerService(Imain_home_popup_container Imain_home_popup_container)
        {
            this._Imain_home_popup_container = Imain_home_popup_container;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_home_popup_container entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase base2 = entity.UploadLink1;
            HttpPostedFileBase base3 = entity.UploadLink2;
            if (base2 != null)
            {
                str3 = str3 + "/HomePopup";
                str4 = str4 + "/HomePopup";
                handle.FileName = base2.FileName;
                handle.MIMEType = base2.ContentType;
                handle.FilePath = str3;
                handle.Content = base2.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.Link1URL = str4 + "/" + handle.FileName;
                }
            }
            if (base3 != null)
            {
                str3 = str3 + "/HomePopup";
                str4 = str4 + "/HomePopup";
                handle.FileName = base3.FileName;
                handle.MIMEType = base3.ContentType;
                handle.FilePath = str3;
                handle.Content = base3.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.Link2URL = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "HomePopupContainerId", "DataEnglish", "Language", "DataArabic", "IsShow", "StartDate", "EndDate", "Link1Text", "Link1TextArabic", "Link1URL", "Link2Text", "Link2TextArabic", "Link2URL" };
            object obj2 = this._Imain_home_popup_container.ExecuteNonQuery(entity, param, "sproc_main_home_popup_container_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeletePopContainer(main_home_popup_container Entity)
        {
            string[] param = new string[] { "HomePopupContainerId" };
            return this._Imain_home_popup_container.ExecuteNonQuery(Entity, param, "sproc_main_home_popup_container_del");
        }

        public main_home_popup_container Get(main_home_popup_container obj)
        {
            string[] param = new string[] { "HomePopupContainerId" };
            return this._Imain_home_popup_container.Get(obj, param, "sproc_main_home_popup_container_sel");
        }

        public IEnumerable<main_home_popup_container> GetAll(main_home_popup_container entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._Imain_home_popup_container.GetAll(entity, param, "sproc_main_home_popup_container_lstAll");
        }

        public object GetScalar(main_home_popup_container obj)
        {
            throw new NotImplementedException();
        }

        public int PopContainerRemoveData(main_home_popup_container Entity)
        {
            string[] param = new string[] { "HomePopupContainerId" };
            return this._Imain_home_popup_container.ExecuteNonQuery(Entity, param, "sproc_main_home_popup_container_RemoveData");
        }
    }
}

