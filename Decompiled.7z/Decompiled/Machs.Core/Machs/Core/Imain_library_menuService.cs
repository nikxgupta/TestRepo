﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_library_menuService : IService<main_library_menu>
    {
        int DeleteLibraryMenu(main_library_menu Entity);
        int DeleteLibraryMenuTemplate(main_library_menu Entity);
    }
}

