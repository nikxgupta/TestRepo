﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_newsService : Imain_newsService, IService<main_news>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_news _main_news = null;

        public main_newsService(Imain_news _main_news)
        {
            this._main_news = _main_news;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_news entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            HttpPostedFileBase base3 = entity.UploadFileForNewsImage1;
            HttpPostedFileBase base4 = entity.UploadFileForNewsImage2;
            HttpPostedFileBase base5 = entity.UploadFileForNewsImage3;
            HttpPostedFileBase base6 = entity.UploadFileForNewsImage4;
            if (uploadFile != null)
            {
                str3 = str3 + "/News";
                str4 = str4 + "/News";
                handle.FileName = uploadFile.FileName;
                handle.MIMEType = uploadFile.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.TitleImage = str4 + "/" + handle.FileName;
                }
            }
            FileHandle handle2 = new FileHandle();
            if (base3 != null)
            {
                string str5 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
                string str6 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
                str5 = str5 + "/News";
                str6 = str6 + "/News";
                handle2.FileName = base3.FileName;
                handle2.MIMEType = base3.ContentType;
                handle2.FilePath = str5;
                handle2.Content = base3.InputStream;
                if (this._iFileHandler.UploadFile(handle2, ref fullFilePath, ref errorMessage))
                {
                    entity.NewsImage1 = str6 + "/" + handle2.FileName;
                }
            }
            FileHandle handle3 = new FileHandle();
            if (base4 != null)
            {
                string str7 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
                string str8 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
                str7 = str7 + "/News";
                str8 = str8 + "/News";
                handle3.FileName = base4.FileName;
                handle3.MIMEType = base4.ContentType;
                handle3.FilePath = str7;
                handle3.Content = base4.InputStream;
                if (this._iFileHandler.UploadFile(handle3, ref fullFilePath, ref errorMessage))
                {
                    entity.NewsImage2 = str8 + "/" + handle3.FileName;
                }
            }
            FileHandle handle4 = new FileHandle();
            if (base5 != null)
            {
                string str9 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
                string str10 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
                str9 = str9 + "/News";
                str10 = str10 + "/News";
                handle4.FileName = base5.FileName;
                handle4.MIMEType = base5.ContentType;
                handle4.FilePath = str9;
                handle4.Content = base5.InputStream;
                if (this._iFileHandler.UploadFile(handle4, ref fullFilePath, ref errorMessage))
                {
                    entity.NewsImage3 = str10 + "/" + handle4.FileName;
                }
            }
            FileHandle handle5 = new FileHandle();
            if (base6 != null)
            {
                string str11 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
                string str12 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
                str11 = str11 + "/News";
                str12 = str12 + "/News";
                handle5.FileName = base6.FileName;
                handle5.MIMEType = base6.ContentType;
                handle5.FilePath = str11;
                handle5.Content = base6.InputStream;
                if (this._iFileHandler.UploadFile(handle5, ref fullFilePath, ref errorMessage))
                {
                    entity.NewsImage4 = str12 + "/" + handle5.FileName;
                }
            }
            string[] param = new string[] { 
                "MNewsId", "TitleImage", "MNewsTitle", "MNewsTitleArabic", "MNewsDescription", "IsActive", "MNewsDescriptionArabic", "MenuId", "IsShowOnHomePage", "NewsDate", "NewsImage1", "NewsImage2", "NewsImage3", "NewsImage4", "LinkText1", "LinkTextArabic1",
                "LinkText2", "LinkTextArabic2", "LinkPath1", "LinkPath2"
            };
            object obj2 = this._main_news.ExecuteNonQuery(entity, param, "sproc_main_news_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteNews(main_news Entity)
        {
            string[] param = new string[] { "MNewsId" };
            return this._main_news.ExecuteNonQuery(Entity, param, "sproc_main_news_del");
        }

        public main_news Get(main_news obj)
        {
            string[] param = new string[] { "MNewsId" };
            return this._main_news.Get(obj, param, "sproc_main_news_sel");
        }

        public IEnumerable<main_news> GetAll(main_news entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "MNewsTitle", "MenuId" };
            return this._main_news.GetAll(entity, param, "sproc_main_news_lstAll");
        }

        public IEnumerable<main_news> GetNews(main_news entity)
        {
            string[] param = new string[] { "MenuId" };
            return this._main_news.GetAll(entity, param, "sproc_main_news_show_public");
        }

        public object GetScalar(main_news obj)
        {
            throw new NotImplementedException();
        }
    }
}

