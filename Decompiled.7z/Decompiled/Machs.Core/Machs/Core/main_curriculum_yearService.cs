﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_curriculum_yearService : Imain_curriculum_yearService, IService<main_curriculum_year>
    {
        private Imain_curriculum_year _main_curriculum_year = null;

        public main_curriculum_yearService(Imain_curriculum_year main_curriculum_year)
        {
            this._main_curriculum_year = main_curriculum_year;
        }

        public int AddEditDelete(main_curriculum_year entity)
        {
            string[] param = new string[] { "CurriculumYearId", "CurriculumYearName", "YearValue", "ParentId" };
            object obj2 = this._main_curriculum_year.ExecuteNonQuery(entity, param, "sproc_main_curriculum_year_ups");
            return Convert.ToInt32(obj2);
        }

        public int Delete(main_curriculum_year entity)
        {
            string[] param = new string[] { "CurriculumYearId" };
            return this._main_curriculum_year.ExecuteNonQuery(entity, param, "sproc_main_curriculum_year_del");
        }

        public main_curriculum_year Get(main_curriculum_year obj)
        {
            string[] param = new string[] { "CurriculumYearId" };
            return this._main_curriculum_year.Get(obj, param, "sproc_main_curriculum_year_sel");
        }

        public main_curriculum_year Get_ByYearValue(main_curriculum_year obj)
        {
            string[] param = new string[] { "ParentId", "YearValue" };
            return this._main_curriculum_year.Get(obj, param, "sproc_main_curriculum_year_sel_ByYearValue");
        }

        public IEnumerable<main_curriculum_year> GetAll(main_curriculum_year entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "ParentId" };
            return this._main_curriculum_year.GetAll(entity, param, "sproc_main_curriculum_year_lstAll");
        }

        public IEnumerable<main_curriculum_year> GetAll_ByParentId(main_curriculum_year entity)
        {
            string[] param = new string[] { "ParentId" };
            return this._main_curriculum_year.GetAll(entity, param, "sproc_main_curriculum_year_lstAll_ByParentId");
        }

        public object GetScalar(main_curriculum_year obj)
        {
            throw new NotImplementedException();
        }
    }
}

