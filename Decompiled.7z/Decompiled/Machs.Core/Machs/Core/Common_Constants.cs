﻿namespace Machs.Core
{
    using System;

    public class Common_Constants
    {
        public const string AGENCY_INTERVIEWERE = "AgencyInterViewer";
        public const string CANDIDATE_USERTYPE = "Candidate";
        public const string LAST_MODIFIED_BY_ID = "LastModifiedById";
        public const string LAST_UPDATION_MODE = "LastUpdationMode";
        public const string PAGEINDEX = "PageIndex";
        public const string PAGESIZE = "PageSize";
        public const string SORTEXP = "SortExp";
        public const string UPDATEMODE = "UpdateMode";
        public const string UserId = "UserId";
        public const string WHERECLAUSE = "WhereClause";
    }
}

