﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_bannerService : IService<main_banner>
    {
        int Delete(main_banner entity);
        IEnumerable<main_banner> GetAllCampusLife(main_banner entity);
        IEnumerable<main_banner> GetAllIndexPage(main_banner entity);
    }
}

