﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_menu_dataService : Imain_menu_dataService, IService<main_menu_data>
    {
        private Imain_menu_data _main_menu_data = null;

        public main_menu_dataService(Imain_menu_data main_menu_data)
        {
            this._main_menu_data = main_menu_data;
        }

        public int AddEditDelete(main_menu_data entity)
        {
            string[] param = new string[] { "MenuDataId", "MenuId", "DataEnglish", "DataArabic", "Language" };
            object obj2 = this._main_menu_data.ExecuteNonQuery(entity, param, "sproc_main_menu_data_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteMenu(main_menu_data Entity)
        {
            string[] param = new string[] { "MenuDataId" };
            return this._main_menu_data.ExecuteNonQuery(Entity, param, "sproc_main_menu_data_del");
        }

        public main_menu_data Get(main_menu_data obj)
        {
            string[] param = new string[] { "MenuId" };
            return this._main_menu_data.Get(obj, param, "sproc_main_menu_data_sel");
        }

        public IEnumerable<main_menu_data> GetAll(main_menu_data entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "DataEnglish" };
            return this._main_menu_data.GetAll(entity, param, "sproc_main_menu_data_lstAll");
        }

        public object GetScalar(main_menu_data obj)
        {
            throw new NotImplementedException();
        }

        public main_menu_data ListAllSubMenuByMenuId(main_menu_data obj)
        {
            string[] param = new string[] { "MenuId", "ParentId" };
            return this._main_menu_data.Get(obj, param, "sproc_main_menu_LstAll_InfoByMenuID");
        }
    }
}

