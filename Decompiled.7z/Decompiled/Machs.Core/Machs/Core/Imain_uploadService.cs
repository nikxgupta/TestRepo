﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_uploadService : IService<main_upload>
    {
        int Delete(main_upload entity);
    }
}

