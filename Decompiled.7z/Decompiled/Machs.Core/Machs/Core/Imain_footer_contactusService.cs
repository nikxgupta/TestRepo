﻿namespace Machs.Core
{
    public interface Imain_footer_contactusService : IService<main_footer_contactus>
    {
    }
}

