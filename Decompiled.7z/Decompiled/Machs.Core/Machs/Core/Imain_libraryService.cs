﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_libraryService : IService<main_library>
    {
        int Deletelibrary(main_library Entity);
        IEnumerable<main_library> GetFutureBookHistory(main_library obj);
        IEnumerable<main_library> GetFutureBooks(main_library obj);
        IEnumerable<main_library> GetPastBookHistory(main_library obj);
        IEnumerable<main_library> GetPastBooks(main_library obj);
        IEnumerable<main_library> GetPresentBookHistory(main_library obj);
        IEnumerable<main_library> GetPresentBooks(main_library obj);
        int UpdateLibraryWithQuantity(main_library obj);
    }
}

