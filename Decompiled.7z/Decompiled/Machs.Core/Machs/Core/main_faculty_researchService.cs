﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_faculty_researchService : Imain_faculty_researchService, IService<main_faculty_research>
    {
        private Imain_faculty_research _main_faculty_research = null;

        public main_faculty_researchService(Imain_faculty_research main_faculty_research)
        {
            this._main_faculty_research = main_faculty_research;
        }

        public int AddEditDelete(main_faculty_research entity)
        {
            string[] param = new string[] { "ResearchId", "FacultyId", "ResearchTitle", "ResearchTitleArabic", "ResearchAuthor", "ResearchAuthorArabic", "ResearchType", "ResearchLink" };
            return Convert.ToInt32(this._main_faculty_research.GetScalar(entity, param, "sproc_main_faculty_research_ups"));
        }

        public int DeleteResearch(main_faculty_research entity)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_faculty_research.ExecuteNonQuery(entity, param, "sproc_main_faculty_research_del");
        }

        public main_faculty_research Get(main_faculty_research obj)
        {
            string[] param = new string[] { "ResearchId" };
            return this._main_faculty_research.Get(obj, param, "sproc_main_faculty_research_sel");
        }

        public IEnumerable<main_faculty_research> GetAll(main_faculty_research entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_faculty_research.GetAll(entity, param, "sproc_main_faculty_research_lstAll");
        }

        public IEnumerable<main_faculty_research> GetAllresearchByFacultyId(main_faculty_research entity)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_faculty_research.GetAll(entity, param, "sproc_main_faculty_research_sel_By_FacultyId");
        }

        public object GetScalar(main_faculty_research obj)
        {
            throw new NotImplementedException();
        }
    }
}

