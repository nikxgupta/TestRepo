﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_curriculum_infoService : IService<main_curriculum_info>
    {
        int Delete(main_curriculum_info entity);
        IEnumerable<main_curriculum_info> GetAll_ByCurriculumYearId(main_curriculum_info entity);
    }
}

