﻿namespace Machs.Core
{
    using Machs.Common;
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Web;

    public class main_registrationService : Imain_registrationService, IService<main_registration>
    {
        private Imain_registration _Imain_registration = null;

        public main_registrationService(Imain_registration main_registration)
        {
            this._Imain_registration = main_registration;
        }

        public int AddEditDelete(main_registration entity)
        {
            string[] param = new string[] { "RegistrationId", "Email", "Password", "UserType", "StudentId", "StudentFullName", "StudentFullNameArabic", "Nationality", "PhoneNumber", "Address", "PassportNumber", "NationalId", "City", "Degree", "Department" };
            object obj2 = this._Imain_registration.ExecuteNonQuery(entity, param, "sproc_main_registration_ups");
            return Convert.ToInt32(obj2);
        }

        public int ChangePassword(main_registration obj)
        {
            string[] param = new string[] { "RegistrationId", "NewPassword" };
            return this._Imain_registration.ExecuteNonQuery(obj, param, "sproc_main_registration_Student_ChangePassword");
        }

        public bool CheckAlumniLogin(main_registration objUser)
        {
            main_registration studentLogin = this.GetStudentLogin(objUser);
            if ((studentLogin != null) && !string.IsNullOrEmpty(studentLogin.Email))
            {
                if (MachsSession.IsInSession("CurrentUser"))
                {
                    MachsSession.RemoveSessionItem("CurrentUser");
                }
                MachsSession.AddSessionItem("CurrentUser", studentLogin);
                return true;
            }
            return false;
        }

        public bool CheckStudentLogin(main_registration objUser)
        {
            main_registration studentLogin = this.GetStudentLogin(objUser);
            if ((studentLogin != null) && !string.IsNullOrEmpty(studentLogin.Email))
            {
                if (MachsSession.IsInSession("CurrentUser"))
                {
                    MachsSession.RemoveSessionItem("CurrentUser");
                }
                MachsSession.AddSessionItem("CurrentUser", studentLogin);
                return true;
            }
            return false;
        }

        public int DeleteStudent(main_registration obj)
        {
            string[] param = new string[] { "RegistrationId" };
            return this._Imain_registration.ExecuteNonQuery(obj, param, "sproc_main_registration_del");
        }

        public main_registration Get(main_registration obj)
        {
            string[] param = new string[] { "RegistrationId" };
            return this._Imain_registration.Get(obj, param, "sproc_main_registration_sel");
        }

        public IEnumerable<main_registration> GetAll(main_registration entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "StudentFullName" };
            return this._Imain_registration.GetAll(entity, param, "sproc_main_registration_lstAll");
        }

        public object GetScalar(main_registration obj)
        {
            throw new NotImplementedException();
        }

        public main_registration GetStudentByEmailId(main_registration obj)
        {
            string[] param = new string[] { "Email" };
            return this._Imain_registration.Get(obj, param, "sproc_main_registration_Student_sel_ByEmailId");
        }

        public main_registration GetStudentByStudentId(main_registration obj)
        {
            string[] param = new string[] { "StudentId" };
            return this._Imain_registration.Get(obj, param, "sproc_main_registration_Student_sel_ByStudentId");
        }

        public main_registration GetStudentLogin(main_registration obj)
        {
            string[] param = new string[] { "Email", "Password" };
            return this._Imain_registration.Get(obj, param, "sproc_main_Student_Login");
        }

        public int InsertLastLoginDate(main_registration obj)
        {
            string[] param = new string[] { "RegistrationId" };
            return this._Imain_registration.ExecuteNonQuery(obj, param, "sproc_main_registration_Student_LastLoginDate_ups");
        }

        public void SendEmailToStudentForPassword(main_registration objReturn)
        {
            if (objReturn != null)
            {
                string constTo = string.Empty;
                string constSubject = string.Empty;
                string constBody = string.Empty;
                constTo = objReturn.Email;
                constSubject = "MACHS Student Login Credentials.";
                using (StreamReader reader = File.OpenText(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["EmailFolder"] + "LoginCredentials.html")))
                {
                    constBody = reader.ReadToEnd();
                }
                constBody = constBody.Replace("@@Name", objReturn.StudentFullName).Replace("@@Email", objReturn.Email).Replace("@@Password", objReturn.Password);
                new EmailSender(constTo, constSubject, constBody, objReturn.RegistrationId, 0, 0, 0, "") { IsBodyHtml = true }.SendEmail();
            }
        }
    }
}

