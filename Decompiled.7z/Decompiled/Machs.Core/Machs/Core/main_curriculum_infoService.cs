﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_curriculum_infoService : Imain_curriculum_infoService, IService<main_curriculum_info>
    {
        private Imain_curriculum_info _main_curriculum_info = null;

        public main_curriculum_infoService(Imain_curriculum_info main_curriculum_info)
        {
            this._main_curriculum_info = main_curriculum_info;
        }

        public int AddEditDelete(main_curriculum_info entity)
        {
            string[] param = new string[] { "CurriculumInfoId", "CurriculumYearId", "AcademicTerm", "CourseCode", "CourseName", "CourseDescription", "Credits", "PreRequisites" };
            object obj2 = this._main_curriculum_info.ExecuteNonQuery(entity, param, "sproc_main_curriculum_info_ups");
            return Convert.ToInt32(obj2);
        }

        public int Delete(main_curriculum_info entity)
        {
            string[] param = new string[] { "CurriculumInfoId" };
            return this._main_curriculum_info.ExecuteNonQuery(entity, param, "sproc_main_curriculum_info_del");
        }

        public main_curriculum_info Get(main_curriculum_info obj)
        {
            string[] param = new string[] { "CurriculumInfoId" };
            return this._main_curriculum_info.Get(obj, param, "sproc_main_curriculum_info_sel");
        }

        public IEnumerable<main_curriculum_info> GetAll(main_curriculum_info entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "CurriculumYearId", "CourseCode", "AcademicTerm" };
            return this._main_curriculum_info.GetAll(entity, param, "sproc_main_curriculum_info_lstAll");
        }

        public IEnumerable<main_curriculum_info> GetAll_ByCurriculumYearId(main_curriculum_info entity)
        {
            string[] param = new string[] { "CurriculumYearId" };
            return this._main_curriculum_info.GetAll(entity, param, "sproc_main_curriculum_info_lstAll_ByCurriculumYearId");
        }

        public object GetScalar(main_curriculum_info obj)
        {
            throw new NotImplementedException();
        }
    }
}

