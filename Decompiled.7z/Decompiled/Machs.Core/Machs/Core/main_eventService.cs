﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_eventService : Imain_eventService, IService<main_event>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_event _Imain_event = null;

        public main_eventService(Imain_event _Imain_event)
        {
            this._Imain_event = _Imain_event;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_event entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            if (uploadFile != null)
            {
                str3 = str3 + "/Event";
                str4 = str4 + "/Event";
                handle.FileName = uploadFile.FileName;
                handle.MIMEType = uploadFile.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.MEventTitleImage = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "MEventId", "MEventTitle", "MEventTitleArabic", "MEventDescriptionArabic", "MEventDescription", "MEventDate", "IsActive", "MEventTitleImage", "MenuId", "IsShowOnHomePage", "IsReadMore" };
            object obj2 = this._Imain_event.ExecuteNonQuery(entity, param, "sproc_main_event_ups");
            return Convert.ToInt32(obj2);
        }

        public int Deletemain_event(main_event Entity)
        {
            string[] param = new string[] { "MEventId" };
            return this._Imain_event.ExecuteNonQuery(Entity, param, "sproc_main_event_del");
        }

        public main_event Get(main_event obj)
        {
            string[] param = new string[] { "MEventId" };
            return this._Imain_event.Get(obj, param, "sproc_main_event_sel");
        }

        public IEnumerable<main_event> GetAll(main_event entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "MEventTitle", "MenuId" };
            return this._Imain_event.GetAll(entity, param, "sproc_main_event_lstAll");
        }

        public IEnumerable<main_event> GetEvents(main_event entity)
        {
            string[] param = new string[] { "MenuId" };
            return this._Imain_event.GetAll(entity, param, "sproc_main_events_show_public");
        }

        public IEnumerable<main_event> GetEventsByDay(main_event entity)
        {
            string[] param = new string[] { "MenuId", "MEventDate" };
            return this._Imain_event.GetAll(entity, param, "sproc_main_events_show_public_byDay");
        }

        public IEnumerable<main_event> GetEventsByMonth(main_event entity)
        {
            string[] param = new string[] { "MenuId", "Month", "Year" };
            return this._Imain_event.GetAll(entity, param, "sproc_main_events_show_public_byMonth");
        }

        public IEnumerable<main_event> GetEventsByMonthALL(main_event entity)
        {
            string[] param = new string[] { "MenuId", "Month", "Year" };
            return this._Imain_event.GetAll(entity, param, "sproc_main_events_show_public_byMonth_All");
        }

        public object GetScalar(main_event obj)
        {
            throw new NotImplementedException();
        }
    }
}

