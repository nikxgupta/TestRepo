﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_bannerService : Imain_bannerService, IService<main_banner>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_banner _main_banner = null;

        public main_bannerService(Imain_banner main_banner)
        {
            this._main_banner = main_banner;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_banner entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            if (uploadFile != null)
            {
                str3 = str3 + "/Banners";
                str4 = str4 + "/Banners";
                handle.FileName = uploadFile.FileName;
                handle.MIMEType = uploadFile.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.FeaturedImage = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "BannerId", "Title", "Description", "DisplayOrder", "FeaturedImage", "IsInactive", "Title", "TitleArabic", "DescriptionArabic", "IsHome", "IsCampusLife" };
            object obj2 = this._main_banner.ExecuteNonQuery(entity, param, "sproc_main_banner_ups");
            return Convert.ToInt32(obj2);
        }

        public int Delete(main_banner entity)
        {
            string[] param = new string[] { "BannerId" };
            return this._main_banner.ExecuteNonQuery(entity, param, "sproc_main_banner_del");
        }

        public main_banner Get(main_banner obj)
        {
            string[] param = new string[] { "BannerId" };
            return this._main_banner.Get(obj, param, "sproc_main_banner_sel");
        }

        public IEnumerable<main_banner> GetAll(main_banner entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "Title", "BannerType" };
            return this._main_banner.GetAll(entity, param, "sproc_main_banner_lstAll");
        }

        public IEnumerable<main_banner> GetAllCampusLife(main_banner entity)
        {
            string[] param = new string[0];
            return this._main_banner.GetAll(entity, param, "sproc_main_banner_lstAll_campusLife");
        }

        public IEnumerable<main_banner> GetAllIndexPage(main_banner entity)
        {
            string[] param = new string[0];
            return this._main_banner.GetAll(entity, param, "sproc_main_banner_lstAll_indexpage");
        }

        public object GetScalar(main_banner obj)
        {
            throw new NotImplementedException();
        }
    }
}

