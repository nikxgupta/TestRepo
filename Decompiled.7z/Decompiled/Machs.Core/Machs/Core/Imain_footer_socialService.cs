﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_footer_socialService : IService<main_footer_social>
    {
        int DeleteFooterSocial(main_footer_social entity);
    }
}

