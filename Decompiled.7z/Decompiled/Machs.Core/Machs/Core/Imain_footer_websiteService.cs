﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_footer_websiteService : IService<main_footer_website>
    {
        int DeleteWebSite(main_footer_website Entity);
    }
}

