﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_home_popup_containerService : IService<main_home_popup_container>
    {
        int DeletePopContainer(main_home_popup_container Entity);
        int PopContainerRemoveData(main_home_popup_container Entity);
    }
}

