﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_faculty_researchService : IService<main_faculty_research>
    {
        int DeleteResearch(main_faculty_research obj);
        IEnumerable<main_faculty_research> GetAllresearchByFacultyId(main_faculty_research entity);
    }
}

