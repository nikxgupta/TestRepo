﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_help_faqService : Imain_help_faqService, IService<main_help_faq>
    {
        private Imain_help_faq _main_help_faq = null;

        public main_help_faqService(Imain_help_faq main_help_faq)
        {
            this._main_help_faq = main_help_faq;
        }

        public int AddEditDelete(main_help_faq entity)
        {
            string[] param = new string[] { "HelpFAQId", "Question", "QuestionArabic", "Answer", "AnswerArabic", "IsHide", "Displayorder" };
            object obj2 = this._main_help_faq.ExecuteNonQuery(entity, param, "sproc_main_help_faq_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteQuestion(main_help_faq Entity)
        {
            string[] param = new string[] { "HelpFAQId" };
            return this._main_help_faq.ExecuteNonQuery(Entity, param, "sproc_main_help_faq_del");
        }

        public main_help_faq Get(main_help_faq obj)
        {
            string[] param = new string[] { "HelpFAQId" };
            return this._main_help_faq.Get(obj, param, "sproc_main_help_faq_sel");
        }

        public IEnumerable<main_help_faq> GetAll(main_help_faq entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "Question" };
            return this._main_help_faq.GetAll(entity, param, "sproc_main_help_faq_lstAll");
        }

        public object GetScalar(main_help_faq obj)
        {
            throw new NotImplementedException();
        }
    }
}

