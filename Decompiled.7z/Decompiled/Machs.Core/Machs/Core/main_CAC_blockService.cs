﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_CAC_blockService : Imain_CAC_blockService, IService<main_CAC_block>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_CAC_block _main_CAC_block = null;

        public main_CAC_blockService(Imain_CAC_block main_CAC_block)
        {
            this._main_CAC_block = main_CAC_block;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_CAC_block entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadFile = entity.UploadFile;
            if (uploadFile != null)
            {
                str3 = str3 + "/Block";
                str4 = str4 + "/Block";
                handle.FileName = uploadFile.FileName;
                handle.MIMEType = uploadFile.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadFile.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.IconImagePath = str4 + "/" + handle.FileName;
                }
            }
            string[] param = new string[] { "CACBlockId", "Title", "Language", "TitleArabic", "ShortDescription", "ShortDescriptionArabic", "IsTemplate", "LinkPath", "IconImagePath", "IsHide", "DataArabic", "DataEnglish" };
            object obj2 = this._main_CAC_block.ExecuteNonQuery(entity, param, "sproc_main_CAC_block_ups");
            return Convert.ToInt32(obj2);
        }

        public int DeleteBlockPopUp(main_CAC_block Entity)
        {
            string[] param = new string[] { "CACBlockId" };
            return this._main_CAC_block.ExecuteNonQuery(Entity, param, "sproc_main_CAC_block_del");
        }

        public main_CAC_block Get(main_CAC_block obj)
        {
            string[] param = new string[] { "CACBlockId" };
            return this._main_CAC_block.Get(obj, param, "sproc_main_CAC_block_sel");
        }

        public IEnumerable<main_CAC_block> GetAll(main_CAC_block entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._main_CAC_block.GetAll(entity, param, "sproc_main_CAC_block_lstAll");
        }

        public object GetScalar(main_CAC_block obj)
        {
            throw new NotImplementedException();
        }
    }
}

