﻿namespace Machs.Core
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public interface Imain_curriculum_yearService : IService<main_curriculum_year>
    {
        int Delete(main_curriculum_year entity);
        main_curriculum_year Get_ByYearValue(main_curriculum_year obj);
        IEnumerable<main_curriculum_year> GetAll_ByParentId(main_curriculum_year entity);
    }
}

