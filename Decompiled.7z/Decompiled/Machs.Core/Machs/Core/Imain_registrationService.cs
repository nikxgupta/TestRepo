﻿namespace Machs.Core
{
    using Machs.Model;
    using System;

    public interface Imain_registrationService : IService<main_registration>
    {
        int ChangePassword(main_registration obj);
        bool CheckStudentLogin(main_registration objUser);
        int DeleteStudent(main_registration obj);
        main_registration GetStudentByEmailId(main_registration obj);
        main_registration GetStudentByStudentId(main_registration obj);
        main_registration GetStudentLogin(main_registration obj);
        int InsertLastLoginDate(main_registration obj);
        void SendEmailToStudentForPassword(main_registration objReturn);
    }
}

