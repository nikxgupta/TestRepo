﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_library_loan_systemService : Imain_library_loan_systemService, IService<main_library_loan_system>
    {
        private Imain_library_loan_system _Imain_library_loan_system = null;

        public main_library_loan_systemService(Imain_library_loan_system main_library_loan_system)
        {
            this._Imain_library_loan_system = main_library_loan_system;
        }

        public int AddEditDelete(main_library_loan_system entity)
        {
            string[] param = new string[] { "LibraryLoanId", "LibraryBooksId", "StudentId", "BookLoanFromDate", "BookLoanToDate", "QuantityAfterLoan" };
            return Convert.ToInt32(this._Imain_library_loan_system.GetScalar(entity, param, "sproc_main_library_loan_system_ups"));
        }

        public IEnumerable<main_library_loan_system> CheckUserHasBook(main_library_loan_system obj)
        {
            string[] param = new string[] { "StudentId", "LibraryBooksId", "CurrentDate" };
            return this._Imain_library_loan_system.GetAll(obj, param, "sproc_main_library_checkUserHasBook");
        }

        public int DeleteBookHistory(main_library_loan_system Entity)
        {
            string[] param = new string[] { "LibraryLoanId" };
            return this._Imain_library_loan_system.ExecuteNonQuery(Entity, param, "sproc_main_library_loan_system_del");
        }

        public main_library_loan_system Get(main_library_loan_system obj)
        {
            string[] param = new string[] { "LibraryLoanId" };
            return this._Imain_library_loan_system.Get(obj, param, "sproc_main_library_loan_system_sel");
        }

        public IEnumerable<main_library_loan_system> GetAll(main_library_loan_system entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp" };
            return this._Imain_library_loan_system.GetAll(entity, param, "sproc_main_library_loan_system_lstAll");
        }

        public main_library_loan_system GetDownLoadReceipt(main_library_loan_system obj)
        {
            string[] param = new string[] { "LibraryLoanId" };
            return this._Imain_library_loan_system.Get(obj, param, "sproc_main_library_loan_system_downloadReceipt");
        }

        public object GetFutureBookDate(main_library_loan_system entity)
        {
            string[] param = new string[] { "LibraryBooksId" };
            return this._Imain_library_loan_system.GetScalar(entity, param, "sproc_main_library_loan_system_GetFutureBookDate");
        }

        public object GetScalar(main_library_loan_system obj)
        {
            throw new NotImplementedException();
        }

        public int UpdateTodateForRenew(main_library_loan_system Entity)
        {
            string[] param = new string[] { "LibraryLoanId", "BookLoanToDate" };
            return this._Imain_library_loan_system.ExecuteNonQuery(Entity, param, "sproc_main_library_loan_UpdateTodateForRenew");
        }
    }
}

