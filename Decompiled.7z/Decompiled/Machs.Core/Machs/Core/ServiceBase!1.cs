﻿namespace Machs.Core
{
    using System;
    using System.Collections.Generic;

    public abstract class ServiceBase<T> : IService<T>
    {
        protected ServiceBase()
        {
        }

        public int AddEditDelete(T entity)
        {
            throw new NotImplementedException();
        }

        public T Get(T obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetAll(T entity)
        {
            throw new NotImplementedException();
        }

        public object GetScalar(T obj)
        {
            throw new NotImplementedException();
        }
    }
}

