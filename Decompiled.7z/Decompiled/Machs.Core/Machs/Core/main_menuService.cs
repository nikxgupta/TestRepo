﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;

    public class main_menuService : Imain_menuService, IService<main_menu>
    {
        private Imain_menu _main_menu = null;

        public main_menuService(Imain_menu main_menu)
        {
            this._main_menu = main_menu;
        }

        public int AddEditDelete(main_menu entity)
        {
            string[] param = new string[] { "MenuId", "MenuName", "MenuNameArabic", "ParentId", "Displayorder", "IsTemplate", "IsCustom", "LinkPath", "IsHide" };
            return Convert.ToInt32(this._main_menu.GetScalar(entity, param, "sproc_main_menu_ups"));
        }

        public int AddEditRoleMenus(main_menu entity)
        {
            string[] param = new string[] { "RoleId", "MenuId", "IsMenuAvailable" };
            return this._main_menu.ExecuteNonQuery(entity, param, "sproc_main_role_menu_ups");
        }

        public int DeleteMenu(main_menu Entity)
        {
            string[] param = new string[] { "MenuId" };
            return this._main_menu.ExecuteNonQuery(Entity, param, "sproc_main_menu_del");
        }

        public IEnumerable<main_menu> FillAllMenu(main_menu entity)
        {
            string[] param = new string[0];
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_lst");
        }

        public main_menu Get(main_menu obj)
        {
            string[] param = new string[] { "MenuId" };
            return this._main_menu.Get(obj, param, "sproc_main_menu_sel");
        }

        public IEnumerable<main_menu> GetAll(main_menu entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "MenuName" };
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_lstAll");
        }

        public IEnumerable<main_menu> GetAllSiteMap(main_menu entity)
        {
            string[] param = new string[0];
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_LstAll_SiteMap");
        }

        public IEnumerable<main_menu> GetAllTreeView(main_menu entity)
        {
            string[] param = new string[0];
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_LstAll_TreeView");
        }

        public IEnumerable<main_menu> GetCustomMenus(main_menu entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "MenuName" };
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_lstAll_Custom");
        }

        public main_menu GetCustomMenusDetailsForUpdate(main_menu obj)
        {
            string[] param = new string[] { "MenuId" };
            return this._main_menu.Get(obj, param, "sproc_main_menu_sel_ForCustom");
        }

        public IEnumerable<main_menu> GetMenusByRoleID(main_menu entity)
        {
            string[] param = new string[] { "RoleId" };
            return this._main_menu.GetAll(entity, param, "sproc_main_Get_menu_By_RoleId");
        }

        public main_menu GetParentDetails(main_menu obj)
        {
            string[] param = new string[] { "MenuId" };
            return this._main_menu.Get(obj, param, "sproc_main_menu_GetParentName");
        }

        public IEnumerable<main_menu> GetParentsChild(main_menu entity)
        {
            string[] param = new string[] { "ParentId" };
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_GetParentChild");
        }

        public IEnumerable<main_menu> GetRoleMenus(main_menu obj)
        {
            string[] param = new string[] { "RoleId" };
            return this._main_menu.GetAll(obj, param, "sproc_main_role_menus_linking_lstall");
        }

        public object GetScalar(main_menu obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<main_menu> ListAllAcademicDepartments(main_menu entity)
        {
            string[] param = new string[0];
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_Acad");
        }

        public IEnumerable<main_menu> ListAllDepartments(main_menu entity)
        {
            string[] param = new string[0];
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_Acad_Admin");
        }

        public IEnumerable<main_menu> ListAllMenuByMenuId(main_menu entity)
        {
            string[] param = new string[0];
            return this._main_menu.GetAll(entity, param, "sproc_main_menu_LstAll_Info");
        }

        public main_menu ListAllSubMenuByMenuIdAndParentId(main_menu obj)
        {
            string[] param = new string[] { "MenuId", "ParentId" };
            return this._main_menu.Get(obj, param, "sproc_main_menu_LstAll_InfoByMenuIDAndParentId");
        }

        public int UpdateCustomMenusDetails(main_menu obj)
        {
            string[] param = new string[] { "MenuId", "ActionName", "ControllerName" };
            return this._main_menu.ExecuteNonQuery(obj, param, "sproc_main_menu_ups_Custom");
        }
    }
}

