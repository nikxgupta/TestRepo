﻿namespace Machs.Core
{
    using Machs.DAL;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Web;

    public class main_facultyMasterService : Imain_facultyMasterService, IService<main_facultyMaster>
    {
        private IFileHandler _iFileHandler = null;
        private Imain_facultyMaster _main_facultyMaster = null;

        public main_facultyMasterService(Imain_facultyMaster main_facultyMaster)
        {
            this._main_facultyMaster = main_facultyMaster;
            this._iFileHandler = new FileHandler();
        }

        public int AddEditDelete(main_facultyMaster entity)
        {
            string errorMessage = string.Empty;
            string fullFilePath = string.Empty;
            string str3 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
            string str4 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
            FileHandle handle = new FileHandle();
            HttpPostedFileBase uploadCV = entity.UploadCV;
            HttpPostedFileBase uploadCVArabic = entity.UploadCVArabic;
            HttpPostedFileBase imageFaculty = entity.ImageFaculty;
            if (uploadCV != null)
            {
                str3 = str3 + "/Faculty";
                str4 = str4 + "/Faculty";
                handle.FileName = uploadCV.FileName;
                handle.MIMEType = uploadCV.ContentType;
                handle.FilePath = str3;
                handle.Content = uploadCV.InputStream;
                if (this._iFileHandler.UploadFile(handle, ref fullFilePath, ref errorMessage))
                {
                    entity.CVUploadPath = str4 + "/" + handle.FileName;
                }
            }
            if (uploadCVArabic != null)
            {
                FileHandle handle2 = new FileHandle();
                string str5 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
                string str6 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
                str5 = str5 + "/Faculty";
                str6 = str6 + "/Faculty";
                handle2.MIMEType = uploadCVArabic.ContentType;
                handle2.FileName = uploadCVArabic.FileName;
                handle2.FilePath = str3;
                handle2.Content = uploadCVArabic.InputStream;
                if (this._iFileHandler.UploadFile(handle2, ref fullFilePath, ref errorMessage))
                {
                    entity.CVUploadPathArabic = str6 + "/" + handle2.FileName;
                }
            }
            if (imageFaculty != null)
            {
                FileHandle handle3 = new FileHandle();
                string str7 = ConfigurationManager.AppSettings["UploadFileUploadPath"];
                string str8 = ConfigurationManager.AppSettings["UploadFileHttpPath"];
                str7 = str3 + "/Faculty";
                str8 = str4 + "/Faculty";
                handle3.MIMEType = imageFaculty.ContentType;
                handle3.FileName = imageFaculty.FileName;
                handle3.FilePath = str3;
                handle3.Content = imageFaculty.InputStream;
                if (this._iFileHandler.UploadFile(handle3, ref fullFilePath, ref errorMessage))
                {
                    entity.FacultyImage = str4 + "/" + handle3.FileName;
                }
            }
            string[] param = new string[] { "FacultyId", "FacultyName", "FacultyNameArabic", "MenuId", "Position", "PositionArabic", "PhoneNumber", "EmailAddress", "CVUploadPath", "CVUploadPathArabic", "FacultyImage", "SubjectsTeach", "SubjectsTeachArabic", "OfficeLocation", "PhoneExt" };
            return Convert.ToInt32(this._main_facultyMaster.GetScalar(entity, param, "sproc_main_facultyMaster_ups"));
        }

        public int DeleteFaculty(main_facultyMaster Entity)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_facultyMaster.ExecuteNonQuery(Entity, param, "sproc_main_facultyMaster_del");
        }

        public main_facultyMaster Get(main_facultyMaster obj)
        {
            string[] param = new string[] { "FacultyId" };
            return this._main_facultyMaster.Get(obj, param, "sproc_main_facultyMaster_sel");
        }

        public IEnumerable<main_facultyMaster> GetAll(main_facultyMaster entity)
        {
            string[] param = new string[] { "PageIndex", "PageSize", "SortExp", "FacultyName", "MenuId" };
            return this._main_facultyMaster.GetAll(entity, param, "sproc_main_facultyMaster_lstAll");
        }

        public object GetScalar(main_facultyMaster obj)
        {
            throw new NotImplementedException();
        }
    }
}

