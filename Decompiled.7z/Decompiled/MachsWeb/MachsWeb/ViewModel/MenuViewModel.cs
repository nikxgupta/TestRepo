﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Web.Mvc;

    public class MenuViewModel
    {
        public SelectList lstddlMenu;
        public List<main_menu> lstFirstLevelMenu;
        public List<main_menu> lstMenu;
        public List<main_menu> lstSecondLevelMenu;
        public List<main_menu> lstThirdLevelMenu;

        public main_menu Menu { get; set; }
    }
}

