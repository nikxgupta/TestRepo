﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Web.Mvc;

    public class FacultyViewModel
    {
        public IEnumerable<main_facultyMaster> lstFaculty;
        public IEnumerable<main_faculty_publication> lstFacultyPublication;
        public IEnumerable<main_faculty_qualification> lstFacultyQualification;
        public IEnumerable<main_faculty_research> lstFacultyResearch;
        public List<main_menu> lstParentChilds;

        public int ChildId { get; set; }

        public main_menu ChildMenuData { get; set; }

        public main_facultyMaster Faculty { get; set; }

        public main_faculty_publication FacultyPublication { get; set; }

        public main_faculty_qualification FacultyQualification { get; set; }

        public main_faculty_research FacultyResearch { get; set; }

        public SelectList lstDepartments { get; set; }

        public main_menu_data MenuData { get; set; }

        public int ParentId { get; set; }

        public main_menu ParentMenuData { get; set; }
    }
}

