﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class FAQViewModel
    {
        public main_help_faq FAQ { get; set; }

        public main_footer_help FooterHelp { get; set; }

        public List<main_help_faq> lstFAQ { get; set; }
    }
}

