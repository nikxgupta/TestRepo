﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class LoginViewModel
    {
        public string Email { get; set; }

        public string FullName { get; set; }

        public List<main_registration> lstStudent { get; set; }

        public string returnUrl { get; set; }

        public main_registration Student { get; set; }
    }
}

