﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class HomeViewModel
    {
        public List<main_home_gallery> lstHomeGalleries;
        public List<main_CAC_block> lstMainCACBlock;
        public List<main_small_home_icon> lstMainsmallhomeicon;

        public main_home_gallery HomeGallery { get; set; }

        public main_home_popup_container HomePopup { get; set; }

        public main_CAC_block MainCACBlock { get; set; }

        public main_small_home_icon Mainsmallhomeicon { get; set; }
    }
}

