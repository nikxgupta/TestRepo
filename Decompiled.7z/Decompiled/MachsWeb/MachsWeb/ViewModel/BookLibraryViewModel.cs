﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Web.Mvc;

    public class BookLibraryViewModel
    {
        public string EncodedEA { get; set; }

        public int Language { get; set; }

        public main_library Library { get; set; }

        public main_library_loan_system LibraryLoanSystem { get; set; }

        public main_library_menu LibraryMenu { get; set; }

        public int LibraryMenuId { get; set; }

        public string LibraryMenuTitle { get; set; }

        public string LibraryMenuTitleArabic { get; set; }

        public SelectList lstBookCategory { get; set; }

        public List<main_library> lstLibrary { get; set; }

        public List<main_library> lstLibraryFutureBooks { get; set; }

        public List<main_library_menu> lstLibraryMenu { get; set; }

        public List<main_library> lstLibraryPresentBooks { get; set; }

        public int MenuId { get; set; }

        public int ParentId { get; set; }
    }
}

