﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class MenuDataViewModel
    {
        public List<main_menu> lstMenu;
        public List<main_menu> lstParentChilds;
        public List<main_menu> lstThirdChild;

        public main_menu Menu { get; set; }

        public main_menu_data MenuData { get; set; }

        public main_menu ParentMenuData { get; set; }
    }
}

