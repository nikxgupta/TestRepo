﻿namespace MachsWeb.ViewModel
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Web.Mvc;

    public class GPAViewModel
    {
        public int ChildId { get; set; }

        public string divId { get; set; }

        public string FinalGrade { get; set; }

        public SelectList lstGrade { get; set; }

        public int ParentId { get; set; }
    }
}

