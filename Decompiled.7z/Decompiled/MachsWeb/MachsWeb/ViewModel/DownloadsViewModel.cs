﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class DownloadsViewModel
    {
        public IEnumerable<main_downloads> lstDownloads;

        public main_downloads Downloads { get; set; }

        public int Level { get; set; }

        public int MenuId { get; set; }

        public int ParentId { get; set; }

        public main_menu ParentMenu { get; set; }
    }
}

