﻿namespace MachsWeb.ViewModel
{
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class CurriculumViewModel
    {
        public int ChildId { get; set; }

        public main_curriculum_info CurriculumInfo { get; set; }

        public main_curriculum_year CurriculumYear { get; set; }

        public List<main_lookup> lstAcademicTerm { get; set; }

        public List<main_curriculum_info> lstCurriculumInfo { get; set; }

        public List<main_curriculum_year> lstCurriculumYear { get; set; }

        public int ParentId { get; set; }

        public string ParentName { get; set; }

        public int YearValue { get; set; }
    }
}

