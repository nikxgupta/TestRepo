﻿namespace MachsWeb
{
    using Machs.Dependency;
    using MachsWeb.Controllers;
    using System;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Optimization;
    using System.Web.Routing;

    public class MvcApplication : HttpApplication
    {
        protected void Application_Error(object sender, EventArgs e)
        {
            HttpContext httpContext = ((MvcApplication) sender).Context;
            RouteData routeData = RouteTable.Routes.GetRouteData(new HttpContextWrapper(httpContext));
            string actionName = "";
            string controllerName = "";
            if (routeData != null)
            {
                if (!((routeData.Values["Controller"] == null) || string.IsNullOrEmpty(routeData.Values["Controller"].ToString())))
                {
                    controllerName = routeData.Values["Controller"].ToString();
                }
                if (!((routeData.Values["Action"] == null) || string.IsNullOrEmpty(routeData.Values["Action"].ToString())))
                {
                    actionName = routeData.Values["Action"].ToString();
                }
            }
            Exception lastError = base.Server.GetLastError();
            ErrorController controller = new ErrorController();
            RouteData data2 = new RouteData();
            string str3 = "ErrorInfo";
            if (lastError is HttpException)
            {
                HttpException exception2 = lastError as HttpException;
                if (exception2.ErrorCode == 0x194)
                {
                    str3 = "NotFound";
                }
                else
                {
                    str3 = "ErrorInfo";
                }
            }
            httpContext.ClearError();
            httpContext.Response.Clear();
            httpContext.Response.StatusCode = (lastError is HttpException) ? ((HttpException) lastError).GetHttpCode() : 500;
            httpContext.Response.TrySkipIisCustomErrors = true;
            data2.Values["Controller"] = "Error";
            data2.Values["Action"] = str3;
            controller.ViewData.Model = new HandleErrorInfo(lastError, controllerName, actionName);
            ((IController) controller).Execute(new RequestContext(new HttpContextWrapper(httpContext), data2));
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            DependencyResolver.SetResolver((IDependencyResolver) new NinjectDependencyResolver());
        }
    }
}

