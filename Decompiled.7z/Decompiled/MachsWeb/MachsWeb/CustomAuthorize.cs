﻿namespace MachsWeb
{
    using Machs.Common;
    using Machs.Model;
    using System;
    using System.Collections.Generic;
    using System.Web.Mvc;
    using System.Web.Routing;

    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public class CustomAuthorize : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            string str = filterContext.Controller.ToString();
            string str2 = filterContext.ActionDescriptor.ActionName.ToString();
            RouteData routeData = filterContext.RequestContext.RouteData;
            base.OnActionExecuted(filterContext);
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            IDictionary<string, object> actionParameters = filterContext.ActionParameters;
            RouteData routeData = filterContext.RequestContext.RouteData;
            string requiredString = routeData.GetRequiredString("controller");
            string str2 = routeData.GetRequiredString("action");
            bool flag = false;
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                if (directValue != null)
                {
                    flag = true;
                }
            }
            string str3 = Convert.ToString(filterContext.HttpContext.Request.Url);
            if (!flag)
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { 
                    controller = "Login",
                    action = "LoginRegistration",
                    returnUrl = str3
                }));
            }
            base.OnActionExecuting(filterContext);
        }
    }
}

