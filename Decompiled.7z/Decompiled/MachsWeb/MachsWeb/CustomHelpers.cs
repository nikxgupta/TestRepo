﻿namespace MachsWeb
{
    using System;
    using System.Globalization;
    using System.Runtime.InteropServices;

    public class CustomHelpers
    {
        public static string ConvertDateCalendar(DateTime DateConv, string Calendar, string DateLangCulture, string DatePattern = "dddd, d MMMM yyyy")
        {
            DateLangCulture = DateLangCulture.ToLower();
            DateTimeFormatInfo dateTimeFormat = new CultureInfo(DateLangCulture, false).DateTimeFormat;
            switch (Calendar)
            {
                case "Hijri":
                    dateTimeFormat.Calendar = new HijriCalendar();
                    break;

                case "Gregorian":
                    dateTimeFormat.Calendar = new GregorianCalendar();
                    break;

                default:
                    return "";
            }
            if (string.IsNullOrEmpty(DatePattern))
            {
                dateTimeFormat.LongDatePattern = "dddd, d MMMM yyyy";
            }
            else
            {
                dateTimeFormat.LongDatePattern = DatePattern;
            }
            return DateConv.ToString("D", dateTimeFormat);
        }
    }
}

