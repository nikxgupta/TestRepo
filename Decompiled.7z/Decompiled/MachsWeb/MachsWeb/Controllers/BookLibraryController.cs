﻿namespace MachsWeb.Controllers
{
    using Machs.Common;
    using Machs.Core;
    using Machs.Model;
    using MachsWeb;
    using MachsWeb.ViewModel;
    using Rotativa;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class BookLibraryController : BaseController
    {
        private Imain_library_loan_systemService _Imain_library_loan_systemService;
        private Imain_library_menuService _Imain_library_menuService;
        private Imain_libraryService _Imain_libraryService;
        private Imain_lookupService _Imain_lookupService;

        public BookLibraryController(Imain_libraryService Imain_libraryService, Imain_lookupService Imain_lookupService, Imain_library_menuService Imain_library_menuService, Imain_library_loan_systemService main_library_loan_systemService)
        {
            this._Imain_libraryService = Imain_libraryService;
            this._Imain_lookupService = Imain_lookupService;
            this._Imain_library_menuService = Imain_library_menuService;
            this._Imain_library_loan_systemService = main_library_loan_systemService;
        }

        [CustomAuthorize]
        public ActionResult AddViewBookDetails(int LibraryBooksId = 0, int LibraryMenuId2 = 0)
        {
            string str = DateTime.Now.ToShortDateString();
            BookLibraryViewModel model = new BookLibraryViewModel {
                Library = new main_library(),
                LibraryLoanSystem = new main_library_loan_system(),
                LibraryMenu = new main_library_menu()
            };
            if (LibraryMenuId2 != 0)
            {
                model.LibraryMenu.LibraryMenuId = LibraryMenuId2;
            }
            model.Library.LibraryBooksId = LibraryBooksId;
            model.LibraryLoanSystem.LibraryBooksId = new int?(LibraryBooksId);
            model.Library = this._Imain_libraryService.Get(model.Library);
            if ((model.Library.QuantityWithLibrary == 0) && !(this._Imain_library_loan_systemService.GetFutureBookDate(model.LibraryLoanSystem) is DBNull))
            {
                DateTime time = Convert.ToDateTime(this._Imain_library_loan_systemService.GetFutureBookDate(model.LibraryLoanSystem));
                model.LibraryLoanSystem.FutureBookDate = time;
            }
            string str2 = model.LibraryLoanSystem.FutureBookDate.ToShortDateString();
            if (str == str2)
            {
                model.Library.QuantityWithLibrary += 1;
            }
            return base.View("ViewBookDetails", model);
        }

        [CustomAuthorize]
        public ActionResult DownloadReceipt(int LibraryLoanId = 0)
        {
            BookLibraryViewModel model = new BookLibraryViewModel {
                LibraryLoanSystem = new main_library_loan_system()
            };
            model.LibraryLoanSystem.LibraryLoanId = LibraryLoanId;
            model.LibraryLoanSystem = this._Imain_library_loan_systemService.GetDownLoadReceipt(model.LibraryLoanSystem);
            model.LibraryLoanSystem.FromDate = model.LibraryLoanSystem.BookLoanFromDate;
            model.LibraryLoanSystem.ToDate = model.LibraryLoanSystem.BookLoanToDate;
            return new PartialViewAsPdf("_DownloadReceipt", model) { FileName = "Book_Receipt.pdf" };
        }

        private SelectList FillBookCategory(string BookCategory)
        {
            main_lookup entity = new main_lookup {
                LookupType = BookCategory
            };
            List<main_lookup> list = new List<main_lookup>();
            return new SelectList(this._Imain_lookupService.ListAllBookCategory(entity).ToList<main_lookup>(), "LookupValue", "LookupText");
        }

        [ValidateInput(false)]
        public ActionResult ManageBooks(BookLibraryViewModel model, string BookTitle = "", string BookCategory = "", int PageIndex = 1, int LibraryMenuId2 = 0)
        {
            if (model.Library == null)
            {
                model.Library = new main_library();
            }
            if (model.LibraryMenu == null)
            {
                model.LibraryMenu = new main_library_menu();
            }
            if (!string.IsNullOrEmpty(BookTitle))
            {
                model.Library.BookPeriodicalsTitle = BookTitle;
            }
            if (!string.IsNullOrEmpty(BookCategory))
            {
                model.Library.BookCategory = BookCategory;
            }
            if (LibraryMenuId2 != 0)
            {
                model.LibraryMenu.LibraryMenuId = LibraryMenuId2;
            }
            model.LibraryMenu = this._Imain_library_menuService.Get(model.LibraryMenu);
            model.Library.SortExp = null;
            if (model.Library.PageSize == 0)
            {
                int num = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
                model.Library.PageSize = num;
            }
            if (PageIndex == 0)
            {
                model.Library.PageIndex = 1;
            }
            else
            {
                model.Library.PageIndex = PageIndex;
            }
            model.lstBookCategory = this.FillBookCategory("BookCategory");
            model.lstLibrary = this._Imain_libraryService.GetAll(model.Library).ToList<main_library>();
            if ((model.lstLibrary != null) && (model.lstLibrary.ToList<main_library>().Count > 0))
            {
                int totalCount = model.lstLibrary.ToList<main_library>()[0].TotalCount;
                model.Library.TotalCount = totalCount;
            }
            return base.View(model);
        }

        [CustomAuthorize]
        public ActionResult ManageUserHistory(int LibraryMenuId2 = 0)
        {
            BookLibraryViewModel model = new BookLibraryViewModel {
                Library = new main_library()
            };
            if (model.LibraryMenu == null)
            {
                model.LibraryMenu = new main_library_menu();
            }
            if (LibraryMenuId2 != 0)
            {
                model.LibraryMenu.LibraryMenuId = LibraryMenuId2;
            }
            model.LibraryMenu = this._Imain_library_menuService.Get(model.LibraryMenu);
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                model.Library.StudentID = Convert.ToInt32(directValue.StudentId);
            }
            string str = DateTime.Now.ToShortDateString();
            model.Library.CurrentDate = Convert.ToDateTime(str);
            model.lstLibrary = this._Imain_libraryService.GetPastBooks(model.Library).ToList<main_library>();
            model.lstLibraryPresentBooks = this._Imain_libraryService.GetPresentBooks(model.Library).ToList<main_library>();
            model.lstLibraryFutureBooks = this._Imain_libraryService.GetFutureBooks(model.Library).ToList<main_library>();
            return base.View(model);
        }

        public ActionResult PartialShowBookDetails(int LibraryBooksId = 0, int LibraryMenuId2 = 0)
        {
            string str = DateTime.Now.ToShortDateString();
            BookLibraryViewModel model = new BookLibraryViewModel {
                Library = new main_library(),
                LibraryLoanSystem = new main_library_loan_system()
            };
            model.Library.LibraryBooksId = LibraryBooksId;
            model.LibraryLoanSystem.LibraryBooksId = new int?(LibraryBooksId);
            model.LibraryMenu = new main_library_menu();
            if (LibraryMenuId2 != 0)
            {
                model.LibraryMenu.LibraryMenuId = LibraryMenuId2;
            }
            model.Library = this._Imain_libraryService.Get(model.Library);
            if ((model.Library.QuantityWithLibrary == 0) && !(this._Imain_library_loan_systemService.GetFutureBookDate(model.LibraryLoanSystem) is DBNull))
            {
                DateTime time = Convert.ToDateTime(this._Imain_library_loan_systemService.GetFutureBookDate(model.LibraryLoanSystem));
                model.LibraryLoanSystem.FutureBookDate = time;
            }
            string str2 = model.LibraryLoanSystem.FutureBookDate.ToShortDateString();
            if (str == str2)
            {
                model.Library.QuantityWithLibrary += 1;
            }
            return this.PartialView("_PartialViewBookDetails", model);
        }

        [CustomAuthorize]
        public JsonResult RenewBook(int LibraryLoanId = 0)
        {
            int num = 0;
            int num2 = 0;
            RenewStatus data = new RenewStatus {
                IsRenew = false
            };
            BookLibraryViewModel model = new BookLibraryViewModel {
                LibraryLoanSystem = new main_library_loan_system(),
                Library = new main_library()
            };
            model.LibraryLoanSystem.LibraryLoanId = LibraryLoanId;
            if (LibraryLoanId != 0)
            {
                model.LibraryLoanSystem = this._Imain_library_loan_systemService.Get(model.LibraryLoanSystem);
            }
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                model.Library.StudentID = directValue.RegistrationId;
                if (((directValue.UserType == "Student") || (directValue.UserType == "")) || string.IsNullOrEmpty(directValue.UserType))
                {
                    num = 5;
                    DateTime time = Convert.ToDateTime(model.LibraryLoanSystem.BookLoanToDate).AddDays((double) num);
                    model.LibraryLoanSystem.BookLoanToDate = new DateTime?(time);
                    num2 = this._Imain_library_loan_systemService.UpdateTodateForRenew(model.LibraryLoanSystem);
                }
                if (directValue.UserType == "Faculty")
                {
                    num = 14;
                    DateTime time2 = Convert.ToDateTime(model.LibraryLoanSystem.BookLoanToDate).AddDays((double) num);
                    model.LibraryLoanSystem.BookLoanToDate = new DateTime?(time2);
                    num2 = this._Imain_library_loan_systemService.UpdateTodateForRenew(model.LibraryLoanSystem);
                }
                data.IsRenew = num2 > 0;
            }
            return base.Json(data);
        }

        [HttpPost, CustomAuthorize]
        public JsonResult SaveBookDetails(int LibraryBooksId, string FromDate = "", string ToDate = "")
        {
            main_library_loan_system entity = new main_library_loan_system();
            main_library _library = new main_library();
            string str2 = null;
            int num = 0;
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                entity.StudentId = directValue.StudentId;
            }
            entity.LibraryBooksId = new int?(LibraryBooksId);
            _library.LibraryBooksId = LibraryBooksId;
            int num2 = Convert.ToInt32(this._Imain_libraryService.Get(_library).QuantityWithLibrary);
            int num3 = 0;
            num = (num2 == 0) ? -1 : Convert.ToInt32((int) (num2 - 1));
            BorrowBookStatus data = new BorrowBookStatus {
                LibraryLoanId = 0
            };
            main_library_loan_system _system2 = new main_library_loan_system {
                StudentId = entity.StudentId,
                LibraryBooksId = entity.LibraryBooksId,
                CurrentDate = Convert.ToDateTime(DateTime.Now.ToShortDateString())
            };
            if (this._Imain_library_loan_systemService.CheckUserHasBook(_system2).ToList<main_library_loan_system>().Count<main_library_loan_system>() > 0)
            {
                data.LibraryLoanId = -100;
            }
            else
            {
                entity.QuantityAfterLoan = new int?(num);
                entity.BookLoanFromDate = new DateTime?(Convert.ToDateTime(FromDate));
                entity.BookLoanToDate = new DateTime?(Convert.ToDateTime(ToDate));
                num3 = this._Imain_library_loan_systemService.AddEditDelete(entity);
                str2 = "Unable to update Book";
                if (num3 < 0)
                {
                    data.LibraryLoanId = 0;
                }
                else
                {
                    data.LibraryLoanId = num3;
                }
            }
            return base.Json(data);
        }

        public ActionResult ShowBookDetails(int LibraryBooksId = 0, int LibraryMenuId2 = 0)
        {
            string str = DateTime.Now.ToShortDateString();
            string str2 = string.Empty;
            BookLibraryViewModel model = new BookLibraryViewModel {
                Library = new main_library(),
                LibraryLoanSystem = new main_library_loan_system(),
                LibraryMenu = new main_library_menu()
            };
            if (LibraryMenuId2 != 0)
            {
                model.LibraryMenu.LibraryMenuId = LibraryMenuId2;
            }
            model.Library.LibraryBooksId = LibraryBooksId;
            model.LibraryLoanSystem.LibraryBooksId = new int?(LibraryBooksId);
            model.Library = this._Imain_libraryService.Get(model.Library);
            if (model.Library.QuantityWithLibrary <= 0)
            {
                model.LibraryLoanSystem.BookAvailbleOn = this._Imain_library_loan_systemService.GetFutureBookDate(model.LibraryLoanSystem).ToString();
                if (model.LibraryLoanSystem.BookAvailbleOn != "")
                {
                    model.LibraryLoanSystem.FutureBookDate = Convert.ToDateTime(model.LibraryLoanSystem.BookAvailbleOn);
                }
                str2 = model.LibraryLoanSystem.FutureBookDate.ToShortDateString();
                if (str == str2)
                {
                    model.Library.QuantityWithLibrary += 1;
                    this._Imain_libraryService.UpdateLibraryWithQuantity(model.Library);
                }
            }
            return this.PartialView("_ShowBookDetails", model);
        }

        public class BorrowBookStatus
        {
            public int LibraryLoanId { get; set; }
        }

        public class RenewStatus
        {
            public bool IsRenew { get; set; }

            public string Url { get; set; }
        }
    }
}

