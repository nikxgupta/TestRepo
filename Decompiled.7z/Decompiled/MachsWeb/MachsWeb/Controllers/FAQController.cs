﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class FAQController : BaseController
    {
        private Imain_footer_helpService _Imain_footer_helpService;
        private Imain_help_faqService _Imain_help_faqService;

        public FAQController(Imain_help_faqService main_help_faq, Imain_footer_helpService Imain_footer_helpService)
        {
            this._Imain_help_faqService = main_help_faq;
            this._Imain_footer_helpService = Imain_footer_helpService;
        }

        [ValidateInput(false)]
        public ActionResult ManageQuestions(FAQViewModel model, string Question = "", int PageIndex = 1, int FooterHelpId = 0)
        {
            if (model.FAQ == null)
            {
                model = new FAQViewModel();
            }
            if (model.FooterHelp == null)
            {
                model.FooterHelp = new main_footer_help();
            }
            if (model.FAQ == null)
            {
                model.FAQ = new main_help_faq();
            }
            if (FooterHelpId != 0)
            {
                model.FooterHelp.FooterHelpId = FooterHelpId;
            }
            model.FooterHelp = this._Imain_footer_helpService.Get(model.FooterHelp);
            model.FAQ.SortExp = null;
            if (model.FAQ.PageSize == 0)
            {
                int num = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
                model.FAQ.PageSize = num;
            }
            if (PageIndex == 0)
            {
                model.FAQ.PageIndex = 1;
            }
            else
            {
                model.FAQ.PageIndex = PageIndex;
            }
            if (!string.IsNullOrEmpty(model.FAQ.Question))
            {
                model.FAQ.PageIndex = 1;
            }
            model.lstFAQ = new List<main_help_faq>();
            model.FAQ.TotalCount = 0;
            model.lstFAQ = this._Imain_help_faqService.GetAll(model.FAQ).ToList<main_help_faq>();
            model.lstFAQ = model.lstFAQ.FindAll(obj => !obj.IsHide).ToList<main_help_faq>();
            if ((model.lstFAQ != null) && (model.lstFAQ.Count > 0))
            {
                int totalCount = model.lstFAQ[0].TotalCount;
                model.FAQ.TotalCount = totalCount;
            }
            model.FooterHelp.FooterHelpId = FooterHelpId;
            model.FooterHelp = this._Imain_footer_helpService.Get(model.FooterHelp);
            return base.View(model);
        }

        public ActionResult ShowQuestionDetails(int HelpFAQId = 0)
        {
            FAQViewModel model = new FAQViewModel {
                FAQ = new main_help_faq()
            };
            model.FAQ.HelpFAQId = HelpFAQId;
            model.FAQ = this._Imain_help_faqService.Get(model.FAQ);
            return this.PartialView("_ShowQuestionDetails", model);
        }
    }
}

