﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class BannerController : BaseController
    {
        private Imain_bannerService _Imain_bannerService;
        private Imain_menu_dataService _Imain_menu_dataService;
        private Imain_menuService _Imain_menuService;

        public BannerController(Imain_bannerService main_banner, Imain_menuService main_menu, Imain_menu_dataService main_menu_dataService)
        {
            this._Imain_bannerService = main_banner;
            this._Imain_menuService = main_menu;
            this._Imain_menu_dataService = main_menu_dataService;
        }

        public ActionResult ManageBanner(int ParentId = 0, int ChildId = 0)
        {
            BannerViewModel model = new BannerViewModel {
                Banner = new main_banner(),
                lstbanner = null
            };
            model.lstbanner = this._Imain_bannerService.GetAllCampusLife(model.Banner).ToList<main_banner>();
            model.MenuId = ChildId;
            model.ParentId = ParentId;
            return base.View("ManageBanner", model);
        }
    }
}

