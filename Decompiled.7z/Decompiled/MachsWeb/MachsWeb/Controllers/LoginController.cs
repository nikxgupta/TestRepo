﻿namespace MachsWeb.Controllers
{
    using Machs.Common;
    using Machs.Common.Login;
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Security;

    public class LoginController : BaseController
    {
        private Imain_registrationService _Imain_registrationService;

        public LoginController(Imain_registrationService main_registrationService)
        {
            this._Imain_registrationService = main_registrationService;
        }

        [HttpGet]
        public ActionResult ChangePassword() => 
            base.View();

        [HttpPost]
        public ActionResult ChangePassword(LoginViewModel model)
        {
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                directValue = this._Imain_registrationService.Get(directValue);
                if (directValue.Password == model.Student.Password)
                {
                    model.Student.RegistrationId = directValue.RegistrationId;
                    if (this._Imain_registrationService.ChangePassword(model.Student) > 0)
                    {
                        base.TempData["chmsg"] = Machs.Common.Login.Login.PwdChangedSuccess;
                        return base.RedirectToAction("Index", "Home");
                    }
                    base.TempData["err"] = Machs.Common.Login.Login.UnableToChangePwd;
                    return base.RedirectToAction("ChangePassword", "Login");
                }
                base.TempData["err"] = Machs.Common.Login.Login.EnterCorrectPwd;
                return base.RedirectToAction("ChangePassword", "Login");
            }
            return base.View(model);
        }

        public ActionResult EditProfile()
        {
            LoginViewModel model = new LoginViewModel {
                Student = new main_registration()
            };
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                model.Student = this._Imain_registrationService.Get(directValue);
            }
            return base.View(model);
        }

        [HttpPost]
        public ActionResult EditProfile(LoginViewModel model)
        {
            string addToastMessageForStudent = null;
            string unableToaddStudent = null;
            if (model.Student.RegistrationId == 0)
            {
                addToastMessageForStudent = Machs.Common.Login.Login.AddToastMessageForStudent;
                unableToaddStudent = Machs.Common.Login.Login.UnableToaddStudent;
            }
            else
            {
                addToastMessageForStudent = Machs.Common.Login.Login.EditToastMessageForAStudent;
                unableToaddStudent = Machs.Common.Login.Login.UnableToUpdateToastMessageForStudent;
            }
            if (this._Imain_registrationService.AddEditDelete(model.Student) < 0)
            {
                base.TempData["err"] = unableToaddStudent;
            }
            else
            {
                base.TempData["msg"] = addToastMessageForStudent;
            }
            return base.RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public ActionResult ForgotPassword(main_registration model)
        {
            string email = string.Empty;
            if (!((model == null) || string.IsNullOrEmpty(model.Email)))
            {
                email = model.Email;
                model = this._Imain_registrationService.GetStudentByEmailId(model);
            }
            if (model.RegistrationId > 0)
            {
                return base.View("Welcome");
            }
            base.TempData["err"] = "Email not registered.";
            return base.RedirectToAction("ForgotPassword", new { Email = email });
        }

        public ActionResult ForgotPassword(string Email = "")
        {
            main_registration model = new main_registration();
            if (!string.IsNullOrEmpty(Email))
            {
                model.Email = Email;
            }
            return base.View(model);
        }

        public ActionResult Index() => 
            base.View();

        [AllowAnonymous]
        public ActionResult Login(string returnUrl = "") => 
            this.View("Login", null, returnUrl);

        [HttpPost, AllowAnonymous]
        public ActionResult Login(string Email, string Password, string returnUrl)
        {
            main_registration objUser = new main_registration {
                Email = Email,
                Password = Password
            };
            if (this._Imain_registrationService.CheckStudentLogin(objUser))
            {
                string str = this.RedirectToLocal_New(objUser, returnUrl);
                return base.Json(str);
            }
            LoginError data = new LoginError {
                Message = "Please enter valid Email Address and Password"
            };
            return base.Json(data);
        }

        [HttpGet]
        public ActionResult LoginRegistration(string returnUrl = "")
        {
            LoginViewModel model = new LoginViewModel();
            if (model.Student == null)
            {
                model.Student = new main_registration();
            }
            if (!string.IsNullOrEmpty(returnUrl))
            {
                model.returnUrl = returnUrl;
            }
            return base.View(model);
        }

        public ActionResult LogOut()
        {
            if (MachsSession.IsInSession("CurrentUser"))
            {
                main_registration directValue = (main_registration) MachsSession.GetDirectValue("CurrentUser");
                this._Imain_registrationService.InsertLastLoginDate(directValue);
                MachsSession.RemoveSessionItem("CurrentUser");
            }
            FormsAuthentication.SignOut();
            MachsSession.ClearSession();
            MachsSession.AbandonSession();
            return base.RedirectToAction("Index", "Home");
        }

        private string RedirectToLocal_New(main_registration model, string returnUrl)
        {
            if (!((returnUrl == "/") || string.IsNullOrEmpty(returnUrl)))
            {
                FormsAuthentication.SetAuthCookie(model.Email, false);
                return HttpUtility.HtmlDecode(returnUrl);
            }
            FormsAuthentication.SetAuthCookie(model.Email, false);
            return base.Url.Action("Index", "Home");
        }

        [HttpPost]
        public ActionResult Registration(LoginViewModel model)
        {
            int num = 0;
            main_registration studentByStudentId = new main_registration {
                StudentId = model.Student.StudentId
            };
            studentByStudentId = this._Imain_registrationService.GetStudentByStudentId(studentByStudentId);
            if (studentByStudentId.RegistrationId > 0)
            {
                base.TempData["err"] = Machs.Common.Login.Login.ConfirmStudentRegistration;
                return base.RedirectToAction("LoginRegistration");
            }
            studentByStudentId.Email = model.Student.Email;
            if (this._Imain_registrationService.GetStudentByEmailId(studentByStudentId).RegistrationId > 0)
            {
                base.TempData["err"] = Machs.Common.Login.Login.ConfirmStudentRegistrationForEmail;
                return base.RedirectToAction("LoginRegistration");
            }
            model.Student.Password = Utility.GetUniqueKeyWithPrefix("M", 7);
            num = this._Imain_registrationService.AddEditDelete(model.Student);
            return base.RedirectToAction("Welcome");
        }

        [HttpGet]
        public ActionResult Registration(string email, string fullname, int Machs)
        {
            main_registration model = new main_registration();
            if (!string.IsNullOrEmpty(email))
            {
                model.Email = email;
            }
            if (!string.IsNullOrEmpty(fullname))
            {
                model.StudentFullName = fullname;
            }
            return base.View(model);
        }

        public ActionResult SessionTimeOut() => 
            base.View();

        public ActionResult Welcome() => 
            base.View("Welcome");

        public class LoginError
        {
            public string Message { get; set; }

            public string Success { get; set; }
        }
    }
}

