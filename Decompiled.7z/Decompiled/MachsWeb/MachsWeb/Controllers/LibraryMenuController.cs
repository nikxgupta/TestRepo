﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class LibraryMenuController : BaseController
    {
        private Imain_library_menuService _Imain_library_menuService;
        private Imain_libraryService _Imain_libraryService;
        private Imain_lookupService _Imain_lookupService;

        public LibraryMenuController(Imain_libraryService Imain_libraryService, Imain_lookupService Imain_lookupService, Imain_library_menuService Imain_library_menuService)
        {
            this._Imain_libraryService = Imain_libraryService;
            this._Imain_lookupService = Imain_lookupService;
            this._Imain_library_menuService = Imain_library_menuService;
        }

        public ActionResult LibraryMenuSideBar()
        {
            BookLibraryViewModel model = new BookLibraryViewModel {
                LibraryMenu = new main_library_menu()
            };
            model.lstLibraryMenu = this._Imain_library_menuService.GetAll(model.LibraryMenu).ToList<main_library_menu>();
            return this.PartialView("_LibraryMenuSideBar", model);
        }

        public ActionResult ManageLibraryMenu(int LibraryMenuId2 = 0)
        {
            BookLibraryViewModel model = new BookLibraryViewModel {
                LibraryMenu = new main_library_menu()
            };
            main_library_menu _menu = new main_library_menu();
            model.lstLibraryMenu = this._Imain_library_menuService.GetAll(model.LibraryMenu).ToList<main_library_menu>();
            if (LibraryMenuId2 == 0)
            {
                _menu = model.lstLibraryMenu.FindAll(obj => obj.Displayorder == 1).ToList<main_library_menu>()[0];
                model.LibraryMenu.LibraryMenuId = _menu.LibraryMenuId;
            }
            else
            {
                model.LibraryMenu.LibraryMenuId = LibraryMenuId2;
            }
            model.LibraryMenu = this._Imain_library_menuService.Get(model.LibraryMenu);
            return base.View("ManageLibraryMenu", model);
        }
    }
}

