﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using Rotativa;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class CourseCurriculumController : BaseController
    {
        private Imain_curriculum_infoService _Imain_curriculum_infoService;
        private Imain_curriculum_yearService _Imain_curriculum_yearService;
        private Imain_lookupService _Imain_lookupService;
        private Imain_menuService _Imain_menuService;

        public CourseCurriculumController(Imain_curriculum_yearService Imain_curriculum_yearService, Imain_lookupService Imain_lookupService, Imain_curriculum_infoService Imain_curriculum_infoService, Imain_menuService main_menu)
        {
            this._Imain_curriculum_yearService = Imain_curriculum_yearService;
            this._Imain_lookupService = Imain_lookupService;
            this._Imain_curriculum_infoService = Imain_curriculum_infoService;
            this._Imain_menuService = main_menu;
        }

        public ActionResult DownloadCoursePlan(int CurriculumYearId = 1, int ParentId = 0, int YearValue = 1)
        {
            CurriculumViewModel model = new CurriculumViewModel {
                CurriculumYear = new main_curriculum_year(),
                CurriculumInfo = new main_curriculum_info()
            };
            if (ParentId != 0)
            {
                model.ParentId = ParentId;
            }
            model.YearValue = YearValue;
            main_menu _menu = new main_menu {
                MenuId = model.ParentId
            };
            _menu = this._Imain_menuService.Get(_menu);
            model.ParentName = _menu.MenuName;
            model.CurriculumInfo.CurriculumYearId = new int?(CurriculumYearId);
            model.lstCurriculumInfo = this._Imain_curriculum_infoService.GetAll_ByCurriculumYearId(model.CurriculumInfo).ToList<main_curriculum_info>();
            model.lstAcademicTerm = this.FillLookupByType("AcademicTerm");
            return new PartialViewAsPdf("_downloadCoursePlan", model) { FileName = model.ParentName + "_Year_" + model.YearValue.ToString() + "_CoursePlan.pdf" };
        }

        public List<main_lookup> FillLookupByType(string LookupType = "")
        {
            main_lookup entity = new main_lookup {
                LookupType = LookupType
            };
            List<main_lookup> list = new List<main_lookup>();
            return this._Imain_lookupService.GetAll(entity).ToList<main_lookup>();
        }

        [ValidateInput(false)]
        public ActionResult ManageCurriculumYear(CurriculumViewModel model, int ParentId = 0, int ChildId = 0, int PageIndex = 1, int YearValue = 1)
        {
            if (model.CurriculumYear == null)
            {
                model.CurriculumYear = new main_curriculum_year();
            }
            if (model.CurriculumInfo == null)
            {
                model.CurriculumInfo = new main_curriculum_info();
            }
            if (ChildId != 0)
            {
                model.ChildId = ChildId;
            }
            if (ParentId != 0)
            {
                model.ParentId = ParentId;
            }
            model.CurriculumYear.ParentId = new int?(model.ParentId);
            model.lstCurriculumYear = this._Imain_curriculum_yearService.GetAll_ByParentId(model.CurriculumYear).ToList<main_curriculum_year>();
            model.CurriculumYear.YearValue = YearValue.ToString();
            model.CurriculumYear = this._Imain_curriculum_yearService.Get_ByYearValue(model.CurriculumYear);
            model.CurriculumInfo.CurriculumYearId = new int?(model.CurriculumYear.CurriculumYearId);
            model.lstCurriculumInfo = this._Imain_curriculum_infoService.GetAll_ByCurriculumYearId(model.CurriculumInfo).ToList<main_curriculum_info>();
            model.lstAcademicTerm = this.FillLookupByType("AcademicTerm");
            return base.View(model);
        }

        public string ShowCurriculumDetails(int CurriculumInfoId = 0)
        {
            CurriculumViewModel model = new CurriculumViewModel {
                CurriculumInfo = new main_curriculum_info()
            };
            model.CurriculumInfo.CurriculumInfoId = CurriculumInfoId;
            model.CurriculumInfo = this._Imain_curriculum_infoService.Get(model.CurriculumInfo);
            return model.CurriculumInfo.CourseDescription;
        }
    }
}

