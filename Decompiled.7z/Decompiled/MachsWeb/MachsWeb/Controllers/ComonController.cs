﻿namespace MachsWeb.Controllers
{
    using Machs.Common;
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Web.Mvc;

    public class ComonController : BaseController
    {
        private Imain_bannerService _Imain_bannerService;
        private Imain_menuService _Imain_menuService;

        public ComonController(Imain_bannerService main_banner, Imain_menuService main_menu)
        {
            this._Imain_bannerService = main_banner;
            this._Imain_menuService = main_menu;
        }

        [AllowAnonymous]
        public ActionResult ChangeCulture(int CultureLang)
        {
            MachsSession.CurrentUICulture = CultureLang;
            if (CultureLang == 2)
            {
                Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture("ar");
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
            }
            if (MachsSession.IsInSession("CurrentCulture"))
            {
                MachsSession.RemoveSessionItem("CurrentCulture");
            }
            MachsSession.AddSessionItem("CurrentCulture", CultureLang);
            return this.Redirect(base.Request.UrlReferrer.ToString());
        }

        public ActionResult ShowBannerDetails(int BannerId)
        {
            main_banner _banner = new main_banner {
                BannerId = BannerId
            };
            _banner = this._Imain_bannerService.Get(_banner);
            return base.View(_banner);
        }

        public ActionResult SideBarSecondLevel(int ParentId, int ChildId = 0)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                ParentMenuData = new main_menu()
            };
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ParentId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            model.lstMenu = this._Imain_menuService.GetAllTreeView(model.Menu).ToList<main_menu>();
            return this.PartialView("_SideBarSecondLevel", model);
        }

        public ActionResult SideBarThirdLevel(int ParentId, int ChildId = 0)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                ParentMenuData = new main_menu()
            };
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ParentId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            model.lstMenu = this._Imain_menuService.GetAllTreeView(model.Menu).ToList<main_menu>();
            return this.PartialView("_SideBarThirdLevel", model);
        }

        public ActionResult TopBanner()
        {
            main_banner entity = new main_banner();
            List<main_banner> model = null;
            model = this._Imain_bannerService.GetAllIndexPage(entity).ToList<main_banner>();
            return base.View("_HomeBanner", model);
        }
    }
}

