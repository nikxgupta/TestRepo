﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class DownloadsController : BaseController
    {
        private Imain_downloadsService _Imain_downloadsService;
        private Imain_menuService _Imain_menuService;

        public DownloadsController(Imain_downloadsService main_downloadsService, Imain_menuService main_menu)
        {
            this._Imain_downloadsService = main_downloadsService;
            this._Imain_menuService = main_menu;
        }

        [ValidateInput(false)]
        public ActionResult ManageDownloads(DownloadsViewModel model, int ParentId = 0, int ChildId = 0)
        {
            if (model.Downloads == null)
            {
                model.Downloads = new main_downloads();
            }
            model.ParentId = ParentId;
            model.ParentMenu = new main_menu();
            if (ChildId != 0)
            {
                model.ParentMenu.MenuId = ChildId;
            }
            model.ParentMenu = this._Imain_menuService.Get(model.ParentMenu);
            model.Downloads.MenuId = ParentId;
            model.lstDownloads = this._Imain_downloadsService.GetAll(model.Downloads);
            if (ParentId != 0)
            {
                int? nullable;
                main_menu _menu = new main_menu {
                    MenuId = ParentId
                };
                _menu = this._Imain_menuService.Get(_menu);
                if (!(_menu.ParentId.HasValue && !(((nullable = _menu.ParentId).GetValueOrDefault() == 0) && nullable.HasValue)))
                {
                    model.Level = 2;
                }
                else
                {
                    _menu.MenuId = Convert.ToInt32(_menu.ParentId);
                    _menu = this._Imain_menuService.Get(_menu);
                    if (!(_menu.ParentId.HasValue && !(((nullable = _menu.ParentId).GetValueOrDefault() == 0) && nullable.HasValue)))
                    {
                        model.Level = 3;
                    }
                }
            }
            else
            {
                model.Level = 1;
            }
            return base.View(model);
        }
    }
}

