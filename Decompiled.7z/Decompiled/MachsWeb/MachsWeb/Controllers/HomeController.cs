﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class HomeController : BaseController
    {
        private Imain_CAC_blockService _Imain_CAC_blockService;
        private Imain_footer_contactusService _Imain_footer_contactusService;
        private Imain_footer_helpService _Imain_footer_helpService;
        private Imain_footer_socialService _Imain_footer_socialService;
        private Imain_footer_websiteService _Imain_footer_websiteService;
        private Imain_home_galleryService _Imain_home_galleryService;
        private Imain_lookupService _Imain_lookupService;
        private Imain_menu_dataService _Imain_menu_dataService;
        private Imain_menuService _Imain_menuService;
        private Imain_small_home_iconService _Imain_small_home_iconService;
        private Imain_eventService _ImainEvents;
        private Imain_home_popup_containerService _ImainHomePopup;
        private Imain_newsService _ImainNews;

        public HomeController(Imain_menuService main_menu, Imain_menu_dataService main_menu_dataService, Imain_newsService news, Imain_eventService events, Imain_home_popup_containerService mainHomePopup, Imain_CAC_blockService Imain_CAC_blockService, Imain_small_home_iconService Imain_small_home_iconService, Imain_footer_websiteService Imain_footer_websiteService, Imain_footer_helpService Imain_footer_helpService, Imain_footer_socialService Imain_footer_socialService, Imain_footer_contactusService Imain_footer_contactusService, Imain_home_galleryService Imain_home_galleryService, Imain_lookupService Imain_lookupService)
        {
            this._Imain_menuService = main_menu;
            this._Imain_menu_dataService = main_menu_dataService;
            this._ImainNews = news;
            this._ImainEvents = events;
            this._ImainHomePopup = mainHomePopup;
            this._Imain_CAC_blockService = Imain_CAC_blockService;
            this._Imain_small_home_iconService = Imain_small_home_iconService;
            this._Imain_footer_websiteService = Imain_footer_websiteService;
            this._Imain_footer_helpService = Imain_footer_helpService;
            this._Imain_footer_socialService = Imain_footer_socialService;
            this._Imain_footer_contactusService = Imain_footer_contactusService;
            this._Imain_home_galleryService = Imain_home_galleryService;
            this._Imain_lookupService = Imain_lookupService;
        }

        public ActionResult accreditation() => 
            base.View();

        public ViewResult AddEditGPARow(string ItemIdno)
        {
            GPAViewModel model = new GPAViewModel {
                divId = ItemIdno,
                lstGrade = this.FillLookupByType("Grade")
            };
            return base.View("_AddEditGPARow", model);
        }

        public ActionResult contactus() => 
            base.View();

        public ActionResult Events(int MenuId = 0) => 
            base.View("_EventsCalendar", MenuId);

        public ActionResult FillBlockTemplate(int CACBlockId)
        {
            HomeViewModel model = new HomeViewModel {
                MainCACBlock = new main_CAC_block()
            };
            model.MainCACBlock.CACBlockId = CACBlockId;
            model.MainCACBlock = this._Imain_CAC_blockService.Get(model.MainCACBlock);
            return base.View(model);
        }

        public ActionResult FillChildMenuItem(int ChildId, int ParentId)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                MenuData = new main_menu_data()
            };
            model.MenuData.MenuId = ChildId;
            model.MenuData = this._Imain_menu_dataService.ListAllSubMenuByMenuId(model.MenuData);
            model.ParentMenuData = new main_menu();
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ChildId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            model.lstMenu = this._Imain_menuService.GetAllTreeView(model.Menu).ToList<main_menu>();
            return base.View("FillChildMenuItem", model);
        }

        public ActionResult FillFooterHelpTemplate(int FooterHelpId)
        {
            main_footer_help _help = new main_footer_help {
                FooterHelpId = FooterHelpId
            };
            _help = this._Imain_footer_helpService.Get(_help);
            return base.View(_help);
        }

        public ActionResult FillFooterWebSiteTemplate(int FooterWebsiteId)
        {
            main_footer_website _website = new main_footer_website {
                FooterWebsiteId = FooterWebsiteId
            };
            _website = this._Imain_footer_websiteService.Get(_website);
            return base.View(_website);
        }

        public ActionResult FillIconTemplate(int SmallHomeIconId)
        {
            HomeViewModel model = new HomeViewModel {
                Mainsmallhomeicon = new main_small_home_icon()
            };
            model.Mainsmallhomeicon.SmallHomeIconId = SmallHomeIconId;
            model.Mainsmallhomeicon = this._Imain_small_home_iconService.Get(model.Mainsmallhomeicon);
            return base.View(model);
        }

        public SelectList FillLookupByType(string LookupType = "")
        {
            main_lookup entity = new main_lookup {
                LookupType = LookupType
            };
            List<main_lookup> list = new List<main_lookup>();
            return new SelectList(this._Imain_lookupService.GetAll(entity).ToList<main_lookup>(), "LookupValue", "LookupText");
        }

        public ActionResult FillParentMenuItem(int ChildId)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                MenuData = new main_menu_data()
            };
            model.MenuData.MenuId = ChildId;
            model.MenuData = this._Imain_menu_dataService.ListAllSubMenuByMenuId(model.MenuData);
            return base.View("FillParentMenuItem", model);
        }

        public ActionResult FillThirdLevelMenuItem(int ParentId, int ChildId = 0)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                ParentMenuData = new main_menu()
            };
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ParentId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            model.MenuData = new main_menu_data();
            if (ChildId == 0)
            {
                ChildId = model.lstParentChilds[0].MenuId;
            }
            model.MenuData.MenuId = ChildId;
            model.MenuData = this._Imain_menu_dataService.ListAllSubMenuByMenuId(model.MenuData);
            return base.View("FillThirdLevelMenuItem", model);
        }

        [HttpPost]
        public ActionResult GetEventsForMonth(int month, int year, int ParentId = 0, int ChildId = 0)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            List<main_event> list = null;
            main_event entity = new main_event {
                MenuId = ParentId,
                Month = month.ToString(),
                Year = year.ToString()
            };
            list = this._ImainEvents.GetEventsByMonth(entity).ToList<main_event>();
            foreach (main_event _event2 in list)
            {
                string[] strArray = _event2.MEventDate.ToString().Split(new string[] { "/" }, StringSplitOptions.None);
                data.Add(strArray[1], $"event on day {strArray[1]}/{month}/{year}");
            }
            return base.Json(data);
        }

        public ActionResult Index()
        {
            HomeViewModel model = new HomeViewModel {
                HomePopup = new main_home_popup_container(),
                MainCACBlock = new main_CAC_block()
            };
            model.HomePopup.HomePopupContainerId = "ContainerId1";
            model.HomePopup = this._ImainHomePopup.Get(model.HomePopup);
            model.lstMainCACBlock = this._Imain_CAC_blockService.GetAll(model.MainCACBlock).ToList<main_CAC_block>();
            return base.View(model);
        }

        public ActionResult machscampus() => 
            base.View();

        public ActionResult ManageGPACalculator(int ChildId = 0, int ParentId = 0)
        {
            GPAViewModel model = new GPAViewModel();
            if (ChildId != 0)
            {
                model.ChildId = ChildId;
            }
            if (ParentId != 0)
            {
                model.ParentId = ParentId;
            }
            return base.View("ManageGPACalculator", model);
        }

        public ActionResult MissionVision() => 
            base.View();

        public ActionResult News(int MenuId = 0)
        {
            List<main_news> model = null;
            main_news entity = new main_news {
                MenuId = MenuId
            };
            model = this._ImainNews.GetNews(entity).ToList<main_news>();
            return base.View("_News_Banner", model);
        }

        public ActionResult photogallery() => 
            base.View();

        public ActionResult ShowAlumini() => 
            base.View();

        public string ShowContactUsMap()
        {
            main_footer_contactus _contactus = new main_footer_contactus();
            return this._Imain_footer_contactusService.Get(_contactus).GoogleMapCode;
        }

        public ActionResult ShowDayEvents(DateTime dateText, int ParentId = 0, int ChildId = 0)
        {
            List<main_event> model = null;
            main_event entity = new main_event {
                MenuId = ParentId,
                MEventDate = new DateTime?(dateText)
            };
            model = this._ImainEvents.GetEventsByDay(entity).ToList<main_event>();
            return this.PartialView("_ShowDayMonthEvents", model);
        }

        public ActionResult ShowDynamicMenu()
        {
            MenuViewModel model = new MenuViewModel();
            model.lstMenu = this._Imain_menuService.GetAllTreeView(model.Menu).ToList<main_menu>();
            model.lstFirstLevelMenu = model.lstMenu.FindAll(delegate (main_menu obj) {
                int? nullable;
                return !obj.ParentId.HasValue || (((nullable = obj.ParentId).GetValueOrDefault() == 0) && nullable.HasValue);
            }).ToList<main_menu>();
            return this.PartialView("_dynamicMenu", model);
        }

        public ActionResult ShowEventDetails(int EventID, int ParentId = 0, int ChildId = 0)
        {
            main_event _event = new main_event {
                MEventId = EventID
            };
            _event = this._ImainEvents.Get(_event);
            return base.View(_event);
        }

        public ActionResult ShowFooterContactUs()
        {
            main_footer_contactus _contactus = new main_footer_contactus();
            _contactus = this._Imain_footer_contactusService.Get(_contactus);
            return base.View("_ShowFooterContactUs", _contactus);
        }

        public ActionResult ShowFooterHelp()
        {
            main_footer_help entity = new main_footer_help();
            List<main_footer_help> model = new List<main_footer_help>();
            model = this._Imain_footer_helpService.GetAll(entity).ToList<main_footer_help>();
            return this.PartialView("_ShowFooterHelp", model);
        }

        public ActionResult ShowFooterSocial()
        {
            main_footer_social entity = new main_footer_social();
            List<main_footer_social> model = new List<main_footer_social>();
            model = this._Imain_footer_socialService.GetAll(entity).ToList<main_footer_social>();
            return this.PartialView("_ShowFooterSocial", model);
        }

        public ActionResult ShowFooterWebsite()
        {
            main_footer_website entity = new main_footer_website();
            List<main_footer_website> model = new List<main_footer_website>();
            model = this._Imain_footer_websiteService.GetAll(entity).ToList<main_footer_website>();
            return this.PartialView("_ShowFooterWebsite", model);
        }

        public ActionResult ShowGalleryDetails()
        {
            HomeViewModel model = new HomeViewModel {
                HomeGallery = new main_home_gallery()
            };
            model.lstHomeGalleries = this._Imain_home_galleryService.GetAll(model.HomeGallery).ToList<main_home_gallery>();
            model.lstHomeGalleries = model.lstHomeGalleries.FindAll(delegate (main_home_gallery obj) {
                bool isHide = obj.IsHide;
                return !obj.IsHide;
            }).ToList<main_home_gallery>();
            return this.PartialView("_ShowGallery", model);
        }

        public ActionResult ShowHomeFooterIcon()
        {
            HomeViewModel model = new HomeViewModel {
                Mainsmallhomeicon = new main_small_home_icon()
            };
            model.lstMainsmallhomeicon = this._Imain_small_home_iconService.GetAll(model.Mainsmallhomeicon).ToList<main_small_home_icon>();
            return this.PartialView("_ShowHomeFooterIcon", model);
        }

        public ActionResult ShowMonthEvents(int month, int year, int ParentId = 0, int ChildId = 0)
        {
            List<main_event> model = null;
            main_event entity = new main_event {
                MenuId = ParentId,
                Month = month.ToString(),
                Year = year.ToString()
            };
            model = this._ImainEvents.GetEventsByMonthALL(entity).ToList<main_event>();
            return this.PartialView("_ShowDayMonthEvents", model);
        }

        public ActionResult ShowNewsDetails(int NewsID, int ParentId = 0, int ChildId = 0)
        {
            main_news _news = new main_news {
                MNewsId = NewsID
            };
            _news = this._ImainNews.Get(_news);
            return base.View(_news);
        }

        public ActionResult ShowSiteMap()
        {
            MenuViewModel model = new MenuViewModel();
            model.lstMenu = this._Imain_menuService.GetAllSiteMap(model.Menu).ToList<main_menu>();
            model.lstFirstLevelMenu = model.lstMenu.FindAll(delegate (main_menu obj) {
                int? nullable;
                return !obj.ParentId.HasValue || (((nullable = obj.ParentId).GetValueOrDefault() == 0) && nullable.HasValue);
            }).ToList<main_menu>();
            return base.View("ShowSiteMap", model);
        }

        public ActionResult ShowSmallHomeIcon()
        {
            HomeViewModel model = new HomeViewModel {
                Mainsmallhomeicon = new main_small_home_icon()
            };
            model.lstMainsmallhomeicon = this._Imain_small_home_iconService.GetAll(model.Mainsmallhomeicon).ToList<main_small_home_icon>();
            return this.PartialView("_ShowSmallHomeIcon", model);
        }

        public ActionResult ShowUnderConstruction() => 
            base.View();

        public ActionResult ThirdLevelMenuSideBar(int ParentId)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                ParentMenuData = new main_menu()
            };
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ParentId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            model.lstMenu = this._Imain_menuService.GetAllTreeView(model.Menu).ToList<main_menu>();
            return this.PartialView("_ThirdLevelMenuSideBar", model);
        }

        public ActionResult WhyCollege() => 
            base.View();

        public ActionResult WhyMachs() => 
            base.View();
    }
}

