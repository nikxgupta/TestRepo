﻿namespace MachsWeb.Controllers
{
    using Machs.Common;
    using System;
    using System.Web.Mvc;

    public class BaseController : Controller
    {
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            int pValue = 0;
            if (!MachsSession.IsInSession("CurrentCulture"))
            {
                pValue = 1;
                MachsSession.AddSessionItem("CurrentCulture", pValue);
            }
            else
            {
                pValue = (int) MachsSession.GetDirectValue("CurrentCulture");
            }
            MachsSession.CurrentUICulture = pValue;
            base.OnActionExecuting(filterContext);
        }
    }
}

