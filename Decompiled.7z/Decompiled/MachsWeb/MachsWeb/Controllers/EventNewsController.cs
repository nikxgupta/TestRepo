﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class EventNewsController : BaseController
    {
        private Imain_menu_dataService _Imain_menu_dataService;
        private Imain_menuService _Imain_menuService;
        private Imain_eventService _ImainEvents;
        private Imain_newsService _ImainNews;

        public EventNewsController(Imain_menuService main_menu, Imain_menu_dataService main_menu_dataService, Imain_newsService news, Imain_eventService events)
        {
            this._Imain_menuService = main_menu;
            this._Imain_menu_dataService = main_menu_dataService;
            this._ImainNews = news;
            this._ImainEvents = events;
        }

        public ActionResult ManageEventsNews(int ParentId, int ChildId = 0)
        {
            MenuDataViewModel model = new MenuDataViewModel {
                ParentMenuData = new main_menu()
            };
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ParentId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            return base.View("ManageEventsNews", model);
        }
    }
}

