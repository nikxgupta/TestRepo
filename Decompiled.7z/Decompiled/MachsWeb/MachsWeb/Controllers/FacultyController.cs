﻿namespace MachsWeb.Controllers
{
    using Machs.Core;
    using Machs.Model;
    using MachsWeb.ViewModel;
    using System;
    using System.Configuration;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Web.Mvc;

    public class FacultyController : BaseController
    {
        private Imain_faculty_publicationService _Imain_faculty_publicationService;
        private Imain_faculty_qualificationService _Imain_faculty_qualificationService;
        private Imain_faculty_researchService _Imain_faculty_researchService;
        private Imain_facultyMasterService _Imain_facultyMasterService;
        private Imain_menuService _Imain_menuService;

        public FacultyController(Imain_menuService main_menu, Imain_facultyMasterService main_facultyMasterService, Imain_faculty_qualificationService Imain_faculty_qualificationService, Imain_faculty_publicationService Imain_faculty_publicationService, Imain_faculty_researchService Imain_faculty_researchService)
        {
            this._Imain_menuService = main_menu;
            this._Imain_facultyMasterService = main_facultyMasterService;
            this._Imain_faculty_qualificationService = Imain_faculty_qualificationService;
            this._Imain_faculty_publicationService = Imain_faculty_publicationService;
            this._Imain_faculty_researchService = Imain_faculty_researchService;
        }

        [ValidateInput(false)]
        public ActionResult ManageFaculty(FacultyViewModel model, int ParentId = 0, int ChildId = 0, int PageIndex = 1, string Keyword = "")
        {
            if (model.Faculty == null)
            {
                model.Faculty = new main_facultyMaster();
            }
            model.ParentId = ParentId;
            model.ChildId = ChildId;
            if (!string.IsNullOrEmpty(Keyword))
            {
                model.Faculty.FacultyName = Keyword;
            }
            model.ParentMenuData = new main_menu();
            model.ParentMenuData.ParentId = new int?(ParentId);
            model.lstParentChilds = this._Imain_menuService.GetParentsChild(model.ParentMenuData).ToList<main_menu>();
            model.ParentMenuData.MenuId = ParentId;
            model.ParentMenuData = this._Imain_menuService.GetParentDetails(model.ParentMenuData);
            model.ChildMenuData = new main_menu();
            model.ChildMenuData.MenuId = ChildId;
            model.ChildMenuData = this._Imain_menuService.GetParentDetails(model.ChildMenuData);
            model.Faculty.SortExp = null;
            if (model.Faculty.PageSize == 0)
            {
                int num = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
                model.Faculty.PageSize = num;
            }
            if (PageIndex == 0)
            {
                model.Faculty.PageIndex = 1;
            }
            else
            {
                model.Faculty.PageIndex = PageIndex;
            }
            model.Faculty.MenuId = ParentId;
            model.lstFaculty = this._Imain_facultyMasterService.GetAll(model.Faculty).ToList<main_facultyMaster>();
            if ((model.lstFaculty != null) && (model.lstFaculty.ToList<main_facultyMaster>().Count > 0))
            {
                int totalCount = model.lstFaculty.ToList<main_facultyMaster>()[0].TotalCount;
                model.Faculty.TotalCount = totalCount;
            }
            return base.View(model);
        }

        public ActionResult ShowFacultyDetails(int FacultyId = 0, int ParentId = 0)
        {
            FacultyViewModel model = new FacultyViewModel {
                Faculty = new main_facultyMaster()
            };
            model.Faculty.FacultyId = FacultyId;
            model.Faculty = this._Imain_facultyMasterService.Get(model.Faculty);
            model.FacultyQualification = new main_faculty_qualification();
            model.FacultyPublication = new main_faculty_publication();
            model.FacultyResearch = new main_faculty_research();
            model.FacultyQualification.FacultyId = new int?(FacultyId);
            model.FacultyPublication.FacultyId = new int?(FacultyId);
            model.FacultyResearch.FacultyId = new int?(FacultyId);
            model.lstFacultyQualification = this._Imain_faculty_qualificationService.GetAllQualificationByFacultyId(model.FacultyQualification);
            model.lstFacultyPublication = this._Imain_faculty_publicationService.GetAllpublicationByFacultyId(model.FacultyPublication);
            model.lstFacultyResearch = this._Imain_faculty_researchService.GetAllresearchByFacultyId(model.FacultyResearch);
            return this.PartialView("_ShowFacultyDetails", model);
        }
    }
}

