﻿namespace MachsWeb.Controllers
{
    using System.Web.Mvc;

    public class ErrorController : Controller
    {
        public ActionResult ErrorInfo() => 
            base.View();

        public ActionResult Index() => 
            base.View();

        public ActionResult NotFound() => 
            base.View();
    }
}

