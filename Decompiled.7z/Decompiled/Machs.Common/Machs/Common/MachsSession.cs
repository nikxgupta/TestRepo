﻿namespace Machs.Common
{
    using System;
    using System.Globalization;
    using System.Threading;
    using System.Web;

    public class MachsSession
    {
        public static void AbandonSession()
        {
            HttpContext.Current.Session.Abandon();
        }

        public static void AddSessionItem(string pKey, object pValue)
        {
            if (!string.IsNullOrEmpty(pKey))
            {
                HttpContext.Current.Session.Add(pKey, pValue);
            }
        }

        public static void ClearSession()
        {
            HttpContext.Current.Session.Clear();
        }

        public static object GetDirectValue(string pKey)
        {
            object obj2 = null;
            if (string.IsNullOrEmpty(pKey))
            {
                return obj2;
            }
            try
            {
                return HttpContext.Current.Session[pKey];
            }
            catch
            {
                return null;
            }
        }

        public static int GetSessionKeyCount() => 
            HttpContext.Current.Session.Keys.Count;

        public static bool IsInSession(string pKey) => 
            !(string.IsNullOrEmpty(pKey) || (HttpContext.Current.Session[pKey] == null));

        public static void RemoveSessionItem(string pKey)
        {
            if (!string.IsNullOrEmpty(pKey))
            {
                HttpContext.Current.Session.Remove(pKey);
            }
        }

        public static int CurrentUICulture
        {
            get
            {
                if (Thread.CurrentThread.CurrentUICulture.Name == "ar-SA")
                {
                    return 2;
                }
                return 1;
            }
            set
            {
                if (value == 2)
                {
                    Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture("ar");
                }
                else
                {
                    Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
                }
            }
        }
    }
}

