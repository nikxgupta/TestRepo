﻿namespace Machs.Common
{
    using System;
    using System.Data;
    using System.Text;
    using System.Xml;

    public class XMLLib
    {
        public XmlDocument DummyXMLObj = new XmlDocument();
        public XmlNamespaceManager NSManager = null;

        public bool aCreateNode(string aNodeName, ref XmlNode aNode)
        {
            bool flag;
            try
            {
                aNode = this.DummyXMLObj.CreateNode(XmlNodeType.Element, aNodeName, "");
                if (aNode != null)
                {
                    return true;
                }
                flag = false;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public bool fAddDataToNode(ref XmlNode aNode, string cDataValue)
        {
            bool flag;
            try
            {
                aNode.InnerText = cDataValue;
                if (aNode != null)
                {
                    return true;
                }
                flag = false;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public void fAppendNode(ref XmlNode WhereToAppend, ref XmlNode WhatToAppend)
        {
            try
            {
                WhereToAppend.AppendChild(WhatToAppend);
            }
            catch (Exception exception)
            {
                if (exception.Message.ToUpper() != "THE NODE TO BE INSERTED IS FROM A DIFFERENT DOCUMENT CONTEXT.")
                {
                    throw exception;
                }
                try
                {
                    WhereToAppend.AppendChild(WhereToAppend.OwnerDocument.ImportNode(WhatToAppend, true));
                }
                catch (Exception exception2)
                {
                    throw exception2;
                }
            }
        }

        public void fAppendNodeAndText(ref XmlNode lDataXMLObj, string lContext, string lNodeName, string lNodeValue)
        {
            XmlNode aNod = null;
            XmlNode aNode = null;
            if (this.fCreateFirstContext(lDataXMLObj, lContext, ref aNod))
            {
                this.aCreateNode(lNodeName, ref aNode);
                this.fAddDataToNode(ref aNode, lNodeValue);
                this.fAppendNode(ref aNod, ref aNode);
            }
        }

        public void fAppendNodelist(ref XmlNode lDestNode, ref XmlNode lSrcNode, string lXPath)
        {
            try
            {
                XmlNodeList aNod = null;
                if (this.fCreateContext(lSrcNode, lXPath, ref aNod))
                {
                    foreach (XmlNode node in aNod)
                    {
                        lDestNode.AppendChild(node);
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void fAppendNodeList(ref XmlNode lDestNode, ref XmlNode lSrcNode, string lXPath)
        {
            try
            {
                XmlNodeList aNod = null;
                this.fCreateContext(lSrcNode, lXPath, ref aNod);
                foreach (XmlNode node2 in aNod)
                {
                    XmlNode whatToAppend = node2.CloneNode(true);
                    this.fAppendNode(ref lDestNode, ref whatToAppend);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void fCreateAndAppendNode(string anodeName, ref XmlNode aNode, ref XmlNode WhereToAppend)
        {
            try
            {
                this.aCreateNode(anodeName, ref aNode);
                this.fAppendNode(ref WhereToAppend, ref aNode);
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public bool fCreateContext(XmlNode aContextNode, string context, ref XmlNodeList aNod)
        {
            bool flag;
            try
            {
                if (this.NSManager == null)
                {
                    aNod = aContextNode.SelectNodes(context);
                }
                else
                {
                    aNod = aContextNode.SelectNodes(context, this.NSManager);
                }
                if (aNod != null)
                {
                    return true;
                }
                flag = true;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public bool fCreateFirstContext(XmlNode aContextNode, string context, ref XmlNode aNod)
        {
            bool flag;
            try
            {
                if (this.NSManager == null)
                {
                    aNod = aContextNode.SelectSingleNode(context);
                }
                else
                {
                    aNod = aContextNode.SelectSingleNode(context, this.NSManager);
                }
                if (aNod != null)
                {
                    return true;
                }
                flag = false;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public void fCreateNodeFromString(string xmlString, ref XmlNode aNode)
        {
            XmlDocument document = new XmlDocument();
            document.LoadXml(xmlString);
            aNode = document.DocumentElement;
        }

        public bool fCreateXMLObj(ref XmlDocument xDoc)
        {
            bool flag;
            try
            {
                xDoc = new XmlDocument();
                if (xDoc != null)
                {
                    return true;
                }
                flag = false;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public string fDirectGetValue(XmlNode aNode, string nodeName)
        {
            string str;
            try
            {
                XmlNode node = null;
                node = aNode.SelectSingleNode(nodeName);
                if (node != null)
                {
                    return node.Value;
                }
                str = "";
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return str;
        }

        public int fGetLength(XmlNode lNode, string lXPath)
        {
            XmlNodeList aNod = null;
            int count = 0;
            if (this.fCreateContext(lNode, lXPath, ref aNod))
            {
                count = aNod.Count;
            }
            return count;
        }

        public string fGetValue(XmlNode aNode, string nodeName)
        {
            string str;
            try
            {
                XmlNode aNod = null;
                this.fCreateFirstContext(aNode, nodeName, ref aNod);
                if (aNod != null)
                {
                    return aNod.InnerText;
                }
                str = "";
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return str;
        }

        public string FGetXML(XmlDocument xDoc, string lXPath)
        {
            string str;
            try
            {
                XmlNode aNod = null;
                if (this.fCreateFirstContext(xDoc, lXPath, ref aNod))
                {
                    return aNod.OuterXml;
                }
                str = "";
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return str;
        }

        public string fGetXMlFromDataSet(DataSet DS) => 
            DS.GetXml();

        public string fGetXMlSchemaFromDataSet(DataSet DS) => 
            DS.GetXmlSchema();

        public bool fOpenFreeXMLDoc(ref XmlDocument xDoc, string XMLFileName)
        {
            if (xDoc == null)
            {
                this.fCreateXMLObj(ref xDoc);
            }
            try
            {
                xDoc.Load(XMLFileName);
                return (xDoc != null);
            }
            catch
            {
                return false;
            }
        }

        public bool fOpenFreeXMLDoc(ref XmlDocument xDoc, string XMLFileName, bool blnIsOnlyString)
        {
            if (xDoc == null)
            {
                this.fCreateXMLObj(ref xDoc);
            }
            try
            {
                xDoc.LoadXml(XMLFileName);
                return (xDoc != null);
            }
            catch
            {
                return false;
            }
        }

        public StringBuilder fRemoveCdata(string lString)
        {
            StringBuilder builder = new StringBuilder(lString);
            builder.Replace("<![CDATA[", "");
            builder.Replace("]]>", "");
            return builder;
        }

        public void fRemoveNode(ref XmlDocument xDoc, string lXpath)
        {
            try
            {
                XmlNode aNod = null;
                if (this.fCreateFirstContext(xDoc, lXpath, ref aNod))
                {
                    aNod.ParentNode.RemoveChild(aNod);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public bool fSetAttribute(ref XmlNode aNode, string attributeName, string attributeValue)
        {
            bool flag;
            try
            {
                XmlAttribute node = this.DummyXMLObj.CreateAttribute(attributeName);
                if (node != null)
                {
                    node.InnerText = attributeValue;
                    aNode.Attributes.SetNamedItem(node);
                    return true;
                }
                flag = false;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public bool fSetValue(ref XmlNode aNode, string nodeName, string retVal)
        {
            bool flag;
            try
            {
                XmlNode node = aNode.SelectSingleNode(nodeName);
                if (node == null)
                {
                    return false;
                }
                flag = this.fAddDataToNode(ref node, retVal);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public bool fSetValueWithCDATA(ref XmlDocument xDoc, ref XmlNode RootNode, string nodeName, string retVal)
        {
            bool flag;
            try
            {
                XmlCDataSection newChild = xDoc.CreateCDataSection(retVal);
                XmlNode node = RootNode.SelectSingleNode(nodeName);
                node.InnerText = "";
                node.AppendChild(newChild);
                flag = true;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return flag;
        }

        public XmlDocument StripDocumentNamespace(XmlDocument oldDom)
        {
            if (oldDom.DocumentElement.NamespaceURI.Length > 0)
            {
                oldDom.DocumentElement.SetAttribute("xmlns", "");
                XmlDocument document = new XmlDocument();
                document.LoadXml(oldDom.OuterXml);
                return document;
            }
            return oldDom;
        }
    }
}

