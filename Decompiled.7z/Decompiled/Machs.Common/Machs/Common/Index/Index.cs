﻿namespace Machs.Common.Index
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [CompilerGenerated, DebuggerNonUserCode, GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
    public class Index
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal Index()
        {
        }

        public static string _01 =>
            ResourceManager.GetString("01", resourceCulture);

        public static string _02 =>
            ResourceManager.GetString("02", resourceCulture);

        public static string _03 =>
            ResourceManager.GetString("03", resourceCulture);

        public static string _04 =>
            ResourceManager.GetString("04", resourceCulture);

        public static string _05 =>
            ResourceManager.GetString("05", resourceCulture);

        public static string _06 =>
            ResourceManager.GetString("06", resourceCulture);

        public static string _07 =>
            ResourceManager.GetString("07", resourceCulture);

        public static string _08 =>
            ResourceManager.GetString("08", resourceCulture);

        public static string _09 =>
            ResourceManager.GetString("09", resourceCulture);

        public static string _10 =>
            ResourceManager.GetString("10", resourceCulture);

        public static string _11 =>
            ResourceManager.GetString("11", resourceCulture);

        public static string _12 =>
            ResourceManager.GetString("12", resourceCulture);

        public static string _13 =>
            ResourceManager.GetString("13", resourceCulture);

        public static string _14 =>
            ResourceManager.GetString("14", resourceCulture);

        public static string _15 =>
            ResourceManager.GetString("15", resourceCulture);

        public static string _16 =>
            ResourceManager.GetString("16", resourceCulture);

        public static string _17 =>
            ResourceManager.GetString("17", resourceCulture);

        public static string _18 =>
            ResourceManager.GetString("18", resourceCulture);

        public static string _19 =>
            ResourceManager.GetString("19", resourceCulture);

        public static string _20 =>
            ResourceManager.GetString("20", resourceCulture);

        public static string _21 =>
            ResourceManager.GetString("21", resourceCulture);

        public static string _22 =>
            ResourceManager.GetString("22", resourceCulture);

        public static string _23 =>
            ResourceManager.GetString("23", resourceCulture);

        public static string _24 =>
            ResourceManager.GetString("24", resourceCulture);

        public static string _25 =>
            ResourceManager.GetString("25", resourceCulture);

        public static string _26 =>
            ResourceManager.GetString("26", resourceCulture);

        public static string _27 =>
            ResourceManager.GetString("27", resourceCulture);

        public static string _28 =>
            ResourceManager.GetString("28", resourceCulture);

        public static string AboutSaudiArabia =>
            ResourceManager.GetString("AboutSaudiArabia", resourceCulture);

        public static string AboutUs =>
            ResourceManager.GetString("AboutUs", resourceCulture);

        public static string Academics =>
            ResourceManager.GetString("Academics", resourceCulture);

        public static string Accreditation =>
            ResourceManager.GetString("Accreditation", resourceCulture);

        public static string AddCourse =>
            ResourceManager.GetString("AddCourse", resourceCulture);

        public static string Administrative =>
            ResourceManager.GetString("Administrative", resourceCulture);

        public static string Admission =>
            ResourceManager.GetString("Admission", resourceCulture);

        public static string Alumni =>
            ResourceManager.GetString("Alumni", resourceCulture);

        public static string Answer =>
            ResourceManager.GetString("Answer", resourceCulture);

        public static string AnswerDetail =>
            ResourceManager.GetString("AnswerDetail", resourceCulture);

        public static string Arabic =>
            ResourceManager.GetString("Arabic", resourceCulture);

        public static string Back =>
            ResourceManager.GetString("Back", resourceCulture);

        public static string CalAgain =>
            ResourceManager.GetString("CalAgain", resourceCulture);

        public static string CalculateCurrentTermGPA =>
            ResourceManager.GetString("CalculateCurrentTermGPA", resourceCulture);

        public static string CalculateGPA =>
            ResourceManager.GetString("CalculateGPA", resourceCulture);

        public static string Calender =>
            ResourceManager.GetString("Calender", resourceCulture);

        public static string CampusLife =>
            ResourceManager.GetString("CampusLife", resourceCulture);

        public static string Careers =>
            ResourceManager.GetString("Careers", resourceCulture);

        public static string Close =>
            ResourceManager.GetString("Close", resourceCulture);

        public static string CollegeBackground =>
            ResourceManager.GetString("CollegeBackground", resourceCulture);

        public static string ContactUs =>
            ResourceManager.GetString("ContactUs", resourceCulture);

        public static string CopyRightInformation =>
            ResourceManager.GetString("CopyRightInformation", resourceCulture);

        public static string COURSES =>
            ResourceManager.GetString("COURSES", resourceCulture);

        public static string CreditHours =>
            ResourceManager.GetString("CreditHours", resourceCulture);

        public static string CT =>
            ResourceManager.GetString("CT", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static CultureInfo Culture => resourceCulture;

        public static string Date =>
            ResourceManager.GetString("Date", resourceCulture);

        public static string English =>
            ResourceManager.GetString("English", resourceCulture);

        public static string EnterCorrectGPA =>
            ResourceManager.GetString("EnterCorrectGPA", resourceCulture);

        public static string EnterFinalGrade =>
            ResourceManager.GetString("EnterFinalGrade", resourceCulture);

        public static string EnterPTGPA =>
            ResourceManager.GetString("EnterPTGPA", resourceCulture);

        public static string EnterPTGPAOutOfFive =>
            ResourceManager.GetString("EnterPTGPAOutOfFive", resourceCulture);

        public static string EnterPTGPAOutOfFour =>
            ResourceManager.GetString("EnterPTGPAOutOfFour", resourceCulture);

        public static string Events =>
            ResourceManager.GetString("Events", resourceCulture);

        public static string EventsandNews =>
            ResourceManager.GetString("EventsandNews", resourceCulture);

        public static string FacultyStaff =>
            ResourceManager.GetString("FacultyStaff", resourceCulture);

        public static string Fr =>
            ResourceManager.GetString("Fr", resourceCulture);

        public static string Gallery =>
            ResourceManager.GetString("Gallery", resourceCulture);

        public static string GPA =>
            ResourceManager.GetString("GPA", resourceCulture);

        public static string GPACalculator =>
            ResourceManager.GetString("GPACalculator", resourceCulture);

        public static string GPAOutOf4 =>
            ResourceManager.GetString("GPAOutOf4", resourceCulture);

        public static string GPAOutOf5 =>
            ResourceManager.GetString("GPAOutOf5", resourceCulture);

        public static string GPAValidation =>
            ResourceManager.GetString("GPAValidation", resourceCulture);

        public static string GPAValidationOutOf4 =>
            ResourceManager.GetString("GPAValidationOutOf4", resourceCulture);

        public static string Heading =>
            ResourceManager.GetString("Heading", resourceCulture);

        public static string Help =>
            ResourceManager.GetString("Help", resourceCulture);

        public static string Home =>
            ResourceManager.GetString("Home", resourceCulture);

        public static string IndexPoint1 =>
            ResourceManager.GetString("IndexPoint1", resourceCulture);

        public static string IndexPoint2 =>
            ResourceManager.GetString("IndexPoint2", resourceCulture);

        public static string IndexPoint3 =>
            ResourceManager.GetString("IndexPoint3", resourceCulture);

        public static string IndexPoint4 =>
            ResourceManager.GetString("IndexPoint4", resourceCulture);

        public static string IndexPoint5 =>
            ResourceManager.GetString("IndexPoint5", resourceCulture);

        public static string IndexPoint6 =>
            ResourceManager.GetString("IndexPoint6", resourceCulture);

        public static string IndexPoint7 =>
            ResourceManager.GetString("IndexPoint7", resourceCulture);

        public static string JumptoPage =>
            ResourceManager.GetString("JumptoPage", resourceCulture);

        public static string Library =>
            ResourceManager.GetString("Library", resourceCulture);

        public static string MachsCampus =>
            ResourceManager.GetString("MachsCampus", resourceCulture);

        public static string MACHSEvents =>
            ResourceManager.GetString("MACHSEvents", resourceCulture);

        public static string Mission =>
            ResourceManager.GetString("Mission", resourceCulture);

        public static string MissionVision =>
            ResourceManager.GetString("MissionVision", resourceCulture);

        public static string Mo =>
            ResourceManager.GetString("Mo", resourceCulture);

        public static string News =>
            ResourceManager.GetString("News", resourceCulture);

        public static string next =>
            ResourceManager.GetString("next", resourceCulture);

        public static string OnlineRegistration =>
            ResourceManager.GetString("OnlineRegistration", resourceCulture);

        public static string Or =>
            ResourceManager.GetString("Or", resourceCulture);

        public static string PhotoGalleries =>
            ResourceManager.GetString("PhotoGalleries", resourceCulture);

        public static string Placeholder =>
            ResourceManager.GetString("Placeholder", resourceCulture);

        public static string Position =>
            ResourceManager.GetString("Position", resourceCulture);

        public static string prev =>
            ResourceManager.GetString("prev", resourceCulture);

        public static string PT =>
            ResourceManager.GetString("PT", resourceCulture);

        public static string Question =>
            ResourceManager.GetString("Question", resourceCulture);

        public static string ReadMore =>
            ResourceManager.GetString("ReadMore", resourceCulture);

        public static string Remove =>
            ResourceManager.GetString("Remove", resourceCulture);

        public static string Remove1 =>
            ResourceManager.GetString("Remove1", resourceCulture);

        public static string ReqCourseCode =>
            ResourceManager.GetString("ReqCourseCode", resourceCulture);

        public static string ReqCreditHours =>
            ResourceManager.GetString("ReqCreditHours", resourceCulture);

        public static string ReqFinalGrade =>
            ResourceManager.GetString("ReqFinalGrade", resourceCulture);

        public static string ReqPT =>
            ResourceManager.GetString("ReqPT", resourceCulture);

        public static string ReqTotalCreditHrs =>
            ResourceManager.GetString("ReqTotalCreditHrs", resourceCulture);

        public static string Research =>
            ResourceManager.GetString("Research", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (object.ReferenceEquals(resourceMan, null))
                {
                    System.Resources.ResourceManager manager = new System.Resources.ResourceManager("Machs.Common.Index.Index", typeof(Machs.Common.Index.Index).Assembly);
                    resourceMan = manager;
                }
                return resourceMan;
            }
        }

        public static string Result =>
            ResourceManager.GetString("Result", resourceCulture);

        public static string Sa =>
            ResourceManager.GetString("Sa", resourceCulture);

        public static string Search =>
            ResourceManager.GetString("Search", resourceCulture);

        public static string Sitemap =>
            ResourceManager.GetString("Sitemap", resourceCulture);

        public static string su =>
            ResourceManager.GetString("su", resourceCulture);

        public static string Th =>
            ResourceManager.GetString("Th", resourceCulture);

        public static string Total =>
            ResourceManager.GetString("Total", resourceCulture);

        public static string TotalHours =>
            ResourceManager.GetString("TotalHours", resourceCulture);

        public static string TotalPoints =>
            ResourceManager.GetString("TotalPoints", resourceCulture);

        public static string Tu =>
            ResourceManager.GetString("Tu", resourceCulture);

        public static string UNIVERSITY =>
            ResourceManager.GetString("UNIVERSITY", resourceCulture);

        public static string Values =>
            ResourceManager.GetString("Values", resourceCulture);

        public static string View =>
            ResourceManager.GetString("View", resourceCulture);

        public static string Vision =>
            ResourceManager.GetString("Vision", resourceCulture);

        public static string We =>
            ResourceManager.GetString("We", resourceCulture);

        public static string WeAreSocial =>
            ResourceManager.GetString("WeAreSocial", resourceCulture);

        public static string Website =>
            ResourceManager.GetString("Website", resourceCulture);

        public static string WhyCollege =>
            ResourceManager.GetString("WhyCollege", resourceCulture);

        public static string WhyMachs =>
            ResourceManager.GetString("WhyMachs", resourceCulture);
    }
}

