﻿namespace Machs.Common
{
    using System;

    public class MachsConstant
    {
        public const string AcademicTerm = "AcademicTerm";
        public const string BookCategory = "BookCategory";
        public const string CurrentCulture = "CurrentCulture";
        public const string LoginFail = "Please enter valid Email Address and Password";
        public const string SESSION_CURRENTUSEANDRROLE = "USERAndROLE";
        public const string UserType = "UserType";
    }
}

