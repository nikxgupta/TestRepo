﻿namespace Machs.Common
{
    using System;

    public class SessionKeys
    {
        public const string CurrentUser = "CurrentUser";
    }
}

