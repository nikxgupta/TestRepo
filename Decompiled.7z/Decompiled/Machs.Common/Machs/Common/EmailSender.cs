﻿namespace Machs.Common
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Net;
    using System.Net.Mail;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Web;
    using System.Xml;

    public class EmailSender
    {
        private const string EMAIL_TEMPLATE_PATH = "EmailTemplatePath";
        private const string IS_SEND_EMAIL = "SendEmail";
        private const string MAIl_FROM = "FromEmailId";
        private const string SENDMAIL_SMTPUSERNAME = "SENDMAIL_SMTPUSERNAME";
        private const string SENDMAIL_SMTPUSERPASSWORD = "SENDMAIL_SMTPUSERPASSWORD";
        private const string SMTP_HOST = "SMTP_HOST";
        private string strIsSendEmail = string.Empty;

        public EmailSender(string constTo, string constSubject, string constBody, int pCustomerID = 0, int pQuotationID = 0, int pInvoiceId = 0, int pEnquiryID = 0, string pfromEmailID = "")
        {
            this.To = constTo;
            this.Subject = constSubject;
            this.Body = constBody;
            this.CustomerID = pCustomerID;
            this.QuotationID = pQuotationID;
            this.InvoiceId = pInvoiceId;
            this.EnquiryID = pEnquiryID;
            this.IsFileAttached = false;
            this.FromEmailId = pfromEmailID;
        }

        public string GetEmailTemplateBody(string strTemplateName, out string strSubject)
        {
            XmlNode aContextNode = null;
            XmlNodeList aNod = null;
            XMLLib lib = null;
            XmlDocument xDoc = new XmlDocument();
            string innerText = string.Empty;
            string str2 = ConfigurationManager.AppSettings["EmailTemplatePath"].ToString();
            string xMLFileName = HttpContext.Current.Server.MapPath(str2 + strTemplateName);
            try
            {
                lib = new XMLLib();
                lib.fOpenFreeXMLDoc(ref xDoc, xMLFileName);
                aContextNode = xDoc.DocumentElement;
                lib.fCreateContext(aContextNode, "root/body", ref aNod);
                innerText = aNod[0].InnerText;
                lib.fCreateContext(aContextNode, "root/subject", ref aNod);
                strSubject = aNod[0].InnerText;
            }
            catch (Exception)
            {
                strSubject = "";
            }
            return innerText;
        }

        public void SendEmail()
        {
            string[] strArray;
            MailMessage message = new MailMessage();
            if (this.To.Contains<char>(';'))
            {
                strArray = this.To.Split(new char[] { ';' });
                if (strArray != null)
                {
                    foreach (string str in strArray)
                    {
                        if (!string.IsNullOrEmpty(str))
                        {
                            message.To.Add(str);
                        }
                    }
                }
            }
            else
            {
                message.To.Add(this.To);
            }
            if (!string.IsNullOrEmpty(this.FromEmailId))
            {
                message.From = new MailAddress(this.FromEmailId);
            }
            else
            {
                message.From = new MailAddress(ConfigurationManager.AppSettings["FromEmailId"].ToString());
            }
            message.Subject = this.Subject;
            message.Body = this.Body;
            message.IsBodyHtml = this.IsBodyHtml;
            SmtpClient client = new SmtpClient {
                Host = ConfigurationManager.AppSettings["SMTP_HOST"].ToString(),
                Credentials = new NetworkCredential(ConfigurationManager.AppSettings["SENDMAIL_SMTPUSERNAME"].ToString(), ConfigurationManager.AppSettings["SENDMAIL_SMTPUSERPASSWORD"].ToString())
            };
            this.strIsSendEmail = ConfigurationManager.AppSettings["SendEmail"].ToString();
            string source = ConfigurationManager.AppSettings["BCCEmailId"].ToString();
            if (source.Contains<char>(';'))
            {
                strArray = source.Split(new char[] { ';' });
                if (strArray != null)
                {
                    foreach (string str in strArray)
                    {
                        if (!string.IsNullOrEmpty(str))
                        {
                            message.Bcc.Add(str);
                        }
                    }
                }
            }
            else
            {
                message.Bcc.Add(source);
            }
            if (this.IsFileAttached)
            {
                foreach (string str3 in this.AttachedFilePath)
                {
                    if (!string.IsNullOrEmpty(str3))
                    {
                        Attachment item = new Attachment(str3, "application/octet-stream");
                        message.Attachments.Add(item);
                    }
                }
            }
            if (this.strIsSendEmail == "1")
            {
                client.Send(message);
            }
        }

        public List<string> AttachedFilePath { get; set; }

        public string BCC { get; set; }

        public string Body { get; set; }

        public string CC { get; set; }

        public int CustomerID { get; set; }

        public int EnquiryID { get; set; }

        public string FromEmailId { get; set; }

        public int InvoiceId { get; set; }

        public bool IsBodyHtml { get; set; }

        public bool IsFileAttached { get; set; }

        public int QuotationID { get; set; }

        public string Subject { get; set; }

        public string To { get; set; }
    }
}

