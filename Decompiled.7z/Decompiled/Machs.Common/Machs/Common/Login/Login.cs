﻿namespace Machs.Common.Login
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), CompilerGenerated, DebuggerNonUserCode]
    public class Login
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal Login()
        {
        }

        public static string AcknowledgementMessage =>
            ResourceManager.GetString("AcknowledgementMessage", resourceCulture);

        public static string Address =>
            ResourceManager.GetString("Address", resourceCulture);

        public static string AddToastMessageForStudent =>
            ResourceManager.GetString("AddToastMessageForStudent", resourceCulture);

        public static string Cancel =>
            ResourceManager.GetString("Cancel", resourceCulture);

        public static string ChangePassword =>
            ResourceManager.GetString("ChangePassword", resourceCulture);

        public static string ChangePasswordForLogin =>
            ResourceManager.GetString("ChangePasswordForLogin", resourceCulture);

        public static string City =>
            ResourceManager.GetString("City", resourceCulture);

        public static string ConfirmNewPassword =>
            ResourceManager.GetString("ConfirmNewPassword", resourceCulture);

        public static string ConfirmStudentRegistration =>
            ResourceManager.GetString("ConfirmStudentRegistration", resourceCulture);

        public static string ConfirmStudentRegistrationForEmail =>
            ResourceManager.GetString("ConfirmStudentRegistrationForEmail", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static CultureInfo Culture => resourceCulture;

        public static string Degree =>
            ResourceManager.GetString("Degree", resourceCulture);

        public static string Department =>
            ResourceManager.GetString("Department", resourceCulture);

        public static string EditProfile =>
            ResourceManager.GetString("EditProfile", resourceCulture);

        public static string EditToastMessageForAStudent =>
            ResourceManager.GetString("EditToastMessageForAStudent", resourceCulture);

        public static string EducationInformation =>
            ResourceManager.GetString("EducationInformation", resourceCulture);

        public static string EmailAddress =>
            ResourceManager.GetString("EmailAddress", resourceCulture);

        public static string EnterCorrectPwd =>
            ResourceManager.GetString("EnterCorrectPwd", resourceCulture);

        public static string Faculty =>
            ResourceManager.GetString("Faculty", resourceCulture);

        public static string ForgotPassword =>
            ResourceManager.GetString("ForgotPassword", resourceCulture);

        public static string FullName =>
            ResourceManager.GetString("FullName", resourceCulture);

        public static string FullNameArabic =>
            ResourceManager.GetString("FullNameArabic", resourceCulture);

        public static string InsertUpdateDate =>
            ResourceManager.GetString("InsertUpdateDate", resourceCulture);

        public static string LastLoginDate =>
            ResourceManager.GetString("LastLoginDate", resourceCulture);

        public static string Login1 =>
            ResourceManager.GetString("Login1", resourceCulture);

        public static string LoginRegistration =>
            ResourceManager.GetString("LoginRegistration", resourceCulture);

        public static string Logout =>
            ResourceManager.GetString("Logout", resourceCulture);

        public static string LowerCaseLogin =>
            ResourceManager.GetString("LowerCaseLogin", resourceCulture);

        public static string NationalId =>
            ResourceManager.GetString("NationalId", resourceCulture);

        public static string Nationality =>
            ResourceManager.GetString("Nationality", resourceCulture);

        public static string NewPassword =>
            ResourceManager.GetString("NewPassword", resourceCulture);

        public static string OldPassword =>
            ResourceManager.GetString("OldPassword", resourceCulture);

        public static string PassportNumber =>
            ResourceManager.GetString("PassportNumber", resourceCulture);

        public static string Password =>
            ResourceManager.GetString("Password", resourceCulture);

        public static string PasswordNotMatching =>
            ResourceManager.GetString("PasswordNotMatching", resourceCulture);

        public static string PasswordNotMatching1 =>
            ResourceManager.GetString("PasswordNotMatching1", resourceCulture);

        public static string PersonalInformation =>
            ResourceManager.GetString("PersonalInformation", resourceCulture);

        public static string PhoneNumber =>
            ResourceManager.GetString("PhoneNumber", resourceCulture);

        public static string Pleasespecifyemailaddress =>
            ResourceManager.GetString("Pleasespecifyemailaddress", resourceCulture);

        public static string Pleasespecifypassword =>
            ResourceManager.GetString("Pleasespecifypassword", resourceCulture);

        public static string PwdChangedSuccess =>
            ResourceManager.GetString("PwdChangedSuccess", resourceCulture);

        public static string Register =>
            ResourceManager.GetString("Register", resourceCulture);

        public static string ReqConfirmPassword =>
            ResourceManager.GetString("ReqConfirmPassword", resourceCulture);

        public static string ReqDegree =>
            ResourceManager.GetString("ReqDegree", resourceCulture);

        public static string ReqDepartment =>
            ResourceManager.GetString("ReqDepartment", resourceCulture);

        public static string ReqEmail =>
            ResourceManager.GetString("ReqEmail", resourceCulture);

        public static string ReqEmailForLogin =>
            ResourceManager.GetString("ReqEmailForLogin", resourceCulture);

        public static string ReqEmailForLogin1 =>
            ResourceManager.GetString("ReqEmailForLogin1", resourceCulture);

        public static string ReqFullName =>
            ResourceManager.GetString("ReqFullName", resourceCulture);

        public static string ReqNewPassword =>
            ResourceManager.GetString("ReqNewPassword", resourceCulture);

        public static string ReqPassword =>
            ResourceManager.GetString("ReqPassword", resourceCulture);

        public static string ReqPasswordForLogin =>
            ResourceManager.GetString("ReqPasswordForLogin", resourceCulture);

        public static string ReqPasswordForLogin1 =>
            ResourceManager.GetString("ReqPasswordForLogin1", resourceCulture);

        public static string ReqPhoneNumber =>
            ResourceManager.GetString("ReqPhoneNumber", resourceCulture);

        public static string ReqStudentID =>
            ResourceManager.GetString("ReqStudentID", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (object.ReferenceEquals(resourceMan, null))
                {
                    System.Resources.ResourceManager manager = new System.Resources.ResourceManager("Machs.Common.Login.Login", typeof(Machs.Common.Login.Login).Assembly);
                    resourceMan = manager;
                }
                return resourceMan;
            }
        }

        public static string Save =>
            ResourceManager.GetString("Save", resourceCulture);

        public static string SelectDegree =>
            ResourceManager.GetString("SelectDegree", resourceCulture);

        public static string SelectDepartment =>
            ResourceManager.GetString("SelectDepartment", resourceCulture);

        public static string SelectPassingYear =>
            ResourceManager.GetString("SelectPassingYear", resourceCulture);

        public static string Student =>
            ResourceManager.GetString("Student", resourceCulture);

        public static string StudentID =>
            ResourceManager.GetString("StudentID", resourceCulture);

        public static string Submit =>
            ResourceManager.GetString("Submit", resourceCulture);

        public static string UnableToaddStudent =>
            ResourceManager.GetString("UnableToaddStudent", resourceCulture);

        public static string UnableToChangePwd =>
            ResourceManager.GetString("UnableToChangePwd", resourceCulture);

        public static string UnableToUpdateToastMessageForStudent =>
            ResourceManager.GetString("UnableToUpdateToastMessageForStudent", resourceCulture);

        public static string UserID =>
            ResourceManager.GetString("UserID", resourceCulture);

        public static string UserType =>
            ResourceManager.GetString("UserType", resourceCulture);

        public static string Welcome =>
            ResourceManager.GetString("Welcome", resourceCulture);

        public static string WelcomeToMachsPortal =>
            ResourceManager.GetString("WelcomeToMachsPortal", resourceCulture);
    }
}

