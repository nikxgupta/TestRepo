﻿namespace Machs.Common
{
    using System;
    using System.Security.Cryptography;
    using System.Text;

    public class Utility
    {
        public static string GeneratorUniqueId(string strPreFix) => 
            (strPreFix + Guid.NewGuid().ToString()).Replace("-", "").ToUpper();

        public static string GetUniqueKeyWithPrefix(string pPrefix, int pMaxSize)
        {
            char[] chArray = new char[0x3e];
            chArray = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
            int capacity = pMaxSize;
            byte[] data = new byte[1];
            RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
            provider.GetNonZeroBytes(data);
            capacity = pMaxSize;
            data = new byte[capacity];
            provider.GetNonZeroBytes(data);
            StringBuilder builder = new StringBuilder(capacity);
            foreach (byte num2 in data)
            {
                builder.Append(chArray[num2 % (chArray.Length - 1)]);
            }
            return (pPrefix + builder.ToString());
        }
    }
}

