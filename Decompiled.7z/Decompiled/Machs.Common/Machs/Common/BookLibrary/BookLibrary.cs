﻿namespace Machs.Common.BookLibrary
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [CompilerGenerated, DebuggerNonUserCode, GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
    public class BookLibrary
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal BookLibrary()
        {
        }

        public static string Author =>
            ResourceManager.GetString("Author", resourceCulture);

        public static string Available =>
            ResourceManager.GetString("Available", resourceCulture);

        public static string Back =>
            ResourceManager.GetString("Back", resourceCulture);

        public static string BookAlreadyReserved =>
            ResourceManager.GetString("BookAlreadyReserved", resourceCulture);

        public static string BookAvailableOn =>
            ResourceManager.GetString("BookAvailableOn", resourceCulture);

        public static string BookCategory =>
            ResourceManager.GetString("BookCategory", resourceCulture);

        public static string BookDetails =>
            ResourceManager.GetString("BookDetails", resourceCulture);

        public static string BookName =>
            ResourceManager.GetString("BookName", resourceCulture);

        public static string BookStatus =>
            ResourceManager.GetString("BookStatus", resourceCulture);

        public static string BorrowBook =>
            ResourceManager.GetString("BorrowBook", resourceCulture);

        public static string BorrowBook1 =>
            ResourceManager.GetString("BorrowBook1", resourceCulture);

        public static string BorrowedCurrentBook =>
            ResourceManager.GetString("BorrowedCurrentBook", resourceCulture);

        public static string BorrowedFutureBook =>
            ResourceManager.GetString("BorrowedFutureBook", resourceCulture);

        public static string BorrowedPastBook =>
            ResourceManager.GetString("BorrowedPastBook", resourceCulture);

        public static string Category =>
            ResourceManager.GetString("Category", resourceCulture);

        public static string Class =>
            ResourceManager.GetString("Class", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static CultureInfo Culture => resourceCulture;

        public static string DateOfReservation =>
            ResourceManager.GetString("DateOfReservation", resourceCulture);

        public static string DelayPenalites =>
            ResourceManager.GetString("DelayPenalites", resourceCulture);

        public static string DelayPenalties =>
            ResourceManager.GetString("DelayPenalties", resourceCulture);

        public static string DelayPenalty =>
            ResourceManager.GetString("DelayPenalty", resourceCulture);

        public static string DownloadReceipt =>
            ResourceManager.GetString("DownloadReceipt", resourceCulture);

        public static string Edition =>
            ResourceManager.GetString("Edition", resourceCulture);

        public static string Email =>
            ResourceManager.GetString("Email", resourceCulture);

        public static string From =>
            ResourceManager.GetString("From", resourceCulture);

        public static string FromDate =>
            ResourceManager.GetString("FromDate", resourceCulture);

        public static string IssueDate =>
            ResourceManager.GetString("IssueDate", resourceCulture);

        public static string JumptoPage =>
            ResourceManager.GetString("JumptoPage", resourceCulture);

        public static string Library =>
            ResourceManager.GetString("Library", resourceCulture);

        public static string LoanFrom =>
            ResourceManager.GetString("LoanFrom", resourceCulture);

        public static string LoanTo =>
            ResourceManager.GetString("LoanTo", resourceCulture);

        public static string Name =>
            ResourceManager.GetString("Name", resourceCulture);

        public static string Next =>
            ResourceManager.GetString("Next", resourceCulture);

        public static string NoBookAvailble =>
            ResourceManager.GetString("NoBookAvailble", resourceCulture);

        public static string NotAvailable =>
            ResourceManager.GetString("NotAvailable", resourceCulture);

        public static string Prev =>
            ResourceManager.GetString("Prev", resourceCulture);

        public static string PrintReceipt =>
            ResourceManager.GetString("PrintReceipt", resourceCulture);

        public static string Quantity =>
            ResourceManager.GetString("Quantity", resourceCulture);

        public static string QuantityWithLibrary =>
            ResourceManager.GetString("QuantityWithLibrary", resourceCulture);

        public static string Renew =>
            ResourceManager.GetString("Renew", resourceCulture);

        public static string RenewSucessMsg =>
            ResourceManager.GetString("RenewSucessMsg", resourceCulture);

        public static string ReqBookLoanFromDate =>
            ResourceManager.GetString("ReqBookLoanFromDate", resourceCulture);

        public static string ReqBookLoanToDate =>
            ResourceManager.GetString("ReqBookLoanToDate", resourceCulture);

        public static string ReqFromDate =>
            ResourceManager.GetString("ReqFromDate", resourceCulture);

        public static string ReqToDate =>
            ResourceManager.GetString("ReqToDate", resourceCulture);

        public static string ReservationBook =>
            ResourceManager.GetString("ReservationBook", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (object.ReferenceEquals(resourceMan, null))
                {
                    System.Resources.ResourceManager manager = new System.Resources.ResourceManager("Machs.Common.BookLibrary.BookLibrary", typeof(Machs.Common.BookLibrary.BookLibrary).Assembly);
                    resourceMan = manager;
                }
                return resourceMan;
            }
        }

        public static string SaveAndPrintReceipt =>
            ResourceManager.GetString("SaveAndPrintReceipt", resourceCulture);

        public static string Search =>
            ResourceManager.GetString("Search", resourceCulture);

        public static string SearchPlaceholder =>
            ResourceManager.GetString("SearchPlaceholder", resourceCulture);

        public static string SelectBookCategory =>
            ResourceManager.GetString("SelectBookCategory", resourceCulture);

        public static string SerialNumber =>
            ResourceManager.GetString("SerialNumber", resourceCulture);

        public static string SubClass =>
            ResourceManager.GetString("SubClass", resourceCulture);

        public static string To =>
            ResourceManager.GetString("To", resourceCulture);

        public static string ToDate =>
            ResourceManager.GetString("ToDate", resourceCulture);

        public static string UnableToUpdateBookStatus =>
            ResourceManager.GetString("UnableToUpdateBookStatus", resourceCulture);

        public static string UserHistory =>
            ResourceManager.GetString("UserHistory", resourceCulture);

        public static string View =>
            ResourceManager.GetString("View", resourceCulture);

        public static string ViewBookDetails =>
            ResourceManager.GetString("ViewBookDetails", resourceCulture);

        public static string Year =>
            ResourceManager.GetString("Year", resourceCulture);
    }
}

