﻿namespace Machs.Common.College
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [CompilerGenerated, GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode]
    public class College
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal College()
        {
        }

        public static string AboutSaudiArabia =>
            ResourceManager.GetString("AboutSaudiArabia", resourceCulture);

        public static string AboutUs =>
            ResourceManager.GetString("AboutUs", resourceCulture);

        public static string Academics =>
            ResourceManager.GetString("Academics", resourceCulture);

        public static string Accreditation =>
            ResourceManager.GetString("Accreditation", resourceCulture);

        public static string Administrative =>
            ResourceManager.GetString("Administrative", resourceCulture);

        public static string Admission =>
            ResourceManager.GetString("Admission", resourceCulture);

        public static string Alumni =>
            ResourceManager.GetString("Alumni", resourceCulture);

        public static string Arabic =>
            ResourceManager.GetString("Arabic", resourceCulture);

        public static string CampusLife =>
            ResourceManager.GetString("CampusLife", resourceCulture);

        public static string Careers =>
            ResourceManager.GetString("Careers", resourceCulture);

        public static string ContactUs =>
            ResourceManager.GetString("ContactUs", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static CultureInfo Culture => resourceCulture;

        public static string English =>
            ResourceManager.GetString("English", resourceCulture);

        public static string FacultyStaff =>
            ResourceManager.GetString("FacultyStaff", resourceCulture);

        public static string Home =>
            ResourceManager.GetString("Home", resourceCulture);

        public static string Library =>
            ResourceManager.GetString("Library", resourceCulture);

        public static string MachsCampus =>
            ResourceManager.GetString("MachsCampus", resourceCulture);

        public static string MACHSEvents =>
            ResourceManager.GetString("MACHSEvents", resourceCulture);

        public static string MissionVision =>
            ResourceManager.GetString("MissionVision", resourceCulture);

        public static string OnlineRegistration =>
            ResourceManager.GetString("OnlineRegistration", resourceCulture);

        public static string PhotoGalleries =>
            ResourceManager.GetString("PhotoGalleries", resourceCulture);

        public static string Research =>
            ResourceManager.GetString("Research", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (object.ReferenceEquals(resourceMan, null))
                {
                    System.Resources.ResourceManager manager = new System.Resources.ResourceManager("Machs.Common.College.College", typeof(Machs.Common.College.College).Assembly);
                    resourceMan = manager;
                }
                return resourceMan;
            }
        }

        public static string WhyCollege =>
            ResourceManager.GetString("WhyCollege", resourceCulture);

        public static string WhyCollegePoint1 =>
            ResourceManager.GetString("WhyCollegePoint1", resourceCulture);

        public static string WhyCollegePoint2 =>
            ResourceManager.GetString("WhyCollegePoint2", resourceCulture);

        public static string WhyCollegePoint3 =>
            ResourceManager.GetString("WhyCollegePoint3", resourceCulture);

        public static string WhyCollegePoint4 =>
            ResourceManager.GetString("WhyCollegePoint4", resourceCulture);

        public static string WhyMachs =>
            ResourceManager.GetString("WhyMachs", resourceCulture);
    }
}

