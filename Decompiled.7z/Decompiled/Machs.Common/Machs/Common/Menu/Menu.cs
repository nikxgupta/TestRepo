﻿namespace Machs.Common.Menu
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), CompilerGenerated, DebuggerNonUserCode]
    public class Menu
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal Menu()
        {
        }

        public static string CoursePlan =>
            ResourceManager.GetString("CoursePlan", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static CultureInfo Culture => resourceCulture;

        public static string CV =>
            ResourceManager.GetString("CV", resourceCulture);

        public static string Department =>
            ResourceManager.GetString("Department", resourceCulture);

        public static string Document =>
            ResourceManager.GetString("Document", resourceCulture);

        public static string Download =>
            ResourceManager.GetString("Download", resourceCulture);

        public static string DownloadCV =>
            ResourceManager.GetString("DownloadCV", resourceCulture);

        public static string Downloads =>
            ResourceManager.GetString("Downloads", resourceCulture);

        public static string Email =>
            ResourceManager.GetString("Email", resourceCulture);

        public static string Faculty =>
            ResourceManager.GetString("Faculty", resourceCulture);

        public static string JumptoPage =>
            ResourceManager.GetString("JumptoPage", resourceCulture);

        public static string Next =>
            ResourceManager.GetString("Next", resourceCulture);

        public static string NoFormsAvailable =>
            ResourceManager.GetString("NoFormsAvailable", resourceCulture);

        public static string NoRecordFound =>
            ResourceManager.GetString("NoRecordFound", resourceCulture);

        public static string OfficeLocation =>
            ResourceManager.GetString("OfficeLocation", resourceCulture);

        public static string PhoneExt =>
            ResourceManager.GetString("PhoneExt", resourceCulture);

        public static string PhoneNumber =>
            ResourceManager.GetString("PhoneNumber", resourceCulture);

        public static string Position =>
            ResourceManager.GetString("Position", resourceCulture);

        public static string Prev =>
            ResourceManager.GetString("Prev", resourceCulture);

        public static string Publications =>
            ResourceManager.GetString("Publications", resourceCulture);

        public static string Qualification =>
            ResourceManager.GetString("Qualification", resourceCulture);

        public static string Research =>
            ResourceManager.GetString("Research", resourceCulture);

        public static string ResearchType =>
            ResourceManager.GetString("ResearchType", resourceCulture);

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (object.ReferenceEquals(resourceMan, null))
                {
                    System.Resources.ResourceManager manager = new System.Resources.ResourceManager("Machs.Common.Menu.Menu", typeof(Machs.Common.Menu.Menu).Assembly);
                    resourceMan = manager;
                }
                return resourceMan;
            }
        }

        public static string Search =>
            ResourceManager.GetString("Search", resourceCulture);

        public static string SearchPlaceholder =>
            ResourceManager.GetString("SearchPlaceholder", resourceCulture);

        public static string Selectpagenumber =>
            ResourceManager.GetString("Selectpagenumber", resourceCulture);

        public static string Staff =>
            ResourceManager.GetString("Staff", resourceCulture);

        public static string SubjectsTeach =>
            ResourceManager.GetString("SubjectsTeach", resourceCulture);

        public static string View =>
            ResourceManager.GetString("View", resourceCulture);
    }
}

