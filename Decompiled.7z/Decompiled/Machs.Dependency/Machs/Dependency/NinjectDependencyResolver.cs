﻿using Ninject.Modules;
using Ninject.Parameters;

namespace Machs.Dependency
{
    using Ninject;
    using Ninject.Syntax;
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public class NinjectDependencyResolver : IDependencyResolver
    {
        private IKernel _kernel = new StandardKernel(new INinjectModule[0]);

        public NinjectDependencyResolver()
        {
            this._kernel.Load(new Assembly[] { Assembly.GetExecutingAssembly() });
        }

        public IBindingToSyntax<T> Bind<T>() => 
            this._kernel.Bind<T>();

        public object GetService(Type serviceType) => 
            this._kernel.TryGet(serviceType, new IParameter[0]);

        public IEnumerable<object> GetServices(Type serviceType) => 
            this._kernel.GetAll(serviceType, new IParameter[0]);

        public T ResolveType<T>() => 
            this._kernel.Get<T>(new IParameter[0]);

        public IKernel Kernel =>
            this._kernel;
    }
}

