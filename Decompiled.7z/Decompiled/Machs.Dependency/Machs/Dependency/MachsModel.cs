﻿using Machs.Core;
using Machs.DAL;

namespace Machs.Dependency
{
    using Ninject.Modules;
    using System;

    public class MachsModel : NinjectModule
    {
        public override void Load()
        {
            base.Bind<Imain_userService>().To<main_userService>();
            base.Bind<Imain_user>().To<main_userRepo>();
            base.Bind<Imain_role_featuresService>().To<main_role_featuresService>();
            base.Bind<Imain_role_features>().To<main_role_featuresRepo>();
            base.Bind<Imain_roleService>().To<main_roleService>();
            base.Bind<Imain_role>().To<main_roleRepo>();
            base.Bind<Imain_bannerService>().To<main_bannerService>();
            base.Bind<Imain_banner>().To<main_bannerRepo>();
            base.Bind<Imain_uploadService>().To<main_uploadService>();
            base.Bind<Imain_upload>().To<main_uploadRepo>();
            base.Bind<Imain_menuService>().To<main_menuService>();
            base.Bind<Imain_menu>().To<main_menuRepo>();
            base.Bind<Imain_menu_dataService>().To<main_menu_dataService>();
            base.Bind<Imain_menu_data>().To<main_menu_dataRepo>();
            base.Bind<Imain_eventService>().To<main_eventService>();
            base.Bind<Imain_event>().To<main_eventRepo>();
            base.Bind<Imain_newsService>().To<main_newsService>();
            base.Bind<Imain_news>().To<main_newsRepo>();
            base.Bind<Imain_facultyMasterService>().To<main_facultyMasterService>();
            base.Bind<Imain_facultyMaster>().To<main_facultyMasterRepo>();
            base.Bind<Imain_faculty_publicationService>().To<main_faculty_publicationService>();
            base.Bind<Imain_faculty_publication>().To<main_faculty_publicationRepo>();
            base.Bind<Imain_faculty_qualificationService>().To<main_faculty_qualificationService>();
            base.Bind<Imain_faculty_qualification>().To<main_faculty_qualificationRepo>();
            base.Bind<Imain_faculty_researchService>().To<main_faculty_researchService>();
            base.Bind<Imain_faculty_research>().To<main_faculty_researchRepo>();
            base.Bind<Imain_home_popup_containerService>().To<main_home_popup_containerService>();
            base.Bind<Imain_home_popup_container>().To<main_home_popup_containerRepo>();
            base.Bind<Imain_CAC_blockService>().To<main_CAC_blockService>();
            base.Bind<Imain_CAC_block>().To<main_CAC_blockRepo>();
            base.Bind<Imain_small_home_iconService>().To<main_small_home_iconService>();
            base.Bind<Imain_small_home_icon>().To<main_small_home_iconRepo>();
            base.Bind<Imain_library>().To<main_libraryRepo>();
            base.Bind<Imain_libraryService>().To<main_libraryService>();
            base.Bind<Imain_lookup>().To<main_lookupRepo>();
            base.Bind<Imain_lookupService>().To<main_lookupService>();
            base.Bind<Imain_footer_websiteService>().To<main_footer_websiteService>();
            base.Bind<Imain_footer_website>().To<main_footer_websiteRepo>();
            base.Bind<Imain_library_menu>().To<main_library_menuRepo>();
            base.Bind<Imain_library_menuService>().To<main_library_menuService>();
            base.Bind<Imain_footer_helpService>().To<main_footer_helpService>();
            base.Bind<Imain_footer_help>().To<main_footer_helpRepo>();
            base.Bind<Imain_help_faqService>().To<main_help_faqService>();
            base.Bind<Imain_help_faq>().To<main_help_faqRepo>();
            base.Bind<Imain_footer_socialService>().To<main_footer_socialService>();
            base.Bind<Imain_footer_social>().To<main_footer_socialRepo>();
            base.Bind<Imain_footer_contactusService>().To<main_footer_contactusService>();
            base.Bind<Imain_footer_contactus>().To<main_footer_contactusRepo>();
            base.Bind<Imain_curriculum_yearService>().To<main_curriculum_yearService>();
            base.Bind<Imain_curriculum_year>().To<main_curriculum_yearRepo>();
            base.Bind<Imain_curriculum_infoService>().To<main_curriculum_infoService>();
            base.Bind<Imain_curriculum_info>().To<main_curriculum_infoRepo>();
            base.Bind<Imain_home_galleryService>().To<main_home_galleryService>();
            base.Bind<Imain_home_galleryRepo>().To<main_home_galleryRepo>();
            base.Bind<Imain_downloadsService>().To<main_downloadsService>();
            base.Bind<Imain_downloadsRepo>().To<main_downloadsRepo>();
            base.Bind<Imain_registrationService>().To<main_registrationService>();
            base.Bind<Imain_registration>().To<main_registrationRepo>();
            base.Bind<Imain_library_loan_systemService>().To<main_library_loan_systemService>();
            base.Bind<Imain_library_loan_system>().To<main_library_loan_systemRepo>();
        }
    }
}

