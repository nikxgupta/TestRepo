﻿namespace Machs.DAL
{
    public class main_home_galleryRepo : RepositoryBase<main_home_gallery>, Imain_home_galleryRepo, IRepository<main_home_gallery>
    {
    }
}

