﻿namespace Machs.DAL
{
    public class main_library_loan_systemRepo : RepositoryBase<main_library_loan_system>, Imain_library_loan_system, IRepository<main_library_loan_system>
    {
    }
}

