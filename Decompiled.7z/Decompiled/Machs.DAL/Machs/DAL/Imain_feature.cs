﻿namespace Machs.DAL
{
    public interface Imain_feature : IRepository<main_feature>
    {
    }
}

