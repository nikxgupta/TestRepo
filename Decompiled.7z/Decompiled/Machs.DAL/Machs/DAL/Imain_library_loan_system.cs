﻿namespace Machs.DAL
{
    public interface Imain_library_loan_system : IRepository<main_library_loan_system>
    {
    }
}

