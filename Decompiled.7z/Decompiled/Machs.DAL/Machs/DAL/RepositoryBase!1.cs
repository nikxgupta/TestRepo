﻿namespace Machs.DAL
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Reflection;

    public class RepositoryBase<T> : IRepository<T>
    {
        private void AddParametersToCmd(string paraName, object paraValue, ref SqlCommand pSqlcmd)
        {
            try
            {
                if ((paraValue is string) && !(!Convert.ToString(paraValue).Contains("'") || paraName.ToUpper().Contains("WHERE")))
                {
                }
                SqlParameter parameter = new SqlParameter(paraName, paraValue);
                pSqlcmd.Parameters.Add(parameter);
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
        }

        private IEnumerable<T> AutoMapReaderAll<T>(SqlDataReader rd)
        {
            var selector = null;
            List<T> list = new List<T>();
            while (rd.Read())
            {
                T objInstance = Activator.CreateInstance<T>();
                if (selector == null)
                {
                    selector = c => new { 
                        Property = c,
                        PropertyName = c.Name
                    };
                }
                typeof(T).GetProperties().Select(selector).ToList().ForEach(delegate (<>f__AnonymousType1<PropertyInfo, string> x) {
                    x.Property.SetValue(this.objInstance, this.CS$<>8__locals42.<>4__this.TryGetValue(this.CS$<>8__locals42.rd, x.PropertyName), null);
                });
                list.Add(objInstance);
            }
            return list;
        }

        private T AutoMapReaderSingle<T>(SqlDataReader rd)
        {
            var selector = null;
            T local;
            try
            {
                var action = null;
                T objInstance = Activator.CreateInstance<T>();
                while (rd.Read())
                {
                    if (selector == null)
                    {
                        selector = c => new { 
                            Property = c,
                            PropertyName = c.Name
                        };
                    }
                    if (action == null)
                    {
                        action = delegate (<>f__AnonymousType1<PropertyInfo, string> x) {
                            x.Property.SetValue(this.objInstance, this.CS$<>8__locals3a.<>4__this.TryGetValue(this.CS$<>8__locals3a.rd, x.PropertyName), null);
                        };
                    }
                    typeof(T).GetProperties().Select(selector).ToList().ForEach(action);
                }
                local = objInstance;
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            return local;
        }

        public int ExecuteNonQuery(T obj, string[] param, string spName)
        {
            var selector = null;
            var action = null;
            int num2;
            SqlCommand sqlCmd = new SqlCommand();
            SQLObject obj2 = new SQLObject();
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties();
                string masterDBConnString = obj2.GetMasterDBConnString();
                sqlCmd.CommandText = spName;
                List<string> lstParas = param.ToList<string>();
                if (selector == null)
                {
                    selector = c => new { 
                        PropName = c.Name,
                        PropVal = c.GetValue(obj, null)
                    };
                }
                if (action == null)
                {
                    action = delegate (<>f__AnonymousType0<string, object> x) {
                        ((RepositoryBase<T>) this).AddParametersToCmd(x.PropName, x.PropVal, ref sqlCmd);
                    };
                }
                (from c in properties
                    where lstParas.Contains(c.Name)
                    select c).Select(selector).ToList().ForEach(action);
                num2 = obj2.ExecuteNonQuery(sqlCmd, masterDBConnString);
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            return num2;
        }

        public T Get(T obj, string[] param, string spName)
        {
            var selector = null;
            var action = null;
            T local;
            SqlCommand sqlCmd = new SqlCommand();
            SqlConnection connection = new SqlConnection();
            SQLObject obj2 = new SQLObject();
            SqlDataReader rd = null;
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties();
                List<string> lstParas = param.ToList<string>();
                string masterDBConnString = obj2.GetMasterDBConnString();
                connection.ConnectionString = masterDBConnString;
                sqlCmd.Connection = connection;
                sqlCmd.CommandText = spName;
                if (selector == null)
                {
                    selector = c => new { 
                        PropName = c.Name,
                        PropVal = Convert.ToString(c.GetValue(obj, null))
                    };
                }
                if (action == null)
                {
                    action = delegate (<>f__AnonymousType0<string, string> x) {
                        ((RepositoryBase<T>) this).AddParametersToCmd(x.PropName, x.PropVal, ref sqlCmd);
                    };
                }
                (from c in properties
                    where lstParas.Contains(c.Name)
                    select c).Select(selector).ToList().ForEach(action);
                rd = obj2.ExecuteMasterReader(sqlCmd, false);
                local = this.AutoMapReaderSingle<T>(rd);
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            finally
            {
                if (!((rd == null) || rd.IsClosed))
                {
                    rd.Close();
                }
                if ((connection != null) && (connection.State != ConnectionState.Closed))
                {
                    connection.Close();
                }
            }
            return local;
        }

        public DataTable GetAlDataTablel(T obj, string[] param, string spName)
        {
            var selector = null;
            var action = null;
            DataTable table;
            SqlCommand sqlCmd = new SqlCommand();
            SQLObject obj2 = new SQLObject();
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties();
                string masterDBConnString = obj2.GetMasterDBConnString();
                sqlCmd.CommandText = spName;
                if (param != null)
                {
                    List<string> lstParas = param.ToList<string>();
                    if (selector == null)
                    {
                        selector = c => new { 
                            PropName = c.Name,
                            PropVal = Convert.ToString(c.GetValue(obj, null))
                        };
                    }
                    if (action == null)
                    {
                        action = delegate (<>f__AnonymousType0<string, string> x) {
                            ((RepositoryBase<T>) this).AddParametersToCmd(x.PropName, x.PropVal, ref sqlCmd);
                        };
                    }
                    (from c in properties
                        where lstParas.Contains(c.Name)
                        select c).Select(selector).ToList().ForEach(action);
                }
                table = obj2.SqlDataAdapter(sqlCmd, masterDBConnString).Tables[0];
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            return table;
        }

        public IEnumerable<T> GetAll(T obj, string[] param, string spName)
        {
            var selector = null;
            var action = null;
            IEnumerable<T> enumerable;
            SqlCommand sqlCmd = new SqlCommand();
            SqlConnection connection = new SqlConnection();
            SQLObject obj2 = new SQLObject();
            SqlDataReader rd = null;
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties();
                string masterDBConnString = obj2.GetMasterDBConnString();
                connection.ConnectionString = masterDBConnString;
                sqlCmd.Connection = connection;
                sqlCmd.CommandText = spName;
                if (param != null)
                {
                    List<string> lstParas = param.ToList<string>();
                    if (selector == null)
                    {
                        selector = c => new { 
                            PropName = c.Name,
                            PropVal = Convert.ToString(c.GetValue(obj, null))
                        };
                    }
                    if (action == null)
                    {
                        action = delegate (<>f__AnonymousType0<string, string> x) {
                            ((RepositoryBase<T>) this).AddParametersToCmd(x.PropName, x.PropVal, ref sqlCmd);
                        };
                    }
                    (from c in properties
                        where lstParas.Contains(c.Name)
                        select c).Select(selector).ToList().ForEach(action);
                }
                rd = obj2.ExecuteMasterReader(sqlCmd, false);
                List<T> list2 = new List<T>();
                enumerable = this.AutoMapReaderAll<T>(rd).ToList<T>();
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            finally
            {
                if (!((rd == null) || rd.IsClosed))
                {
                    rd.Close();
                }
                if ((connection != null) && (connection.State != ConnectionState.Closed))
                {
                    connection.Close();
                }
            }
            return enumerable;
        }

        public IEnumerable<T> GetAll(object obj, string[] param, string spName)
        {
            var selector = null;
            var action = null;
            IEnumerable<T> enumerable;
            SqlCommand sqlCmd = new SqlCommand();
            SqlConnection connection = new SqlConnection();
            SQLObject obj2 = new SQLObject();
            SqlDataReader rd = null;
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties();
                string masterDBConnString = obj2.GetMasterDBConnString();
                connection.ConnectionString = masterDBConnString;
                sqlCmd.Connection = connection;
                sqlCmd.CommandText = spName;
                if (param != null)
                {
                    List<string> lstParas = param.ToList<string>();
                    if (selector == null)
                    {
                        selector = c => new { 
                            PropName = c.Name,
                            PropVal = Convert.ToString(c.GetValue(obj, null))
                        };
                    }
                    if (action == null)
                    {
                        action = delegate (<>f__AnonymousType0<string, string> x) {
                            ((RepositoryBase<T>) this).AddParametersToCmd(x.PropName, x.PropVal, ref sqlCmd);
                        };
                    }
                    (from c in properties
                        where lstParas.Contains(c.Name)
                        select c).Select(selector).ToList().ForEach(action);
                }
                rd = obj2.ExecuteMasterReader(sqlCmd, false);
                List<T> list2 = new List<T>();
                enumerable = this.AutoMapReaderAll<T>(rd).ToList<T>();
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            finally
            {
                if (!((rd == null) || rd.IsClosed))
                {
                    rd.Close();
                }
                if ((connection != null) && (connection.State != ConnectionState.Closed))
                {
                    connection.Close();
                }
            }
            return enumerable;
        }

        public object GetScalar(T obj, string[] param, string spName)
        {
            var selector = null;
            var action = null;
            object obj3;
            SqlCommand sqlCmd = new SqlCommand();
            SQLObject obj2 = new SQLObject();
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties();
                string masterDBConnString = obj2.GetMasterDBConnString();
                sqlCmd.CommandText = spName;
                if (param != null)
                {
                    List<string> lstParas = param.ToList<string>();
                    if (selector == null)
                    {
                        selector = c => new { 
                            PropName = c.Name,
                            PropVal = Convert.ToString(c.GetValue(obj, null))
                        };
                    }
                    if (action == null)
                    {
                        action = delegate (<>f__AnonymousType0<string, string> x) {
                            ((RepositoryBase<T>) this).AddParametersToCmd(x.PropName, x.PropVal, ref sqlCmd);
                        };
                    }
                    (from c in properties
                        where lstParas.Contains(c.Name)
                        select c).Select(selector).ToList().ForEach(action);
                }
                obj3 = obj2.ExecuteMasterScalar(sqlCmd);
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            return obj3;
        }

        private object TryGetValue(SqlDataReader reader, string name)
        {
            object obj2;
            try
            {
                DataTable schemaTable = reader.GetSchemaTable();
                for (int i = 0; i < schemaTable.Rows.Count; i++)
                {
                    if (schemaTable.Rows[i][0].ToString().ToLower() == name.ToLower())
                    {
                        if (DBNull.Value.Equals(reader[i]))
                        {
                            return null;
                        }
                        return reader[i];
                    }
                }
                obj2 = null;
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception.InnerException);
            }
            return obj2;
        }
    }
}

