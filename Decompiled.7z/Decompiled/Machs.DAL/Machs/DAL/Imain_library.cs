﻿namespace Machs.DAL
{
    public interface Imain_library : IRepository<main_library>
    {
    }
}

