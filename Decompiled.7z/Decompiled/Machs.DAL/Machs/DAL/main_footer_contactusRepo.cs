﻿namespace Machs.DAL
{
    public class main_footer_contactusRepo : RepositoryBase<main_footer_contactus>, Imain_footer_contactus, IRepository<main_footer_contactus>
    {
    }
}

