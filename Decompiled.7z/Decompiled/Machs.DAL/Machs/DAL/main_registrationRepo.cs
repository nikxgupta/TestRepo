﻿namespace Machs.DAL
{
    public class main_registrationRepo : RepositoryBase<main_registration>, Imain_registration, IRepository<main_registration>
    {
    }
}

