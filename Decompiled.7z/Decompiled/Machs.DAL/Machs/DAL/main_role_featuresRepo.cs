﻿namespace Machs.DAL
{
    public class main_role_featuresRepo : RepositoryBase<main_role_features>, Imain_role_features, IRepository<main_role_features>
    {
    }
}

