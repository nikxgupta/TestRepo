﻿namespace Machs.DAL
{
    public interface Imain_footer_social : IRepository<main_footer_social>
    {
    }
}

