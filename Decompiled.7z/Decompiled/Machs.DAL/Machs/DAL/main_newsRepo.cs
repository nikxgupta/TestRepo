﻿namespace Machs.DAL
{
    public class main_newsRepo : RepositoryBase<main_news>, Imain_news, IRepository<main_news>
    {
    }
}

