﻿namespace Machs.DAL
{
    public class main_uploadRepo : RepositoryBase<main_upload>, Imain_upload, IRepository<main_upload>
    {
    }
}

