﻿namespace Machs.DAL
{
    public interface Imain_CAC_block : IRepository<main_CAC_block>
    {
    }
}

