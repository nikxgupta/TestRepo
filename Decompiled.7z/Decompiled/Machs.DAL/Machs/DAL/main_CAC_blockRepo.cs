﻿namespace Machs.DAL
{
    public class main_CAC_blockRepo : RepositoryBase<main_CAC_block>, Imain_CAC_block, IRepository<main_CAC_block>
    {
    }
}

