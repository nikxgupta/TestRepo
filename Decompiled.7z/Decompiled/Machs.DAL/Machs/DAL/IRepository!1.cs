﻿namespace Machs.DAL
{
    using System;
    using System.Collections.Generic;

    public interface IRepository<T>
    {
        int ExecuteNonQuery(T obj, string[] param, string spName);
        T Get(T obj, string[] param, string spName);
        IEnumerable<T> GetAll(T obj, string[] param, string spName);
        IEnumerable<T> GetAll(object obj, string[] param, string spName);
        object GetScalar(T obj, string[] param, string spName);
    }
}

