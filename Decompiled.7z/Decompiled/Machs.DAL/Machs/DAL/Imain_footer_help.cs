﻿namespace Machs.DAL
{
    public interface Imain_footer_help : IRepository<main_footer_help>
    {
    }
}

