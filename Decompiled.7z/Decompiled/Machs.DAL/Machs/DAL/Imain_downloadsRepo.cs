﻿namespace Machs.DAL
{
    public interface Imain_downloadsRepo : IRepository<main_downloads>
    {
    }
}

