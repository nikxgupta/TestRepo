﻿namespace Machs.DAL
{
    public class main_footer_helpRepo : RepositoryBase<main_footer_help>, Imain_footer_help, IRepository<main_footer_help>
    {
    }
}

