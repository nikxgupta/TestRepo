﻿namespace Machs.DAL
{
    public class main_small_home_iconRepo : RepositoryBase<main_small_home_icon>, Imain_small_home_icon, IRepository<main_small_home_icon>
    {
    }
}

