﻿namespace Machs.DAL
{
    public interface Imain_faculty_research : IRepository<main_faculty_research>
    {
    }
}

