﻿namespace Machs.DAL
{
    public class main_roleRepo : RepositoryBase<main_role>, Imain_role, IRepository<main_role>
    {
    }
}

