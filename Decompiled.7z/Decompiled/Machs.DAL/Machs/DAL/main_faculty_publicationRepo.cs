﻿namespace Machs.DAL
{
    public class main_faculty_publicationRepo : RepositoryBase<main_faculty_publication>, Imain_faculty_publication, IRepository<main_faculty_publication>
    {
    }
}

