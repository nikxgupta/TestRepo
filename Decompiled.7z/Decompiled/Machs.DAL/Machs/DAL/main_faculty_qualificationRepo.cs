﻿namespace Machs.DAL
{
    public class main_faculty_qualificationRepo : RepositoryBase<main_faculty_qualification>, Imain_faculty_qualification, IRepository<main_faculty_qualification>
    {
    }
}

