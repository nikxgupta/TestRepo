﻿namespace Machs.DAL
{
    public class main_bannerRepo : RepositoryBase<main_banner>, Imain_banner, IRepository<main_banner>
    {
    }
}

