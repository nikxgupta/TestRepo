﻿namespace Machs.DAL
{
    public interface Imain_upload : IRepository<main_upload>
    {
    }
}

