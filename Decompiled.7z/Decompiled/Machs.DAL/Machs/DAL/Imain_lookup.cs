﻿namespace Machs.DAL
{
    public interface Imain_lookup : IRepository<main_lookup>
    {
    }
}

