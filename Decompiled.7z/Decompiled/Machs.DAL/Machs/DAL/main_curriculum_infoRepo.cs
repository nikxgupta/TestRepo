﻿namespace Machs.DAL
{
    public class main_curriculum_infoRepo : RepositoryBase<main_curriculum_info>, Imain_curriculum_info, IRepository<main_curriculum_info>
    {
    }
}

