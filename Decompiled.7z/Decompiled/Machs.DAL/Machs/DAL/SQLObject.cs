﻿namespace Machs.DAL
{
    using System;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;

    public class SQLObject
    {
        private const int itryCount = 10;
        public string MasterConnectionString = string.Empty;
        public SqlConnection sqlConnectionClient;
        public SqlConnection sqlConnectionImport;
        public SqlConnection sqlConnectionMaster;

        public System.Data.SqlClient.SqlDataReader ExecuteMasterReader(SqlCommand pCommand, bool pisConOpen)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            if (!pisConOpen)
            {
                pCommand.Connection.Open();
            }
            return pCommand.ExecuteReader();
        }

        public object ExecuteMasterScalar(SqlCommand pCommand)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            int num = 0;
            using (SqlConnection connection = new SqlConnection(this.GetMasterDBConnString()))
            {
                pCommand.Connection = connection;
                while ((connection.State != ConnectionState.Open) && (num < 10))
                {
                    if (connection.State != ConnectionState.Connecting)
                    {
                        connection.Open();
                    }
                    if (connection.State == ConnectionState.Open)
                    {
                        return pCommand.ExecuteScalar();
                    }
                    num++;
                }
            }
            return null;
        }

        public bool ExecuteNonQuery(SqlCommand pCommand)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            int num = pCommand.ExecuteNonQuery();
            return true;
        }

        public int ExecuteNonQuery(SqlCommand pCommand, string pConnString)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            using (SqlConnection connection = new SqlConnection(pConnString))
            {
                connection.Open();
                pCommand.Connection = connection;
                return pCommand.ExecuteNonQuery();
            }
        }

        public bool ExecuteNonQuery(SqlCommand pCommand, string pConnString, bool pIsExecuted)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            pIsExecuted = false;
            using (SqlConnection connection = new SqlConnection(pConnString))
            {
                connection.Open();
                pCommand.Connection = connection;
                pCommand.ExecuteNonQuery();
            }
            pIsExecuted = true;
            return pIsExecuted;
        }

        public int ExecuteNonQueryCount(SqlCommand pCommand)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            return pCommand.ExecuteNonQuery();
        }

        public object ExecuteScalar(SqlCommand pCommand, bool pIsConnOpen)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            if (!pIsConnOpen)
            {
                pCommand.Connection.Open();
            }
            return pCommand.ExecuteScalar();
        }

        public string GetMasterDBConnString() => 
            ConfigurationManager.ConnectionStrings["SessionConn"].ToString();

        public bool ReaderHasColumn(IDataReader reader, string pColumnName)
        {
            reader.GetSchemaTable().DefaultView.RowFilter = "ColumnName= '" + pColumnName + "'";
            return (reader.GetSchemaTable().DefaultView.Count > 0);
        }

        public DataSet SqlDataAdapter(SqlCommand pCommand)
        {
            DataSet dataSet = null;
            pCommand.CommandType = CommandType.StoredProcedure;
            dataSet = new DataSet();
            using (System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter(pCommand))
            {
                adapter.Fill(dataSet);
            }
            return dataSet;
        }

        public DataSet SqlDataAdapter(SqlCommand pCommand, string pConnString)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            using (SqlConnection connection = new SqlConnection(pConnString))
            {
                pCommand.Connection = connection;
                return this.SqlDataAdapter(pCommand);
            }
        }

        public System.Data.SqlClient.SqlDataReader SqlDataReader(SqlCommand pCommand, bool pIsConnOpen)
        {
            pCommand.CommandType = CommandType.StoredProcedure;
            pCommand.CommandTimeout = 0;
            if (!pIsConnOpen)
            {
                pCommand.Connection.Open();
            }
            return pCommand.ExecuteReader();
        }
    }
}

