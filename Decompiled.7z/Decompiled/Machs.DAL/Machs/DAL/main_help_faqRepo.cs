﻿namespace Machs.DAL
{
    public class main_help_faqRepo : RepositoryBase<main_help_faq>, Imain_help_faq, IRepository<main_help_faq>
    {
    }
}

