﻿namespace Machs.DAL
{
    public class main_footer_socialRepo : RepositoryBase<main_footer_social>, Imain_footer_social, IRepository<main_footer_social>
    {
    }
}

