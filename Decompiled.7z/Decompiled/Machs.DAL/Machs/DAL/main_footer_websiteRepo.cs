﻿namespace Machs.DAL
{
    public class main_footer_websiteRepo : RepositoryBase<main_footer_website>, Imain_footer_website, IRepository<main_footer_website>
    {
    }
}

