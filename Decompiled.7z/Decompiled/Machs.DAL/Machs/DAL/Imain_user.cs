﻿namespace Machs.DAL
{
    public interface Imain_user : IRepository<main_user>
    {
    }
}

