﻿namespace Machs.DAL
{
    public class main_library_menuRepo : RepositoryBase<main_library_menu>, Imain_library_menu, IRepository<main_library_menu>
    {
    }
}

