﻿namespace Machs.DAL
{
    public interface Imain_faculty_publication : IRepository<main_faculty_publication>
    {
    }
}

