﻿namespace Machs.DAL
{
    public interface Imain_facultyMaster : IRepository<main_facultyMaster>
    {
    }
}

