﻿namespace Machs.DAL
{
    public class main_facultyMasterRepo : RepositoryBase<main_facultyMaster>, Imain_facultyMaster, IRepository<main_facultyMaster>
    {
    }
}

