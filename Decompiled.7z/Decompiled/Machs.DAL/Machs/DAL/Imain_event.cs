﻿namespace Machs.DAL
{
    public interface Imain_event : IRepository<main_event>
    {
    }
}

