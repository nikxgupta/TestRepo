﻿namespace Machs.DAL
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Runtime.CompilerServices;
    using System.Text;

    public static class SqlCommandExtensions
    {
        public static string CommandAsSql(this SqlCommand sc)
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                try
                {
                    bool flag = true;
                    builder.AppendLine("use " + sc.Connection.Database + ";");
                    switch (sc.CommandType)
                    {
                        case CommandType.Text:
                            builder.AppendLine(sc.CommandText);
                            break;

                        case CommandType.StoredProcedure:
                            builder.AppendLine("declare @return_value int;");
                            foreach (SqlParameter parameter in sc.Parameters)
                            {
                                if ((parameter.Direction == ParameterDirection.InputOutput) || (parameter.Direction == ParameterDirection.Output))
                                {
                                    builder.Append("declare " + parameter.ParameterName + "\t" + parameter.SqlDbType.ToString() + "\t= ");
                                    builder.AppendLine(((parameter.Direction == ParameterDirection.Output) ? "null" : parameter.ParameterValueForSQL()) + ";");
                                }
                            }
                            builder.AppendLine("exec [" + sc.CommandText + "]");
                            foreach (SqlParameter parameter in sc.Parameters)
                            {
                                if (parameter.Direction != ParameterDirection.ReturnValue)
                                {
                                    builder.Append(flag ? "\t" : "\t, ");
                                    if (flag)
                                    {
                                        flag = false;
                                    }
                                    if (parameter.Direction == ParameterDirection.Input)
                                    {
                                        builder.AppendLine(parameter.ParameterName + " = " + parameter.ParameterValueForSQL());
                                    }
                                    else
                                    {
                                        builder.AppendLine(parameter.ParameterName + " = " + parameter.ParameterName + " output");
                                    }
                                }
                            }
                            builder.AppendLine(";");
                            builder.AppendLine("select 'Return Value' = convert(varchar, @return_value);");
                            foreach (SqlParameter parameter in sc.Parameters)
                            {
                                if ((parameter.Direction == ParameterDirection.InputOutput) || (parameter.Direction == ParameterDirection.Output))
                                {
                                    builder.AppendLine("select '" + parameter.ParameterName + "' = convert(varchar, " + parameter.ParameterName + ");");
                                }
                            }
                            break;
                    }
                }
                catch (Exception)
                {
                    builder.AppendLine(string.Empty);
                }
            }
            finally
            {
            }
            return builder.ToString();
        }

        public static string ParameterValueForSQL(this SqlParameter sp)
        {
            string str2 = string.IsNullOrEmpty(Convert.ToString(sp.Value)) ? string.Empty : Convert.ToString(sp.Value);
            switch (sp.SqlDbType)
            {
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                case SqlDbType.DateTimeOffset:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                case SqlDbType.Char:
                case SqlDbType.DateTime:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                    return ("'" + str2.Replace("'", "''") + "'");

                case SqlDbType.Bit:
                    return str2;
            }
            return str2.Replace("'", "''");
        }
    }
}

