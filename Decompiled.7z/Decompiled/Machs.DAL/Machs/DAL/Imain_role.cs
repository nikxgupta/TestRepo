﻿namespace Machs.DAL
{
    public interface Imain_role : IRepository<main_role>
    {
    }
}

