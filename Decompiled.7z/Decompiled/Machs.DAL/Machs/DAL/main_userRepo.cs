﻿namespace Machs.DAL
{
    public class main_userRepo : RepositoryBase<main_user>, Imain_user, IRepository<main_user>
    {
    }
}

