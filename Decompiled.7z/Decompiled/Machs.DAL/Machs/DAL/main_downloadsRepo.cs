﻿namespace Machs.DAL
{
    public class main_downloadsRepo : RepositoryBase<main_downloads>, Imain_downloadsRepo, IRepository<main_downloads>
    {
    }
}

