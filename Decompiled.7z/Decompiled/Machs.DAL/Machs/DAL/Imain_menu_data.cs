﻿namespace Machs.DAL
{
    public interface Imain_menu_data : IRepository<main_menu_data>
    {
    }
}

