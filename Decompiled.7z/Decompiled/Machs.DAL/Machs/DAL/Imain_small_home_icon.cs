﻿namespace Machs.DAL
{
    public interface Imain_small_home_icon : IRepository<main_small_home_icon>
    {
    }
}

