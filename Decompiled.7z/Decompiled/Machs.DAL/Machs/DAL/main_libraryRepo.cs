﻿namespace Machs.DAL
{
    public class main_libraryRepo : RepositoryBase<main_library>, Imain_library, IRepository<main_library>
    {
    }
}

