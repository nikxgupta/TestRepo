﻿namespace Machs.DAL
{
    public interface Imain_role_features : IRepository<main_role_features>
    {
    }
}

