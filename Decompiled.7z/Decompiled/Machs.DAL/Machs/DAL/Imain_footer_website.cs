﻿namespace Machs.DAL
{
    public interface Imain_footer_website : IRepository<main_footer_website>
    {
    }
}

