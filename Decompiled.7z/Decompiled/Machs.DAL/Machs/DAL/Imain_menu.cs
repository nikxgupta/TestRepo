﻿namespace Machs.DAL
{
    public interface Imain_menu : IRepository<main_menu>
    {
    }
}

