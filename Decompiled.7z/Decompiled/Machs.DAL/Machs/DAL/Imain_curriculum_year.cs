﻿namespace Machs.DAL
{
    public interface Imain_curriculum_year : IRepository<main_curriculum_year>
    {
    }
}

