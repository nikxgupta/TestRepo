﻿namespace Machs.DAL
{
    public class main_home_popup_containerRepo : RepositoryBase<main_home_popup_container>, Imain_home_popup_container, IRepository<main_home_popup_container>
    {
    }
}

