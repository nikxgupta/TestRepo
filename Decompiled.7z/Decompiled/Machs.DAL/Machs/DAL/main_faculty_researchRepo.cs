﻿namespace Machs.DAL
{
    public class main_faculty_researchRepo : RepositoryBase<main_faculty_research>, Imain_faculty_research, IRepository<main_faculty_research>
    {
    }
}

