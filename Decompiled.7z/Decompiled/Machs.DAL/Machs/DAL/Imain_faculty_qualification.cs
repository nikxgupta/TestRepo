﻿namespace Machs.DAL
{
    public interface Imain_faculty_qualification : IRepository<main_faculty_qualification>
    {
    }
}

