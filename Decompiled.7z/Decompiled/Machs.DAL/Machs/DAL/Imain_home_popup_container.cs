﻿namespace Machs.DAL
{
    public interface Imain_home_popup_container : IRepository<main_home_popup_container>
    {
    }
}

