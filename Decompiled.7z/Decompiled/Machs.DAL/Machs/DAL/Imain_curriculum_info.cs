﻿namespace Machs.DAL
{
    public interface Imain_curriculum_info : IRepository<main_curriculum_info>
    {
    }
}

