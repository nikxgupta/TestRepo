﻿namespace Machs.DAL
{
    public interface Imain_library_menu : IRepository<main_library_menu>
    {
    }
}

