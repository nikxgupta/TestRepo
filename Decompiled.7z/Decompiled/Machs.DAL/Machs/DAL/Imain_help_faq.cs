﻿namespace Machs.DAL
{
    public interface Imain_help_faq : IRepository<main_help_faq>
    {
    }
}

