﻿namespace Machs.DAL
{
    public class main_menuRepo : RepositoryBase<main_menu>, Imain_menu, IRepository<main_menu>
    {
    }
}

