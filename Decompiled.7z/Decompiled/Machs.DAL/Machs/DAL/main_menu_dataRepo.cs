﻿namespace Machs.DAL
{
    public class main_menu_dataRepo : RepositoryBase<main_menu_data>, Imain_menu_data, IRepository<main_menu_data>
    {
    }
}

