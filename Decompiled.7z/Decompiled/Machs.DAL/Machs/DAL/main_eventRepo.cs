﻿namespace Machs.DAL
{
    public class main_eventRepo : RepositoryBase<main_event>, Imain_event, IRepository<main_event>
    {
    }
}

