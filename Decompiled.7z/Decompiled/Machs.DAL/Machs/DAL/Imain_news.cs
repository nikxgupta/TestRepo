﻿namespace Machs.DAL
{
    public interface Imain_news : IRepository<main_news>
    {
    }
}

