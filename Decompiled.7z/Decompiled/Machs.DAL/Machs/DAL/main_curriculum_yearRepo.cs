﻿namespace Machs.DAL
{
    public class main_curriculum_yearRepo : RepositoryBase<main_curriculum_year>, Imain_curriculum_year, IRepository<main_curriculum_year>
    {
    }
}

