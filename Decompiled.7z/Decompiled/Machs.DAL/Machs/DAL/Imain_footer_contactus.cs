﻿namespace Machs.DAL
{
    public interface Imain_footer_contactus : IRepository<main_footer_contactus>
    {
    }
}

