﻿namespace Machs.DAL
{
    public class main_lookupRepo : RepositoryBase<main_lookup>, Imain_lookup, IRepository<main_lookup>
    {
    }
}

