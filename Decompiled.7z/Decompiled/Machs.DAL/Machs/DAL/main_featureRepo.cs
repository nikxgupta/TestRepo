﻿namespace Machs.DAL
{
    public class main_featureRepo : RepositoryBase<main_feature>, Imain_feature, IRepository<main_feature>
    {
    }
}

