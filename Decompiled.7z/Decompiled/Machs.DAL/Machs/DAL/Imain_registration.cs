﻿namespace Machs.DAL
{
    public interface Imain_registration : IRepository<main_registration>
    {
    }
}

