﻿namespace Machs.DAL
{
    public interface Imain_banner : IRepository<main_banner>
    {
    }
}

