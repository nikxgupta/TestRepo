﻿namespace Machs.DAL
{
    public interface Imain_home_galleryRepo : IRepository<main_home_gallery>
    {
    }
}

